-- NUKEVIET 4.0
-- Module: Database
-- http://www.nukeviet.vn
--
-- Host: 127.0.0.1
-- Generation Time: February 17, 2017, 02:13 PM GMT
-- Server version: 5.6.29
-- PHP Version: 5.6.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET SESSION `character_set_client`='utf8mb4';
SET SESSION `character_set_results`='utf8mb4';
SET SESSION `character_set_connection`='utf8mb4';
SET SESSION `collation_connection`='utf8mb4_unicode_ci';
SET NAMES 'utf8mb4';
ALTER DATABASE DEFAULT CHARACTER SET `utf8mb4` COLLATE `utf8mb4_unicode_ci`;

--
-- Database: `azvietco_one`
--


-- ---------------------------------------


--
-- Table structure for table `az_authors`
--

DROP TABLE IF EXISTS `az_authors`;
CREATE TABLE `az_authors` (
  `admin_id` mediumint(8) unsigned NOT NULL,
  `editor` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `lev` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `files_level` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `position` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `edittime` int(11) NOT NULL DEFAULT '0',
  `is_suspend` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `susp_reason` text  COLLATE utf8mb4_unicode_ci,
  `check_num` varchar(40)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_authors`
--

INSERT INTO `az_authors` VALUES
(1, 'ckeditor', 1, 'adobe,archives,audio,documents,flash,images,real,video|1|1|1', 'Administrator', 0, 0, 0, '', 'b0c94768838b2fd97e59c1067de04c07', 1478747560, '14.175.225.154', 'Mozilla/5.0 (Windows NT 6.2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36');


-- ---------------------------------------


--
-- Table structure for table `az_authors_config`
--

DROP TABLE IF EXISTS `az_authors_config`;
CREATE TABLE `az_authors_config` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `keyname` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `keyname` (`keyname`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_authors_module`
--

DROP TABLE IF EXISTS `az_authors_module`;
CREATE TABLE `az_authors_module` (
  `mid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `lang_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  `act_1` tinyint(4) NOT NULL DEFAULT '0',
  `act_2` tinyint(4) NOT NULL DEFAULT '1',
  `act_3` tinyint(4) NOT NULL DEFAULT '1',
  `checksum` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`mid`),
  UNIQUE KEY `module` (`module`)
) ENGINE=MyISAM  AUTO_INCREMENT=12  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_authors_module`
--

INSERT INTO `az_authors_module` VALUES
(1, 'siteinfo', 'mod_siteinfo', 1, 1, 1, 1, '527181e13fc75bf6e43985ff835cc5c7'), 
(2, 'authors', 'mod_authors', 2, 1, 1, 1, '3b5c9fc23465cc02df00127bdd173125'), 
(3, 'settings', 'mod_settings', 3, 1, 1, 0, '0965c1f3c67642860c01223556f14995'), 
(4, 'database', 'mod_database', 4, 1, 0, 0, '65acd20547e0d58311eaab54fcc253e4'), 
(5, 'webtools', 'mod_webtools', 5, 1, 0, 0, '972942e97ff0178d5c27e57a343ad64f'), 
(6, 'seotools', 'mod_seotools', 6, 1, 0, 0, '5eba5e6e94643575c43dff46710d333e'), 
(7, 'language', 'mod_language', 7, 1, 1, 0, '8a2751f2ac1c7ab3c2179a83ecdc3cb3'), 
(8, 'modules', 'mod_modules', 8, 1, 1, 0, '5540a37dc550242431f52cd51ab494cf'), 
(9, 'themes', 'mod_themes', 9, 1, 1, 0, 'c938df566fb3eb2a2fe3615c13b33742'), 
(10, 'extensions', 'mod_extensions', 10, 1, 0, 0, 'db444b85f38610185d13dca3320fc636'), 
(11, 'upload', 'mod_upload', 11, 1, 1, 1, '8e718a140b8619b2d8fd4e0fe8952c75');


-- ---------------------------------------


--
-- Table structure for table `az_banip`
--

DROP TABLE IF EXISTS `az_banip`;
CREATE TABLE `az_banip` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `ip` varchar(32)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mask` tinyint(4) NOT NULL DEFAULT '0',
  `area` tinyint(3) NOT NULL,
  `begintime` int(11) DEFAULT NULL,
  `endtime` int(11) DEFAULT NULL,
  `notice` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_banners_click`
--

DROP TABLE IF EXISTS `az_banners_click`;
CREATE TABLE `az_banners_click` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `click_time` int(11) unsigned NOT NULL DEFAULT '0',
  `click_day` int(2) NOT NULL,
  `click_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_country` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_browse_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_os_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `click_ref` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `bid` (`bid`),
  KEY `click_day` (`click_day`),
  KEY `click_ip` (`click_ip`),
  KEY `click_country` (`click_country`),
  KEY `click_browse_key` (`click_browse_key`),
  KEY `click_os_key` (`click_os_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_banners_click`
--

INSERT INTO `az_banners_click` VALUES
(2, 1475347816, 0, '127.0.0.1', 'ZZ', '', 'chrome', '', 'Windows 7', 'http://wonder.de/contact/');


-- ---------------------------------------


--
-- Table structure for table `az_banners_clients`
--

DROP TABLE IF EXISTS `az_banners_clients`;
CREATE TABLE `az_banners_clients` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(60)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(80)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `reg_time` int(11) unsigned NOT NULL DEFAULT '0',
  `full_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `yim` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `check_num` varchar(40)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploadtype` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`),
  UNIQUE KEY `email` (`email`),
  KEY `full_name` (`full_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_banners_plans`
--

DROP TABLE IF EXISTS `az_banners_plans`;
CREATE TABLE `az_banners_plans` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `blang` char(2)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `form` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_banners_plans`
--

INSERT INTO `az_banners_plans` VALUES
(1, '', 'Quang cao giua trang', '', 'sequential', 575, 72, 1), 
(2, '', 'Quang cao trai', '', 'sequential', 212, 800, 1), 
(3, '', 'Quang cao Phai', '', 'random', 250, 500, 1);


-- ---------------------------------------


--
-- Table structure for table `az_banners_rows`
--

DROP TABLE IF EXISTS `az_banners_rows`;
CREATE TABLE `az_banners_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `clid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `file_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_ext` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_mime` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` int(4) unsigned NOT NULL DEFAULT '0',
  `height` int(4) unsigned NOT NULL DEFAULT '0',
  `file_alt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageforswf` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `click_url` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_blank',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `clid` (`clid`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_banners_rows`
--

INSERT INTO `az_banners_rows` VALUES
(2, 'vinades', 2, 0, 'vinades.jpg', 'jpg', 'image/jpeg', 212, 400, '', '', 'http://vinades.vn', '_blank', 1475277519, 1475277519, 0, 1, 1, 2), 
(3, 'Quang cao giua trang', 1, 0, 'webnhanh.jpg', 'png', 'image/jpeg', 575, 72, '', '', 'http://webnhanh.vn', '_blank', 1475277519, 1475277519, 0, 0, 1, 1), 
(4, '123host_Nukeviet', 3, 0, '123host_nukeviet.jpg', 'jpg', 'image/jpeg', 250, 250, '', '', 'http://event.123host.vn/link/out/338', '_blank', 1453194858, 1453194858, 0, 0, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `az_config`
--

DROP TABLE IF EXISTS `az_config`;
CREATE TABLE `az_config` (
  `lang` varchar(3)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sys',
  `module` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'global',
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `config_value` text  COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `lang` (`lang`,`module`,`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_config`
--

INSERT INTO `az_config` VALUES
('sys', 'site', 'closed_site', '0'), 
('sys', 'site', 'admin_theme', 'admin_default'), 
('sys', 'site', 'date_pattern', 'l, d/m/Y'), 
('sys', 'site', 'time_pattern', 'H:i'), 
('sys', 'site', 'online_upd', '1'), 
('sys', 'site', 'statistic', '1'), 
('sys', 'site', 'mailer_mode', ''), 
('sys', 'site', 'smtp_host', 'smtp.gmail.com'), 
('sys', 'site', 'smtp_ssl', '1'), 
('sys', 'site', 'smtp_port', '465'), 
('sys', 'site', 'smtp_username', 'user@gmail.com'), 
('sys', 'site', 'smtp_password', ''), 
('sys', 'site', 'googleAnalyticsID', ''), 
('sys', 'site', 'googleAnalyticsSetDomainName', '0'), 
('sys', 'site', 'googleAnalyticsMethod', 'classic'), 
('sys', 'site', 'searchEngineUniqueID', ''), 
('sys', 'site', 'metaTagsOgp', '1'), 
('sys', 'site', 'pageTitleMode', 'pagetitle'), 
('sys', 'site', 'description_length', '170'), 
('sys', 'global', 'ssl_https', '0'), 
('sys', 'global', 'notification_active', '1'), 
('sys', 'global', 'notification_autodel', '15'), 
('sys', 'global', 'site_keywords', 'AZVIET CMS, portal, mysql, php'), 
('sys', 'global', 'site_phone', ''), 
('sys', 'global', 'block_admin_ip', '0'), 
('sys', 'global', 'admfirewall', '0'), 
('sys', 'global', 'dump_autobackup', '1'), 
('sys', 'global', 'dump_backup_ext', 'gz'), 
('sys', 'global', 'dump_backup_day', '30'), 
('sys', 'global', 'gfx_chk', '3'), 
('sys', 'global', 'file_allowed_ext', 'adobe,archives,audio,documents,flash,images,real,video'), 
('sys', 'global', 'forbid_extensions', 'php,php3,php4,php5,phtml,inc'), 
('sys', 'global', 'forbid_mimes', ''), 
('sys', 'global', 'nv_max_size', '2097152'), 
('sys', 'global', 'upload_checking_mode', 'mild'), 
('sys', 'global', 'upload_alt_require', '1'), 
('sys', 'global', 'upload_auto_alt', '1'), 
('sys', 'global', 'allowuserreg', '1'), 
('sys', 'global', 'allowuserlogin', '1'), 
('sys', 'global', 'allowuserloginmulti', '0'), 
('sys', 'global', 'allowloginchange', '0'), 
('sys', 'global', 'allowquestion', '0'), 
('sys', 'global', 'allowuserpublic', '1'), 
('sys', 'global', 'useactivate', '2'), 
('sys', 'global', 'allowmailchange', '1'), 
('sys', 'global', 'allow_sitelangs', 'vi'), 
('sys', 'global', 'read_type', '0'), 
('sys', 'global', 'rewrite_optional', '1'), 
('sys', 'global', 'rewrite_endurl', '/'), 
('sys', 'global', 'rewrite_exturl', '.html'), 
('sys', 'global', 'rewrite_op_mod', 'news'), 
('sys', 'global', 'autocheckupdate', '1'), 
('sys', 'global', 'autoupdatetime', '24'), 
('sys', 'global', 'gzip_method', '1'), 
('sys', 'global', 'is_user_forum', '0'), 
('sys', 'global', 'authors_detail_main', '0'), 
('sys', 'global', 'spadmin_add_admin', '1'), 
('sys', 'global', 'openid_servers', ''), 
('sys', 'global', 'timestamp', '151'), 
('sys', 'global', 'openid_processing', '0'), 
('sys', 'global', 'captcha_type', '0'), 
('sys', 'global', 'version', '4.0.29'), 
('sys', 'global', 'whoviewuser', '2'), 
('sys', 'global', 'facebook_client_id', ''), 
('sys', 'global', 'facebook_client_secret', ''), 
('sys', 'global', 'google_client_id', ''), 
('sys', 'global', 'google_client_secret', ''), 
('sys', 'global', 'cookie_httponly', '1'), 
('sys', 'global', 'admin_check_pass_time', '1800'), 
('sys', 'global', 'user_check_pass_time', '1800'), 
('sys', 'global', 'auto_login_after_reg', '1'), 
('sys', 'global', 'cookie_secure', '0'), 
('sys', 'global', 'nv_unick_type', '4'), 
('sys', 'global', 'nv_upass_type', '2'), 
('sys', 'global', 'is_flood_blocker', '1'), 
('sys', 'global', 'max_requests_60', '40'), 
('sys', 'global', 'max_requests_300', '150'), 
('sys', 'global', 'nv_display_errors_list', '1'), 
('sys', 'global', 'display_errors_list', '1'), 
('sys', 'global', 'nv_auto_resize', '1'), 
('sys', 'global', 'dump_interval', '1'), 
('sys', 'global', 'cdn_url', ''), 
('sys', 'define', 'nv_unickmin', '4'), 
('sys', 'define', 'nv_unickmax', '20'), 
('sys', 'define', 'nv_upassmin', '8'), 
('sys', 'define', 'nv_upassmax', '20'), 
('sys', 'define', 'nv_gfx_num', '2'), 
('sys', 'define', 'nv_gfx_width', '50'), 
('sys', 'define', 'nv_gfx_height', '50'), 
('sys', 'define', 'nv_max_width', '1500'), 
('sys', 'define', 'nv_max_height', '1500'), 
('sys', 'define', 'nv_live_cookie_time', '31104000'), 
('sys', 'define', 'nv_live_session_time', '0'), 
('sys', 'define', 'nv_anti_iframe', '0'), 
('sys', 'define', 'nv_anti_agent', '0'), 
('sys', 'define', 'nv_allowed_html_tags', 'embed, object, param, a, b, blockquote, br, caption, col, colgroup, div, em, h1, h2, h3, h4, h5, h6, hr, i, img, li, p, span, strong, s, sub, sup, table, tbody, td, th, tr, u, ul, ol, iframe, figure, figcaption, video, audio, source, track, code, pre'), 
('sys', 'define', 'dir_forum', ''), 
('vi', 'global', 'site_domain', ''), 
('vi', 'global', 'site_name', 'ONE-interior'), 
('vi', 'global', 'site_logo', 'uploads/logo.png'), 
('vi', 'global', 'site_banner', ''), 
('vi', 'global', 'site_favicon', 'uploads/icon3.jpg'), 
('vi', 'global', 'site_description', 'Kiến trúc-Nội thất'), 
('vi', 'global', 'site_keywords', ''), 
('vi', 'global', 'theme_type', 'r'), 
('vi', 'global', 'site_theme', 'default'), 
('vi', 'global', 'mobile_theme', ''), 
('vi', 'global', 'site_home_module', 'news'), 
('vi', 'global', 'switch_mobi_des', '0'), 
('vi', 'global', 'upload_logo', ''), 
('vi', 'global', 'upload_logo_pos', 'bottomRight'), 
('vi', 'global', 'autologosize1', '50'), 
('vi', 'global', 'autologosize2', '40'), 
('vi', 'global', 'autologosize3', '30'), 
('vi', 'global', 'autologomod', ''), 
('vi', 'global', 'name_show', '0'), 
('vi', 'global', 'cronjobs_next_time', '1487341112'), 
('vi', 'global', 'disable_site_content', 'Vì lý do kỹ thuật website tạm ngưng hoạt động. Thành thật xin lỗi các bạn vì sự bất tiện này!'), 
('vi', 'global', 'ssl_https_modules', ''), 
('vi', 'seotools', 'prcservice', ''), 
('vi', 'about', 'auto_postcomm', '1'), 
('vi', 'about', 'allowed_comm', '-1'), 
('vi', 'about', 'view_comm', '6'), 
('vi', 'about', 'setcomm', '4'), 
('vi', 'about', 'activecomm', '0'), 
('vi', 'about', 'emailcomm', '0'), 
('vi', 'about', 'adminscomm', ''), 
('vi', 'about', 'sortcomm', '0'), 
('vi', 'about', 'captcha', '1'), 
('vi', 'news', 'indexfile', 'viewcat_main_right'), 
('vi', 'news', 'per_page', '20'), 
('vi', 'news', 'st_links', '10'), 
('vi', 'news', 'homewidth', '100'), 
('vi', 'news', 'homeheight', '150'), 
('vi', 'news', 'blockwidth', '70'), 
('vi', 'news', 'blockheight', '75'), 
('vi', 'news', 'imagefull', '460'), 
('vi', 'news', 'copyright', 'Chú ý: Việc đăng lại bài viết trên ở website hoặc các phương tiện truyền thông khác mà không ghi rõ nguồn http://nukeviet.vn là vi phạm bản quyền'), 
('vi', 'news', 'showtooltip', '1'), 
('vi', 'news', 'tooltip_position', 'bottom'), 
('vi', 'news', 'tooltip_length', '150'), 
('vi', 'news', 'showhometext', '1'), 
('vi', 'news', 'timecheckstatus', '0'), 
('vi', 'news', 'config_source', '0'), 
('vi', 'news', 'show_no_image', ''), 
('vi', 'news', 'allowed_rating_point', '1'), 
('vi', 'news', 'facebookappid', ''), 
('vi', 'news', 'socialbutton', '1'), 
('vi', 'news', 'alias_lower', '1'), 
('vi', 'news', 'tags_alias', '0'), 
('vi', 'news', 'auto_tags', '0'), 
('vi', 'news', 'tags_remind', '1'), 
('vi', 'news', 'structure_upload', 'Ym'), 
('vi', 'news', 'imgposition', '2'), 
('vi', 'news', 'auto_postcomm', '1'), 
('vi', 'news', 'allowed_comm', '-1'), 
('vi', 'news', 'view_comm', '6'), 
('vi', 'news', 'setcomm', '4'), 
('vi', 'news', 'activecomm', '1'), 
('vi', 'news', 'emailcomm', '0'), 
('vi', 'news', 'adminscomm', ''), 
('vi', 'news', 'sortcomm', '0'), 
('vi', 'news', 'captcha', '1'), 
('vi', 'page', 'auto_postcomm', '1'), 
('vi', 'page', 'allowed_comm', '-1'), 
('vi', 'page', 'view_comm', '6'), 
('vi', 'page', 'setcomm', '4'), 
('vi', 'page', 'activecomm', '0'), 
('vi', 'page', 'emailcomm', '0'), 
('vi', 'page', 'adminscomm', ''), 
('vi', 'page', 'sortcomm', '0'), 
('vi', 'page', 'captcha', '1'), 
('vi', 'siteterms', 'auto_postcomm', '1'), 
('vi', 'siteterms', 'allowed_comm', '-1'), 
('vi', 'siteterms', 'view_comm', '6'), 
('vi', 'siteterms', 'setcomm', '4'), 
('vi', 'siteterms', 'activecomm', '0'), 
('vi', 'siteterms', 'emailcomm', '0'), 
('vi', 'siteterms', 'adminscomm', ''), 
('vi', 'siteterms', 'sortcomm', '0'), 
('vi', 'siteterms', 'captcha', '1'), 
('vi', 'freecontent', 'next_execute', '0'), 
('vi', 'contact', 'bodytext', 'Để không ngừng nâng cao chất lượng dịch vụ và đáp ứng tốt hơn nữa các yêu cầu của Quý khách, chúng tôi mong muốn nhận được các thông tin phản hồi. Nếu Quý khách có bất kỳ thắc mắc hoặc đóng góp nào, xin vui lòng liên hệ với chúng tôi theo thông tin dưới đây. Chúng tôi sẽ phản hồi lại Quý khách trong thời gian sớm nhất.'), 
('sys', 'site', 'statistics_timezone', 'Asia/Bangkok'), 
('sys', 'site', 'site_email', 'vietnguyen@one-interior.vn'), 
('sys', 'global', 'error_set_logs', '1'), 
('sys', 'global', 'error_send_email', 'vietanhsolution@gmail.com'), 
('sys', 'global', 'site_lang', 'vi'), 
('sys', 'global', 'my_domains', 'localhost'), 
('sys', 'global', 'cookie_prefix', 'nv4c_z9750'), 
('sys', 'global', 'session_prefix', 'nv4s_g8SiK1'), 
('sys', 'global', 'site_timezone', 'byCountry'), 
('sys', 'global', 'proxy_blocker', '0'), 
('sys', 'global', 'str_referer_blocker', '0'), 
('sys', 'global', 'lang_multi', '0'), 
('sys', 'global', 'lang_geo', '0'), 
('sys', 'global', 'ftp_server', 'localhost'), 
('sys', 'global', 'ftp_port', '21'), 
('sys', 'global', 'ftp_user_name', ''), 
('sys', 'global', 'ftp_user_pass', 'AitLlWGtv33b5CaMvwoMTQIrS5Vhrb992-QmjL8KDE0,'), 
('sys', 'global', 'ftp_path', '/'), 
('sys', 'global', 'ftp_check_login', '0'), 
('vi', 'photos', 'origin_size_width', '1500'), 
('vi', 'photos', 'origin_size_height', '1500'), 
('vi', 'photos', 'cr_thumb_width', '640'), 
('vi', 'photos', 'cr_thumb_height', '400'), 
('vi', 'photos', 'cr_thumb_quality', '99'), 
('vi', 'photos', 'per_line', '4'), 
('vi', 'photos', 'home_view', 'home_view_grid_by_album'), 
('vi', 'photos', 'home_layout', 'main'), 
('vi', 'photos', 'album_view', 'album_view_grid'), 
('vi', 'photos', 'home_title_cut', '60'), 
('vi', 'photos', 'per_page_album', '8'), 
('vi', 'photos', 'per_page_photo', '30'), 
('vi', 'photos', 'social_tool', '1'), 
('vi', 'photos', 'fbappid', '0'), 
('vi', 'photos', 'structure_upload', 'Y_m'), 
('vi', 'photos', 'maxupload', '2097152'), 
('vi', 'photos', 'active_logo', '1'), 
('vi', 'photos', 'autologosize1', '30'), 
('vi', 'photos', 'autologosize2', '30'), 
('vi', 'photos', 'autologosize3', '30'), 
('vi', 'photos', 'module_logo', 'uploads/dau-anh.png'), 
('vi', 'photos', 'auto_postcomm', '1'), 
('vi', 'photos', 'allowed_comm', '-1'), 
('vi', 'photos', 'view_comm', '6'), 
('vi', 'photos', 'setcomm', '4'), 
('vi', 'photos', 'activecomm', '1'), 
('vi', 'photos', 'emailcomm', '0'), 
('vi', 'photos', 'adminscomm', ''), 
('vi', 'photos', 'sortcomm', '0'), 
('vi', 'photos', 'captcha', '1'), 
('vi', 'shops', 'image_size', '100x100'), 
('vi', 'shops', 'home_view', 'view_home_cat'), 
('vi', 'shops', 'per_page', '15'), 
('vi', 'shops', 'per_row', '3'), 
('vi', 'shops', 'money_unit', 'VND'), 
('vi', 'shops', 'weight_unit', 'g'), 
('vi', 'shops', 'post_auto_member', '0'), 
('vi', 'shops', 'auto_check_order', '0'), 
('vi', 'shops', 'format_order_id', 'S%06s'), 
('vi', 'shops', 'format_code_id', 'S%06s'), 
('vi', 'shops', 'facebookappid', ''), 
('vi', 'shops', 'active_guest_order', '1'), 
('vi', 'shops', 'active_showhomtext', '1'), 
('vi', 'shops', 'active_order', '1'), 
('vi', 'shops', 'active_order_popup', '1'), 
('vi', 'shops', 'active_order_non_detail', '1'), 
('vi', 'shops', 'active_price', '1'), 
('vi', 'shops', 'active_order_number', '0'), 
('vi', 'shops', 'order_day', '0'), 
('vi', 'shops', 'order_nexttime', '0'), 
('vi', 'shops', 'active_payment', '0'), 
('vi', 'shops', 'groups_price', '3'), 
('vi', 'shops', 'active_tooltip', '0'), 
('vi', 'shops', 'timecheckstatus', '0'), 
('vi', 'shops', 'show_product_code', '0'), 
('vi', 'shops', 'show_compare', '0'), 
('vi', 'shops', 'show_displays', '0'), 
('vi', 'shops', 'use_shipping', '0'), 
('vi', 'shops', 'use_coupons', '1'), 
('vi', 'shops', 'active_wishlist', '1'), 
('vi', 'shops', 'active_gift', '1'), 
('vi', 'shops', 'active_warehouse', '0'), 
('vi', 'shops', 'tags_alias', '0'), 
('vi', 'shops', 'auto_tags', '1'), 
('vi', 'shops', 'tags_remind', '0'), 
('vi', 'shops', 'point_active', '0'), 
('vi', 'shops', 'point_conversion', '0'), 
('vi', 'shops', 'point_new_order', '0'), 
('vi', 'shops', 'review_active', '1'), 
('vi', 'shops', 'review_check', '1'), 
('vi', 'shops', 'review_captcha', '1'), 
('vi', 'shops', 'group_price', ''), 
('vi', 'shops', 'groups_notify', '1'), 
('vi', 'shops', 'template_active', '1'), 
('vi', 'shops', 'download_active', '1'), 
('vi', 'shops', 'download_groups', '6'), 
('vi', 'shops', 'alias_lower', '1'), 
('vi', 'shops', 'auto_postcomm', '1'), 
('vi', 'shops', 'allowed_comm', '-1'), 
('vi', 'shops', 'view_comm', '6'), 
('vi', 'shops', 'setcomm', '4'), 
('vi', 'shops', 'activecomm', '1'), 
('vi', 'shops', 'emailcomm', '0'), 
('vi', 'shops', 'adminscomm', ''), 
('vi', 'shops', 'sortcomm', '0'), 
('vi', 'shops', 'captcha', '1');


-- ---------------------------------------


--
-- Table structure for table `az_cookies`
--

DROP TABLE IF EXISTS `az_cookies`;
CREATE TABLE `az_cookies` (
  `name` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `value` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `secure` tinyint(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `cookiename` (`name`,`domain`,`path`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_cookies`
--

INSERT INTO `az_cookies` VALUES
('nv4c_b1Spx_ctr', 'MTE2Xzk4XzFfMjUzLlZO', '.api.nukeviet.vn', '/', 1506832093, 0), 
('nv4c_b1Spx_u_lang', '3KI,', '.api.nukeviet.vn', '/', 1506400093, 0), 
('nv4c_b1Spx_statistic_vi', 'l21rmJmYZ2lsYg,,', '.api.nukeviet.vn', '/', 1475429170, 0);


-- ---------------------------------------


--
-- Table structure for table `az_counter`
--

DROP TABLE IF EXISTS `az_counter`;
CREATE TABLE `az_counter` (
  `c_type` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `c_val` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_update` int(11) NOT NULL DEFAULT '0',
  `c_count` int(11) unsigned NOT NULL DEFAULT '0',
  `vi_count` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `c_type` (`c_type`,`c_val`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_counter`
--

INSERT INTO `az_counter` VALUES
('c_time', 'start', 0, 0, 0), 
('c_time', 'last', 0, 1487340807, 0), 
('total', 'hits', 1487340807, 735, 735), 
('year', '2016', 1482850287, 423, 423), 
('year', '2017', 1487340807, 312, 312), 
('year', '2018', 0, 0, 0), 
('year', '2019', 0, 0, 0), 
('year', '2020', 0, 0, 0), 
('year', '2021', 0, 0, 0), 
('year', '2022', 0, 0, 0), 
('year', '2023', 0, 0, 0), 
('year', '2024', 0, 0, 0), 
('month', 'Jan', 1485164519, 4, 4), 
('month', 'Feb', 1487340807, 308, 308), 
('month', 'Mar', 0, 0, 0), 
('month', 'Apr', 0, 0, 0), 
('month', 'May', 0, 0, 0), 
('month', 'Jun', 0, 0, 0), 
('month', 'Jul', 0, 0, 0), 
('month', 'Aug', 0, 0, 0), 
('month', 'Sep', 0, 0, 0), 
('month', 'Oct', 1477898940, 0, 0), 
('month', 'Nov', 1480050917, 0, 0), 
('month', 'Dec', 1482850287, 0, 0), 
('day', '01', 1475325504, 0, 0), 
('day', '02', 1478066213, 0, 0), 
('day', '03', 1478149194, 0, 0), 
('day', '04', 0, 0, 0), 
('day', '05', 0, 0, 0), 
('day', '06', 0, 0, 0), 
('day', '07', 1475836528, 0, 0), 
('day', '08', 0, 0, 0), 
('day', '09', 1486655899, 17, 17), 
('day', '10', 1486740220, 8, 8), 
('day', '11', 1486831455, 137, 137), 
('day', '12', 1486911734, 13, 13), 
('day', '13', 1486997755, 41, 41), 
('day', '14', 1487087246, 36, 36), 
('day', '15', 1487175381, 21, 21), 
('day', '16', 1487257315, 17, 17), 
('day', '17', 1487340807, 18, 18), 
('day', '18', 1479429285, 0, 0), 
('day', '19', 1479547443, 0, 0), 
('day', '20', 1476971661, 0, 0), 
('day', '21', 1484947991, 0, 0), 
('day', '22', 1477152076, 0, 0), 
('day', '23', 1485164519, 0, 0), 
('day', '24', 1477323695, 0, 0), 
('day', '25', 1480050917, 0, 0), 
('day', '26', 1477497025, 0, 0), 
('day', '27', 1482850287, 0, 0), 
('day', '28', 1477673931, 0, 0), 
('day', '29', 1477725442, 0, 0), 
('day', '30', 1477845730, 0, 0), 
('day', '31', 1477898940, 0, 0), 
('dayofweek', 'Sunday', 1486911734, 86, 86), 
('dayofweek', 'Monday', 1486997755, 86, 86), 
('dayofweek', 'Tuesday', 1487087246, 80, 80), 
('dayofweek', 'Wednesday', 1487175381, 73, 73), 
('dayofweek', 'Thursday', 1487257315, 98, 98), 
('dayofweek', 'Friday', 1487340807, 112, 112), 
('dayofweek', 'Saturday', 1486831455, 200, 200), 
('hour', '00', 1487181369, 0, 0), 
('hour', '01', 1487010914, 0, 0), 
('hour', '02', 1487273252, 1, 1), 
('hour', '03', 1487105433, 0, 0), 
('hour', '04', 1487281691, 2, 2), 
('hour', '05', 1487197497, 0, 0), 
('hour', '06', 1487289288, 1, 1), 
('hour', '07', 1486685815, 0, 0), 
('hour', '08', 1487295260, 9, 9), 
('hour', '09', 1487297847, 1, 1), 
('hour', '10', 1487303737, 1, 1), 
('hour', '11', 1487134112, 0, 0), 
('hour', '12', 1487137263, 0, 0), 
('hour', '13', 1487055415, 0, 0), 
('hour', '14', 1487315194, 1, 1), 
('hour', '15', 1487059963, 0, 0), 
('hour', '16', 1487236606, 0, 0), 
('hour', '17', 1487328210, 1, 1), 
('hour', '18', 1486984772, 0, 0), 
('hour', '19', 1487073616, 0, 0), 
('hour', '20', 1487252193, 0, 0), 
('hour', '21', 1487340807, 1, 1), 
('hour', '22', 1487257315, 0, 0), 
('hour', '23', 1487175381, 0, 0), 
('bot', 'googlebot', 1487328210, 227, 227), 
('bot', 'msnbot', 0, 0, 0), 
('bot', 'bingbot', 0, 0, 0), 
('bot', 'yahooslurp', 0, 0, 0), 
('bot', 'w3cvalidator', 0, 0, 0), 
('browser', 'opera', 0, 0, 0), 
('browser', 'operamini', 0, 0, 0), 
('browser', 'webtv', 0, 0, 0), 
('browser', 'explorer', 1481779890, 2, 2), 
('browser', 'edge', 1478756753, 2, 2), 
('browser', 'pocket', 0, 0, 0), 
('browser', 'konqueror', 0, 0, 0), 
('browser', 'icab', 0, 0, 0), 
('browser', 'omniweb', 0, 0, 0), 
('browser', 'firebird', 0, 0, 0), 
('browser', 'firefox', 1476679119, 1, 1), 
('browser', 'iceweasel', 0, 0, 0), 
('browser', 'shiretoko', 0, 0, 0), 
('browser', 'mozilla', 1487295260, 62, 62), 
('browser', 'amaya', 0, 0, 0), 
('browser', 'lynx', 0, 0, 0), 
('browser', 'safari', 1479877368, 19, 19), 
('browser', 'iphone', 1478835227, 7, 7), 
('browser', 'ipod', 0, 0, 0), 
('browser', 'ipad', 0, 0, 0), 
('browser', 'chrome', 1487340807, 331, 331), 
('browser', 'cococ', 0, 0, 0), 
('browser', 'android', 1476541137, 1, 1), 
('browser', 'googlebot', 1487328210, 227, 227), 
('browser', 'yahooslurp', 0, 0, 0), 
('browser', 'w3cvalidator', 0, 0, 0), 
('browser', 'blackberry', 0, 0, 0), 
('browser', 'icecat', 0, 0, 0), 
('browser', 'nokias60', 0, 0, 0), 
('browser', 'nokia', 0, 0, 0), 
('browser', 'msn', 0, 0, 0), 
('browser', 'msnbot', 0, 0, 0), 
('browser', 'bingbot', 0, 0, 0), 
('browser', 'netscape', 0, 0, 0), 
('browser', 'galeon', 0, 0, 0), 
('browser', 'netpositive', 0, 0, 0), 
('browser', 'phoenix', 0, 0, 0), 
('browser', 'Mobile', 0, 0, 0), 
('browser', 'bots', 0, 0, 0), 
('browser', 'Unknown', 1486827912, 56, 56), 
('os', 'unknown', 1487328210, 364, 364), 
('os', 'win', 1478756753, 1, 1), 
('os', 'win10', 1478751502, 99, 99), 
('os', 'win8', 1487340807, 73, 73), 
('os', 'win7', 1486607075, 117, 117), 
('os', 'win2003', 0, 0, 0), 
('os', 'winvista', 0, 0, 0), 
('os', 'wince', 0, 0, 0), 
('os', 'winxp', 1481779890, 1, 1), 
('os', 'win2000', 0, 0, 0), 
('os', 'apple', 1485164519, 4, 4), 
('os', 'linux', 1481788912, 17, 17), 
('os', 'os2', 0, 0, 0), 
('os', 'beos', 0, 0, 0), 
('os', 'iphone', 1478835227, 8, 8), 
('os', 'ipod', 0, 0, 0), 
('os', 'ipad', 0, 0, 0), 
('os', 'blackberry', 0, 0, 0), 
('os', 'nokia', 0, 0, 0), 
('os', 'freebsd', 0, 0, 0), 
('os', 'openbsd', 0, 0, 0), 
('os', 'netbsd', 0, 0, 0), 
('os', 'sunos', 0, 0, 0), 
('os', 'opensolaris', 0, 0, 0), 
('os', 'android', 1486655899, 51, 51), 
('os', 'irix', 0, 0, 0), 
('os', 'palm', 0, 0, 0), 
('country', 'AD', 0, 0, 0), 
('country', 'AE', 0, 0, 0), 
('country', 'AF', 0, 0, 0), 
('country', 'AG', 0, 0, 0), 
('country', 'AI', 0, 0, 0), 
('country', 'AL', 0, 0, 0), 
('country', 'AM', 0, 0, 0), 
('country', 'AN', 0, 0, 0), 
('country', 'AO', 0, 0, 0), 
('country', 'AQ', 0, 0, 0), 
('country', 'AR', 0, 0, 0), 
('country', 'AS', 0, 0, 0), 
('country', 'AT', 0, 0, 0), 
('country', 'AU', 0, 0, 0), 
('country', 'AW', 0, 0, 0), 
('country', 'AZ', 0, 0, 0), 
('country', 'BA', 0, 0, 0), 
('country', 'BB', 0, 0, 0), 
('country', 'BD', 0, 0, 0), 
('country', 'BE', 0, 0, 0), 
('country', 'BF', 0, 0, 0), 
('country', 'BG', 0, 0, 0), 
('country', 'BH', 0, 0, 0), 
('country', 'BI', 0, 0, 0), 
('country', 'BJ', 0, 0, 0), 
('country', 'BM', 0, 0, 0), 
('country', 'BN', 0, 0, 0), 
('country', 'BO', 0, 0, 0), 
('country', 'BR', 0, 0, 0), 
('country', 'BS', 0, 0, 0), 
('country', 'BT', 0, 0, 0), 
('country', 'BW', 0, 0, 0), 
('country', 'BY', 0, 0, 0), 
('country', 'BZ', 0, 0, 0), 
('country', 'CA', 0, 0, 0), 
('country', 'CD', 0, 0, 0), 
('country', 'CF', 0, 0, 0), 
('country', 'CG', 0, 0, 0), 
('country', 'CH', 0, 0, 0), 
('country', 'CI', 0, 0, 0), 
('country', 'CK', 0, 0, 0), 
('country', 'CL', 0, 0, 0), 
('country', 'CM', 0, 0, 0), 
('country', 'CN', 0, 0, 0), 
('country', 'CO', 0, 0, 0), 
('country', 'CR', 0, 0, 0), 
('country', 'CS', 0, 0, 0), 
('country', 'CU', 0, 0, 0), 
('country', 'CV', 0, 0, 0), 
('country', 'CY', 0, 0, 0), 
('country', 'CZ', 0, 0, 0), 
('country', 'DE', 0, 0, 0), 
('country', 'DJ', 0, 0, 0), 
('country', 'DK', 0, 0, 0), 
('country', 'DM', 0, 0, 0), 
('country', 'DO', 0, 0, 0), 
('country', 'DZ', 0, 0, 0), 
('country', 'EC', 0, 0, 0), 
('country', 'EE', 1484221081, 1, 1), 
('country', 'EG', 0, 0, 0), 
('country', 'ER', 0, 0, 0), 
('country', 'ES', 0, 0, 0), 
('country', 'ET', 0, 0, 0), 
('country', 'EU', 0, 0, 0), 
('country', 'FI', 0, 0, 0), 
('country', 'FJ', 0, 0, 0), 
('country', 'FK', 0, 0, 0), 
('country', 'FM', 0, 0, 0), 
('country', 'FO', 0, 0, 0), 
('country', 'FR', 0, 0, 0), 
('country', 'GA', 0, 0, 0), 
('country', 'GB', 0, 0, 0), 
('country', 'GD', 0, 0, 0), 
('country', 'GE', 0, 0, 0), 
('country', 'GF', 0, 0, 0), 
('country', 'GH', 0, 0, 0), 
('country', 'GI', 0, 0, 0), 
('country', 'GL', 0, 0, 0), 
('country', 'GM', 0, 0, 0), 
('country', 'GN', 0, 0, 0), 
('country', 'GP', 0, 0, 0), 
('country', 'GQ', 0, 0, 0), 
('country', 'GR', 0, 0, 0), 
('country', 'GS', 0, 0, 0), 
('country', 'GT', 0, 0, 0), 
('country', 'GU', 0, 0, 0), 
('country', 'GW', 0, 0, 0), 
('country', 'GY', 0, 0, 0), 
('country', 'HK', 0, 0, 0), 
('country', 'HN', 0, 0, 0), 
('country', 'HR', 0, 0, 0), 
('country', 'HT', 0, 0, 0), 
('country', 'HU', 0, 0, 0), 
('country', 'ID', 0, 0, 0), 
('country', 'IE', 0, 0, 0), 
('country', 'IL', 0, 0, 0), 
('country', 'IN', 0, 0, 0), 
('country', 'IO', 0, 0, 0), 
('country', 'IQ', 0, 0, 0), 
('country', 'IR', 0, 0, 0), 
('country', 'IS', 0, 0, 0), 
('country', 'IT', 0, 0, 0), 
('country', 'JM', 0, 0, 0), 
('country', 'JO', 0, 0, 0), 
('country', 'JP', 1481779890, 1, 1), 
('country', 'KE', 0, 0, 0), 
('country', 'KG', 0, 0, 0), 
('country', 'KH', 0, 0, 0), 
('country', 'KI', 0, 0, 0), 
('country', 'KM', 0, 0, 0), 
('country', 'KN', 0, 0, 0), 
('country', 'KR', 0, 0, 0), 
('country', 'KW', 0, 0, 0), 
('country', 'KY', 0, 0, 0), 
('country', 'KZ', 0, 0, 0), 
('country', 'LA', 0, 0, 0), 
('country', 'LB', 0, 0, 0), 
('country', 'LC', 0, 0, 0), 
('country', 'LI', 0, 0, 0), 
('country', 'LK', 0, 0, 0), 
('country', 'LR', 0, 0, 0), 
('country', 'LS', 0, 0, 0), 
('country', 'LT', 0, 0, 0), 
('country', 'LU', 0, 0, 0), 
('country', 'LV', 0, 0, 0), 
('country', 'LY', 0, 0, 0), 
('country', 'MA', 0, 0, 0), 
('country', 'MC', 0, 0, 0), 
('country', 'MD', 0, 0, 0), 
('country', 'MG', 0, 0, 0), 
('country', 'MH', 0, 0, 0), 
('country', 'MK', 0, 0, 0), 
('country', 'ML', 0, 0, 0), 
('country', 'MM', 0, 0, 0), 
('country', 'MN', 0, 0, 0), 
('country', 'MO', 0, 0, 0), 
('country', 'MP', 0, 0, 0), 
('country', 'MQ', 0, 0, 0), 
('country', 'MR', 0, 0, 0), 
('country', 'MT', 0, 0, 0), 
('country', 'MU', 0, 0, 0), 
('country', 'MV', 0, 0, 0), 
('country', 'MW', 0, 0, 0), 
('country', 'MX', 0, 0, 0), 
('country', 'MY', 0, 0, 0), 
('country', 'MZ', 0, 0, 0), 
('country', 'NA', 0, 0, 0), 
('country', 'NC', 0, 0, 0), 
('country', 'NE', 0, 0, 0), 
('country', 'NF', 0, 0, 0), 
('country', 'NG', 0, 0, 0), 
('country', 'NI', 0, 0, 0), 
('country', 'NL', 0, 0, 0), 
('country', 'NO', 0, 0, 0), 
('country', 'NP', 0, 0, 0), 
('country', 'NR', 0, 0, 0), 
('country', 'NU', 0, 0, 0), 
('country', 'NZ', 0, 0, 0), 
('country', 'OM', 0, 0, 0), 
('country', 'PA', 0, 0, 0), 
('country', 'PE', 0, 0, 0), 
('country', 'PF', 0, 0, 0), 
('country', 'PG', 0, 0, 0), 
('country', 'PH', 0, 0, 0), 
('country', 'PK', 0, 0, 0), 
('country', 'PL', 0, 0, 0), 
('country', 'PR', 0, 0, 0), 
('country', 'PS', 0, 0, 0), 
('country', 'PT', 0, 0, 0), 
('country', 'PW', 0, 0, 0), 
('country', 'PY', 0, 0, 0), 
('country', 'QA', 0, 0, 0), 
('country', 'RE', 0, 0, 0), 
('country', 'RO', 0, 0, 0), 
('country', 'RU', 0, 0, 0), 
('country', 'RW', 0, 0, 0), 
('country', 'SA', 0, 0, 0), 
('country', 'SB', 0, 0, 0), 
('country', 'SC', 0, 0, 0), 
('country', 'SD', 0, 0, 0), 
('country', 'SE', 0, 0, 0), 
('country', 'SG', 0, 0, 0), 
('country', 'SI', 0, 0, 0), 
('country', 'SK', 0, 0, 0), 
('country', 'SL', 0, 0, 0), 
('country', 'SM', 0, 0, 0), 
('country', 'SN', 0, 0, 0), 
('country', 'SO', 0, 0, 0), 
('country', 'SR', 0, 0, 0), 
('country', 'ST', 0, 0, 0), 
('country', 'SV', 0, 0, 0), 
('country', 'SY', 0, 0, 0), 
('country', 'SZ', 0, 0, 0), 
('country', 'TD', 0, 0, 0), 
('country', 'TF', 0, 0, 0), 
('country', 'TG', 0, 0, 0), 
('country', 'TH', 0, 0, 0), 
('country', 'TJ', 0, 0, 0), 
('country', 'TK', 0, 0, 0), 
('country', 'TL', 0, 0, 0), 
('country', 'TM', 0, 0, 0), 
('country', 'TN', 0, 0, 0), 
('country', 'TO', 0, 0, 0), 
('country', 'TR', 0, 0, 0), 
('country', 'TT', 0, 0, 0), 
('country', 'TV', 0, 0, 0), 
('country', 'TW', 0, 0, 0), 
('country', 'TZ', 0, 0, 0), 
('country', 'UA', 0, 0, 0), 
('country', 'UG', 0, 0, 0), 
('country', 'US', 1487328210, 286, 286), 
('country', 'UY', 0, 0, 0), 
('country', 'UZ', 0, 0, 0), 
('country', 'VA', 0, 0, 0), 
('country', 'VC', 0, 0, 0), 
('country', 'VE', 0, 0, 0), 
('country', 'VG', 0, 0, 0), 
('country', 'VI', 0, 0, 0), 
('country', 'VN', 1487340807, 347, 347), 
('country', 'VU', 0, 0, 0), 
('country', 'WS', 0, 0, 0), 
('country', 'YE', 0, 0, 0), 
('country', 'YT', 0, 0, 0), 
('country', 'YU', 0, 0, 0), 
('country', 'ZA', 0, 0, 0), 
('country', 'ZM', 0, 0, 0), 
('country', 'ZW', 0, 0, 0), 
('country', 'ZZ', 1485164515, 100, 100), 
('country', 'unkown', 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `az_cronjobs`
--

DROP TABLE IF EXISTS `az_cronjobs`;
CREATE TABLE `az_cronjobs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `start_time` int(11) unsigned NOT NULL DEFAULT '0',
  `inter_val` int(11) unsigned NOT NULL DEFAULT '0',
  `run_file` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_func` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `params` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `last_time` int(11) unsigned NOT NULL DEFAULT '0',
  `last_result` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vi_cron_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `is_sys` (`is_sys`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_cronjobs`
--

INSERT INTO `az_cronjobs` VALUES
(1, 1475277519, 5, 'online_expired_del.php', 'cron_online_expired_del', '', 0, 1, 1, 1487340812, 1, 'Xóa các dòng ghi trạng thái online đã cũ trong CSDL'), 
(2, 1475277519, 1440, 'dump_autobackup.php', 'cron_dump_autobackup', '', 0, 1, 1, 1486827066, 1, 'Tự động lưu CSDL'), 
(3, 1475277519, 60, 'temp_download_destroy.php', 'cron_auto_del_temp_download', '', 0, 1, 1, 1486827066, 1, 'Xóa các file tạm trong thư mục tmp'), 
(4, 1475277519, 30, 'ip_logs_destroy.php', 'cron_del_ip_logs', '', 0, 1, 1, 1486827066, 1, 'Xóa IP log files, Xóa các file nhật ký truy cập'), 
(5, 1475277519, 1440, 'error_log_destroy.php', 'cron_auto_del_error_log', '', 0, 1, 1, 1486827066, 1, 'Xóa các file error_log quá hạn'), 
(6, 1475277519, 360, 'error_log_sendmail.php', 'cron_auto_sendmail_error_log', '', 0, 1, 0, 0, 0, 'Gửi email các thông báo lỗi cho admin'), 
(7, 1475277519, 60, 'ref_expired_del.php', 'cron_ref_expired_del', '', 0, 1, 1, 1486827066, 1, 'Xóa các referer quá hạn'), 
(8, 1475277519, 60, 'check_version.php', 'cron_auto_check_version', '', 0, 1, 1, 1486827066, 1, 'Kiểm tra phiên bản NukeViet'), 
(9, 1475277519, 1440, 'notification_autodel.php', 'cron_notification_autodel', '', 0, 1, 1, 1486827066, 1, 'Xóa thông báo cũ');


-- ---------------------------------------


--
-- Table structure for table `az_extension_files`
--

DROP TABLE IF EXISTS `az_extension_files`;
CREATE TABLE `az_extension_files` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `path` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lastmodified` int(11) unsigned NOT NULL DEFAULT '0',
  `duplicate` smallint(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`idfile`)
) ENGINE=MyISAM  AUTO_INCREMENT=299  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_extension_files`
--

INSERT INTO `az_extension_files` VALUES
(1, 'module', 'shops', 'themes/admin_default/css/shops.css', 1475427381, 1), 
(2, 'module', 'shops', 'themes/admin_default/js/content.js', 1475427381, 0), 
(3, 'module', 'shops', 'themes/admin_default/js/shops.js', 1475427381, 0), 
(4, 'module', 'shops', 'themes/admin_default/modules/shops/.htaccess', 1475427381, 0), 
(5, 'module', 'shops', 'themes/admin_default/modules/shops/block.tpl', 1475427381, 0), 
(6, 'module', 'shops', 'themes/admin_default/modules/shops/blockcat.tpl', 1475427381, 0), 
(7, 'module', 'shops', 'themes/admin_default/modules/shops/block_cat_list.tpl', 1475427381, 0), 
(8, 'module', 'shops', 'themes/admin_default/modules/shops/block_list.tpl', 1475427381, 0), 
(9, 'module', 'shops', 'themes/admin_default/modules/shops/carrier.tpl', 1475427381, 0), 
(10, 'module', 'shops', 'themes/admin_default/modules/shops/carrier_config.tpl', 1475427381, 0), 
(11, 'module', 'shops', 'themes/admin_default/modules/shops/carrier_config_items.tpl', 1475427381, 0), 
(12, 'module', 'shops', 'themes/admin_default/modules/shops/cat_add.tpl', 1475427381, 0), 
(13, 'module', 'shops', 'themes/admin_default/modules/shops/cat_delete.tpl', 1475427381, 0), 
(14, 'module', 'shops', 'themes/admin_default/modules/shops/cat_lists.tpl', 1475427381, 0), 
(15, 'module', 'shops', 'themes/admin_default/modules/shops/content.tpl', 1475427381, 0), 
(16, 'module', 'shops', 'themes/admin_default/modules/shops/coupons.tpl', 1475427381, 0), 
(17, 'module', 'shops', 'themes/admin_default/modules/shops/coupons_view.tpl', 1475427381, 0), 
(18, 'module', 'shops', 'themes/admin_default/modules/shops/discounts.tpl', 1475427381, 0), 
(19, 'module', 'shops', 'themes/admin_default/modules/shops/docpay.tpl', 1475427381, 0), 
(20, 'module', 'shops', 'themes/admin_default/modules/shops/download.tpl', 1475427381, 0), 
(21, 'module', 'shops', 'themes/admin_default/modules/shops/email_new_order_payment.tpl', 1475427381, 0), 
(22, 'module', 'shops', 'themes/admin_default/modules/shops/fields.tpl', 1475427381, 0), 
(23, 'module', 'shops', 'themes/admin_default/modules/shops/field_tab.tpl', 1475427381, 0), 
(24, 'module', 'shops', 'themes/admin_default/modules/shops/getprice.tpl', 1475427381, 0), 
(25, 'module', 'shops', 'themes/admin_default/modules/shops/group_add.tpl', 1475427381, 0), 
(26, 'module', 'shops', 'themes/admin_default/modules/shops/group_delete.tpl', 1475427381, 0), 
(27, 'module', 'shops', 'themes/admin_default/modules/shops/group_lists.tpl', 1475427381, 0), 
(28, 'module', 'shops', 'themes/admin_default/modules/shops/index.html', 1475427381, 0), 
(29, 'module', 'shops', 'themes/admin_default/modules/shops/items.tpl', 1475427381, 0), 
(30, 'module', 'shops', 'themes/admin_default/modules/shops/location.tpl', 1475427381, 0), 
(31, 'module', 'shops', 'themes/admin_default/modules/shops/location_lists.tpl', 1475427381, 0), 
(32, 'module', 'shops', 'themes/admin_default/modules/shops/main.tpl', 1475427381, 0), 
(33, 'module', 'shops', 'themes/admin_default/modules/shops/money.tpl', 1475427381, 0), 
(34, 'module', 'shops', 'themes/admin_default/modules/shops/order.tpl', 1475427381, 0), 
(35, 'module', 'shops', 'themes/admin_default/modules/shops/order_seller.tpl', 1475427381, 0), 
(36, 'module', 'shops', 'themes/admin_default/modules/shops/or_view.tpl', 1475427381, 0), 
(37, 'module', 'shops', 'themes/admin_default/modules/shops/payport.tpl', 1475427381, 0), 
(38, 'module', 'shops', 'themes/admin_default/modules/shops/point.tpl', 1475427381, 0), 
(39, 'module', 'shops', 'themes/admin_default/modules/shops/print.tpl', 1475427381, 0), 
(40, 'module', 'shops', 'themes/admin_default/modules/shops/prounit.tpl', 1475427381, 0), 
(41, 'module', 'shops', 'themes/admin_default/modules/shops/review.tpl', 1475427381, 0), 
(42, 'module', 'shops', 'themes/admin_default/modules/shops/seller.tpl', 1475427381, 0), 
(43, 'module', 'shops', 'themes/admin_default/modules/shops/setting.tpl', 1475427381, 0), 
(44, 'module', 'shops', 'themes/admin_default/modules/shops/shipping.tpl', 1475427381, 0), 
(45, 'module', 'shops', 'themes/admin_default/modules/shops/shipping_menu.tpl', 1475427381, 0), 
(46, 'module', 'shops', 'themes/admin_default/modules/shops/shops.tpl', 1475427381, 0), 
(47, 'module', 'shops', 'themes/admin_default/modules/shops/tabs.tpl', 1475427381, 0), 
(48, 'module', 'shops', 'themes/admin_default/modules/shops/tags.tpl', 1475427381, 0), 
(49, 'module', 'shops', 'themes/admin_default/modules/shops/tags_lists.tpl', 1475427381, 0), 
(50, 'module', 'shops', 'themes/admin_default/modules/shops/template.tpl', 1475427381, 0), 
(51, 'module', 'shops', 'themes/admin_default/modules/shops/topics.tpl', 1475427381, 0), 
(52, 'module', 'shops', 'themes/admin_default/modules/shops/updateprice.tpl', 1475427381, 0), 
(53, 'module', 'shops', 'themes/admin_default/modules/shops/warehouse.tpl', 1475427381, 0), 
(54, 'module', 'shops', 'themes/admin_default/modules/shops/warehouse_logs.tpl', 1475427381, 0), 
(55, 'module', 'shops', 'themes/admin_default/modules/shops/weight.tpl', 1475427381, 0), 
(56, 'module', 'shops', 'themes/default/css/jquery.bxslider.css', 1475427381, 0), 
(57, 'module', 'shops', 'themes/default/css/shops.css', 1475427381, 0), 
(58, 'module', 'shops', 'themes/default/images/shops/24x24-no.png', 1475427381, 0), 
(59, 'module', 'shops', 'themes/default/images/shops/access_head_bg.png', 1475427381, 0), 
(60, 'module', 'shops', 'themes/default/images/shops/ajax-loader.gif', 1475427381, 0), 
(61, 'module', 'shops', 'themes/default/images/shops/bgbt.png', 1475427381, 0), 
(62, 'module', 'shops', 'themes/default/images/shops/bg_divtab.png', 1475427381, 0), 
(63, 'module', 'shops', 'themes/default/images/shops/bl.png', 1475427381, 0), 
(64, 'module', 'shops', 'themes/default/images/shops/br.png', 1475427381, 0), 
(65, 'module', 'shops', 'themes/default/images/shops/buzz.png', 1475427381, 0), 
(66, 'module', 'shops', 'themes/default/images/shops/controls.png', 1475427381, 0), 
(67, 'module', 'shops', 'themes/default/images/shops/flickr.png', 1475427381, 0), 
(68, 'module', 'shops', 'themes/default/images/shops/google.png', 1475427381, 0), 
(69, 'module', 'shops', 'themes/default/images/shops/icon_files/doc.png', 1475427381, 0), 
(70, 'module', 'shops', 'themes/default/images/shops/icon_files/document.png', 1475427381, 0), 
(71, 'module', 'shops', 'themes/default/images/shops/icon_files/docx.png', 1475427381, 0), 
(72, 'module', 'shops', 'themes/default/images/shops/icon_files/odt.png', 1475427381, 0), 
(73, 'module', 'shops', 'themes/default/images/shops/icon_files/pdf.png', 1475427381, 0), 
(74, 'module', 'shops', 'themes/default/images/shops/icon_files/ppt.png', 1475427381, 0), 
(75, 'module', 'shops', 'themes/default/images/shops/icon_files/pptx.png', 1475427381, 0), 
(76, 'module', 'shops', 'themes/default/images/shops/icon_files/rar.png', 1475427381, 0), 
(77, 'module', 'shops', 'themes/default/images/shops/icon_files/xsl.png', 1475427381, 0), 
(78, 'module', 'shops', 'themes/default/images/shops/icon_files/xslx.png', 1475427381, 0), 
(79, 'module', 'shops', 'themes/default/images/shops/icon_files/zip.png', 1475427381, 0), 
(80, 'module', 'shops', 'themes/default/images/shops/index.html', 1475427381, 0), 
(81, 'module', 'shops', 'themes/default/images/shops/no-image.jpg', 1475427381, 0), 
(82, 'module', 'shops', 'themes/default/images/shops/previous-next.png', 1475427381, 0), 
(83, 'module', 'shops', 'themes/default/images/shops/print.png', 1475427381, 0), 
(84, 'module', 'shops', 'themes/default/images/shops/pro_cat_header.png', 1475427381, 0), 
(85, 'module', 'shops', 'themes/default/images/shops/pro_tab.png', 1475427381, 0), 
(86, 'module', 'shops', 'themes/default/images/shops/rate/rate-btn2-hover.png', 1475427381, 0), 
(87, 'module', 'shops', 'themes/default/images/shops/rate/rate-btn2.png', 1475427381, 0), 
(88, 'module', 'shops', 'themes/default/images/shops/rate/rate-btn3-hover.png', 1475427381, 0), 
(89, 'module', 'shops', 'themes/default/images/shops/rate/rate-stars.png', 1475427381, 0), 
(90, 'module', 'shops', 'themes/default/images/shops/square.jpg', 1475427381, 0), 
(91, 'module', 'shops', 'themes/default/images/shops/star-png.png', 1475427381, 0), 
(92, 'module', 'shops', 'themes/default/images/shops/star.png', 1475427381, 0), 
(93, 'module', 'shops', 'themes/default/images/shops/twitter.png', 1475427381, 0), 
(94, 'module', 'shops', 'themes/default/images/shops/zoom-img.png', 1475427381, 0), 
(95, 'module', 'shops', 'themes/default/js/jquery.bxslider.min.js', 1475427381, 0), 
(96, 'module', 'shops', 'themes/default/js/responsiveCarousel.min.js', 1475427381, 0), 
(97, 'module', 'shops', 'themes/default/js/shops.js', 1475427381, 0), 
(98, 'module', 'shops', 'themes/default/modules/shops/.htaccess', 1475427381, 0), 
(99, 'module', 'shops', 'themes/default/modules/shops/block.bxproduct_center.tpl', 1475427381, 0), 
(100, 'module', 'shops', 'themes/default/modules/shops/block.cart.tpl', 1475427381, 0), 
(101, 'module', 'shops', 'themes/default/modules/shops/block.catalogsv.tpl', 1475427381, 0), 
(102, 'module', 'shops', 'themes/default/modules/shops/block.filter_product.tpl', 1475427381, 0), 
(103, 'module', 'shops', 'themes/default/modules/shops/block.filter_product_cat.tpl', 1475427381, 0), 
(104, 'module', 'shops', 'themes/default/modules/shops/block.others_product.tpl', 1475427381, 0), 
(105, 'module', 'shops', 'themes/default/modules/shops/block.price_view.tpl', 1475427381, 0), 
(106, 'module', 'shops', 'themes/default/modules/shops/block.product_center.tpl', 1475427381, 0), 
(107, 'module', 'shops', 'themes/default/modules/shops/block.search.tpl', 1475427381, 0), 
(108, 'module', 'shops', 'themes/default/modules/shops/blockcat.tpl', 1475427381, 0), 
(109, 'module', 'shops', 'themes/default/modules/shops/cart.tpl', 1475427381, 0), 
(110, 'module', 'shops', 'themes/default/modules/shops/compare.tpl', 1475427381, 0), 
(111, 'module', 'shops', 'themes/default/modules/shops/coupons_info.tpl', 1475427381, 0), 
(112, 'module', 'shops', 'themes/default/modules/shops/detail.tpl', 1475427381, 0), 
(113, 'module', 'shops', 'themes/default/modules/shops/download_content.tpl', 1475427381, 0), 
(114, 'module', 'shops', 'themes/default/modules/shops/email_new_order.tpl', 1475427381, 0), 
(115, 'module', 'shops', 'themes/default/modules/shops/history_order.tpl', 1475427381, 0), 
(116, 'module', 'shops', 'themes/default/modules/shops/index.html', 1475427381, 0), 
(117, 'module', 'shops', 'themes/default/modules/shops/main_procate.tpl', 1475427381, 0), 
(118, 'module', 'shops', 'themes/default/modules/shops/main_product.tpl', 1475427381, 0), 
(119, 'module', 'shops', 'themes/default/modules/shops/order.tpl', 1475427381, 0), 
(120, 'module', 'shops', 'themes/default/modules/shops/othersimg.tpl', 1475427381, 0), 
(121, 'module', 'shops', 'themes/default/modules/shops/payment.tpl', 1475427381, 0), 
(122, 'module', 'shops', 'themes/default/modules/shops/point.tpl', 1475427381, 0), 
(123, 'module', 'shops', 'themes/default/modules/shops/print.tpl', 1475427381, 0), 
(124, 'module', 'shops', 'themes/default/modules/shops/print_pro.tpl', 1475427381, 0), 
(125, 'module', 'shops', 'themes/default/modules/shops/review_content.tpl', 1475427381, 0), 
(126, 'module', 'shops', 'themes/default/modules/shops/review_list.tpl', 1475427381, 0), 
(127, 'module', 'shops', 'themes/default/modules/shops/search.tpl', 1475427381, 0), 
(128, 'module', 'shops', 'themes/default/modules/shops/search_all.tpl', 1475427381, 0), 
(129, 'module', 'shops', 'themes/default/modules/shops/view_gird.tpl', 1475427381, 0), 
(130, 'module', 'shops', 'themes/default/modules/shops/view_list.tpl', 1475427381, 0), 
(131, 'module', 'shops', 'themes/default/modules/shops/wishlist.tpl', 1475427381, 0), 
(132, 'module', 'shops', 'uploads/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1475427381, 0), 
(133, 'module', 'shops', 'assets/shops/2015_05/giay-bup-be-ngoi-sao-nhap-khau.jpg', 1475427381, 0), 
(134, 'module', 'shops', 'modules/shops/action_mysql.php', 1475427381, 0), 
(135, 'module', 'shops', 'modules/shops/admin/.htaccess', 1475427381, 0), 
(136, 'module', 'shops', 'modules/shops/admin/active_pay.php', 1475427381, 0), 
(137, 'module', 'shops', 'modules/shops/admin/actpay.php', 1475427381, 0), 
(138, 'module', 'shops', 'modules/shops/admin/alias.php', 1475427381, 0), 
(139, 'module', 'shops', 'modules/shops/admin/block.php', 1475427381, 0), 
(140, 'module', 'shops', 'modules/shops/admin/blockcat.php', 1475427381, 0), 
(141, 'module', 'shops', 'modules/shops/admin/carrier.php', 1475427381, 0), 
(142, 'module', 'shops', 'modules/shops/admin/carrier_config.php', 1475427381, 0), 
(143, 'module', 'shops', 'modules/shops/admin/carrier_config_items.php', 1475427381, 0), 
(144, 'module', 'shops', 'modules/shops/admin/cat.php', 1475427381, 0), 
(145, 'module', 'shops', 'modules/shops/admin/changepay.php', 1475427381, 0), 
(146, 'module', 'shops', 'modules/shops/admin/change_block.php', 1475427381, 0), 
(147, 'module', 'shops', 'modules/shops/admin/change_cat.php', 1475427381, 0), 
(148, 'module', 'shops', 'modules/shops/admin/change_group.php', 1475427381, 0), 
(149, 'module', 'shops', 'modules/shops/admin/change_location.php', 1475427381, 0), 
(150, 'module', 'shops', 'modules/shops/admin/change_source.php', 1475427381, 0), 
(151, 'module', 'shops', 'modules/shops/admin/chang_block_cat.php', 1475427381, 0), 
(152, 'module', 'shops', 'modules/shops/admin/content.php', 1475427381, 0), 
(153, 'module', 'shops', 'modules/shops/admin/coupons.php', 1475427381, 0), 
(154, 'module', 'shops', 'modules/shops/admin/coupons_view.php', 1475427381, 0), 
(155, 'module', 'shops', 'modules/shops/admin/custom_form.php', 1475427381, 0), 
(156, 'module', 'shops', 'modules/shops/admin/delmoney.php', 1475427381, 0), 
(157, 'module', 'shops', 'modules/shops/admin/delunit.php', 1475427381, 0), 
(158, 'module', 'shops', 'modules/shops/admin/delweight.php', 1475427381, 0), 
(159, 'module', 'shops', 'modules/shops/admin/del_block_cat.php', 1475427381, 0), 
(160, 'module', 'shops', 'modules/shops/admin/del_cat.php', 1475427381, 0), 
(161, 'module', 'shops', 'modules/shops/admin/del_content.php', 1475427381, 0), 
(162, 'module', 'shops', 'modules/shops/admin/del_group.php', 1475427381, 0), 
(163, 'module', 'shops', 'modules/shops/admin/del_location.php', 1475427381, 0), 
(164, 'module', 'shops', 'modules/shops/admin/del_source.php', 1475427381, 0), 
(165, 'module', 'shops', 'modules/shops/admin/detemplate.php', 1475427381, 0), 
(166, 'module', 'shops', 'modules/shops/admin/discounts.php', 1475427381, 0), 
(167, 'module', 'shops', 'modules/shops/admin/docpay.php', 1475427381, 0), 
(168, 'module', 'shops', 'modules/shops/admin/download.php', 1475427381, 0), 
(169, 'module', 'shops', 'modules/shops/admin/exptime.php', 1475427381, 0), 
(170, 'module', 'shops', 'modules/shops/admin/fields.php', 1475427381, 0), 
(171, 'module', 'shops', 'modules/shops/admin/field_tab.php', 1475427381, 0), 
(172, 'module', 'shops', 'modules/shops/admin/getcatalog.php', 1475427381, 0), 
(173, 'module', 'shops', 'modules/shops/admin/getgroup.php', 1475427381, 0), 
(174, 'module', 'shops', 'modules/shops/admin/getprice.php', 1475427381, 0), 
(175, 'module', 'shops', 'modules/shops/admin/group.php', 1475427381, 0), 
(176, 'module', 'shops', 'modules/shops/admin/index.html', 1475427381, 0), 
(177, 'module', 'shops', 'modules/shops/admin/items.php', 1475427381, 0), 
(178, 'module', 'shops', 'modules/shops/admin/keywords.php', 1475427381, 0), 
(179, 'module', 'shops', 'modules/shops/admin/list_block.php', 1475427381, 0), 
(180, 'module', 'shops', 'modules/shops/admin/list_block_cat.php', 1475427381, 0), 
(181, 'module', 'shops', 'modules/shops/admin/list_cat.php', 1475427381, 0), 
(182, 'module', 'shops', 'modules/shops/admin/list_group.php', 1475427381, 0), 
(183, 'module', 'shops', 'modules/shops/admin/list_location.php', 1475427381, 0), 
(184, 'module', 'shops', 'modules/shops/admin/location.php', 1475427381, 0), 
(185, 'module', 'shops', 'modules/shops/admin/main.php', 1475427381, 0), 
(186, 'module', 'shops', 'modules/shops/admin/money.php', 1475427381, 0), 
(187, 'module', 'shops', 'modules/shops/admin/order.php', 1475427381, 0), 
(188, 'module', 'shops', 'modules/shops/admin/order_seller.php', 1475427381, 0), 
(189, 'module', 'shops', 'modules/shops/admin/or_del.php', 1475427381, 0), 
(190, 'module', 'shops', 'modules/shops/admin/or_view.php', 1475427381, 0), 
(191, 'module', 'shops', 'modules/shops/admin/payport.php', 1475427381, 0), 
(192, 'module', 'shops', 'modules/shops/admin/point.php', 1475427381, 0), 
(193, 'module', 'shops', 'modules/shops/admin/print.php', 1475427381, 0), 
(194, 'module', 'shops', 'modules/shops/admin/prounit.php', 1475427381, 0), 
(195, 'module', 'shops', 'modules/shops/admin/publtime.php', 1475427381, 0), 
(196, 'module', 'shops', 'modules/shops/admin/review.php', 1475427381, 0), 
(197, 'module', 'shops', 'modules/shops/admin/seller.php', 1475427381, 0), 
(198, 'module', 'shops', 'modules/shops/admin/setting.php', 1475427381, 0), 
(199, 'module', 'shops', 'modules/shops/admin/shipping.php', 1475427381, 0), 
(200, 'module', 'shops', 'modules/shops/admin/shops.php', 1475427381, 0), 
(201, 'module', 'shops', 'modules/shops/admin/tabs.php', 1475427381, 0), 
(202, 'module', 'shops', 'modules/shops/admin/tags.php', 1475427381, 0), 
(203, 'module', 'shops', 'modules/shops/admin/tagsajax.php', 1475427381, 0), 
(204, 'module', 'shops', 'modules/shops/admin/template.php', 1475427381, 0), 
(205, 'module', 'shops', 'modules/shops/admin/updateprice.php', 1475427381, 0), 
(206, 'module', 'shops', 'modules/shops/admin/view.php', 1475427381, 0), 
(207, 'module', 'shops', 'modules/shops/admin/warehouse.php', 1475427381, 0), 
(208, 'module', 'shops', 'modules/shops/admin/warehouse_logs.php', 1475427381, 0), 
(209, 'module', 'shops', 'modules/shops/admin/weight.php', 1475427381, 0), 
(210, 'module', 'shops', 'modules/shops/admin.functions.php', 1475427381, 0), 
(211, 'module', 'shops', 'modules/shops/admin.menu.php', 1475427381, 0), 
(212, 'module', 'shops', 'modules/shops/blocks/.htaccess', 1475427381, 0), 
(213, 'module', 'shops', 'modules/shops/blocks/global.block_bxproduct_center.ini', 1475427381, 0), 
(214, 'module', 'shops', 'modules/shops/blocks/global.block_bxproduct_center.php', 1475427381, 0), 
(215, 'module', 'shops', 'modules/shops/blocks/global.block_cart.php', 1475427381, 0), 
(216, 'module', 'shops', 'modules/shops/blocks/global.block_catalogs.ini', 1475427381, 0), 
(217, 'module', 'shops', 'modules/shops/blocks/global.block_catalogs.php', 1475427381, 0), 
(218, 'module', 'shops', 'modules/shops/blocks/global.block_price_view.ini', 1475427381, 0), 
(219, 'module', 'shops', 'modules/shops/blocks/global.block_price_view.php', 1475427381, 0), 
(220, 'module', 'shops', 'modules/shops/blocks/global.block_product_center.ini', 1475427381, 0), 
(221, 'module', 'shops', 'modules/shops/blocks/global.block_product_center.php', 1475427381, 0), 
(222, 'module', 'shops', 'modules/shops/blocks/global.block_relates_product.ini', 1475427381, 0), 
(223, 'module', 'shops', 'modules/shops/blocks/global.block_relates_product.php', 1475427381, 0), 
(224, 'module', 'shops', 'modules/shops/blocks/global.block_search.php', 1475427381, 0), 
(225, 'module', 'shops', 'modules/shops/blocks/index.html', 1475427381, 0), 
(226, 'module', 'shops', 'modules/shops/blocks/module.block_filter_product.ini', 1475427381, 0), 
(227, 'module', 'shops', 'modules/shops/blocks/module.block_filter_product.php', 1475427381, 0), 
(228, 'module', 'shops', 'modules/shops/blocks/module.block_filter_product_cat.ini', 1475427381, 0), 
(229, 'module', 'shops', 'modules/shops/blocks/module.block_filter_product_cat.php', 1475427381, 0), 
(230, 'module', 'shops', 'modules/shops/blocks/module.block_others_product.php', 1475427381, 0), 
(231, 'module', 'shops', 'modules/shops/blocks/module.block_product_center.php', 1475427381, 0), 
(232, 'module', 'shops', 'modules/shops/comment.php', 1475427381, 0), 
(233, 'module', 'shops', 'modules/shops/fields.check.php', 1475427381, 0), 
(234, 'module', 'shops', 'modules/shops/funcs/.htaccess', 1475427381, 0), 
(235, 'module', 'shops', 'modules/shops/funcs/blockcat.php', 1475427381, 0), 
(236, 'module', 'shops', 'modules/shops/funcs/cart.php', 1475427381, 0), 
(237, 'module', 'shops', 'modules/shops/funcs/checkorder.php', 1475427381, 0), 
(238, 'module', 'shops', 'modules/shops/funcs/compare.php', 1475427381, 0), 
(239, 'module', 'shops', 'modules/shops/funcs/complete.php', 1475427381, 0), 
(240, 'module', 'shops', 'modules/shops/funcs/delhis.php', 1475427381, 0), 
(241, 'module', 'shops', 'modules/shops/funcs/detail.php', 1475427381, 0), 
(242, 'module', 'shops', 'modules/shops/funcs/download.php', 1475427381, 0), 
(243, 'module', 'shops', 'modules/shops/funcs/group.php', 1475427381, 0), 
(244, 'module', 'shops', 'modules/shops/funcs/history.php', 1475427381, 0), 
(245, 'module', 'shops', 'modules/shops/funcs/index.html', 1475427381, 0), 
(246, 'module', 'shops', 'modules/shops/funcs/loadcart.php', 1475427381, 0), 
(247, 'module', 'shops', 'modules/shops/funcs/main.php', 1475427381, 0), 
(248, 'module', 'shops', 'modules/shops/funcs/order.php', 1475427381, 0), 
(249, 'module', 'shops', 'modules/shops/funcs/payment.php', 1475427381, 0), 
(250, 'module', 'shops', 'modules/shops/funcs/point.php', 1475427381, 0), 
(251, 'module', 'shops', 'modules/shops/funcs/print.php', 1475427381, 0), 
(252, 'module', 'shops', 'modules/shops/funcs/print_pro.php', 1475427381, 0), 
(253, 'module', 'shops', 'modules/shops/funcs/remove.php', 1475427381, 0), 
(254, 'module', 'shops', 'modules/shops/funcs/review.php', 1475427381, 0), 
(255, 'module', 'shops', 'modules/shops/funcs/rss.php', 1475427381, 0), 
(256, 'module', 'shops', 'modules/shops/funcs/search.php', 1475427381, 0), 
(257, 'module', 'shops', 'modules/shops/funcs/search_result.php', 1475427381, 0), 
(258, 'module', 'shops', 'modules/shops/funcs/sendmail.php', 1475427381, 0), 
(259, 'module', 'shops', 'modules/shops/funcs/setcart.php', 1475427381, 0), 
(260, 'module', 'shops', 'modules/shops/funcs/shippingajax.php', 1475427381, 0), 
(261, 'module', 'shops', 'modules/shops/funcs/sitemap.php', 1475427381, 0), 
(262, 'module', 'shops', 'modules/shops/funcs/tag.php', 1475427381, 0), 
(263, 'module', 'shops', 'modules/shops/funcs/viewcat.php', 1475427381, 0), 
(264, 'module', 'shops', 'modules/shops/funcs/wishlist.php', 1475427381, 0), 
(265, 'module', 'shops', 'modules/shops/funcs/wishlist_update.php', 1475427381, 0), 
(266, 'module', 'shops', 'modules/shops/functions.php', 1475427381, 0), 
(267, 'module', 'shops', 'modules/shops/global.functions.php', 1475427381, 0), 
(268, 'module', 'shops', 'modules/shops/index.html', 1475427381, 0), 
(269, 'module', 'shops', 'modules/shops/language/.htaccess', 1475427381, 0), 
(270, 'module', 'shops', 'modules/shops/language/admin_en.php', 1475427381, 0), 
(271, 'module', 'shops', 'modules/shops/language/admin_vi.php', 1475427381, 0), 
(272, 'module', 'shops', 'modules/shops/language/data_vi.php', 1475427381, 0), 
(273, 'module', 'shops', 'modules/shops/language/en.php', 1475427381, 0), 
(274, 'module', 'shops', 'modules/shops/language/index.html', 1475427381, 0), 
(275, 'module', 'shops', 'modules/shops/language/vi.php', 1475427381, 0), 
(276, 'module', 'shops', 'modules/shops/menu.php', 1475427381, 0), 
(277, 'module', 'shops', 'modules/shops/notification.php', 1475427381, 0), 
(278, 'module', 'shops', 'modules/shops/payment/.htaccess', 1475427381, 0), 
(279, 'module', 'shops', 'modules/shops/payment/baokim.checkorders.php', 1475427381, 0), 
(280, 'module', 'shops', 'modules/shops/payment/baokim.checkout_url.php', 1475427381, 0), 
(281, 'module', 'shops', 'modules/shops/payment/baokim.class.php', 1475427381, 0), 
(282, 'module', 'shops', 'modules/shops/payment/baokim.complete.php', 1475427381, 0), 
(283, 'module', 'shops', 'modules/shops/payment/baokim.config.ini', 1475427381, 0), 
(284, 'module', 'shops', 'modules/shops/payment/index.html', 1475427381, 0), 
(285, 'module', 'shops', 'modules/shops/payment/onepaydomestic.checkorders.php', 1475427381, 0), 
(286, 'module', 'shops', 'modules/shops/payment/onepaydomestic.checkout_url.php', 1475427381, 0), 
(287, 'module', 'shops', 'modules/shops/payment/onepaydomestic.complete.php', 1475427381, 0), 
(288, 'module', 'shops', 'modules/shops/payment/onepaydomestic.config.ini', 1475427381, 0), 
(289, 'module', 'shops', 'modules/shops/payment/paypal_express_checkout.checkorders.php', 1475427381, 0), 
(290, 'module', 'shops', 'modules/shops/payment/paypal_express_checkout.checkout_url.php', 1475427381, 0), 
(291, 'module', 'shops', 'modules/shops/payment/paypal_express_checkout.complete.php', 1475427381, 0), 
(292, 'module', 'shops', 'modules/shops/payment/paypal_express_checkout.config.ini', 1475427381, 0), 
(293, 'module', 'shops', 'modules/shops/rssdata.php', 1475427381, 0), 
(294, 'module', 'shops', 'modules/shops/search.php', 1475427381, 0), 
(295, 'module', 'shops', 'modules/shops/site.functions.php', 1475427381, 0), 
(296, 'module', 'shops', 'modules/shops/siteinfo.php', 1475427381, 0), 
(297, 'module', 'shops', 'modules/shops/theme.php', 1475427381, 0), 
(298, 'module', 'shops', 'modules/shops/version.php', 1475427381, 0);


-- ---------------------------------------


--
-- Table structure for table `az_googleplus`
--

DROP TABLE IF EXISTS `az_googleplus`;
CREATE TABLE `az_googleplus` (
  `gid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `idprofile` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  UNIQUE KEY `idprofile` (`idprofile`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_language`
--

DROP TABLE IF EXISTS `az_language`;
CREATE TABLE `az_language` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `idfile` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lang_key` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `filelang` (`idfile`,`lang_key`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_language_file`
--

DROP TABLE IF EXISTS `az_language_file`;
CREATE TABLE `az_language_file` (
  `idfile` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_file` varchar(200)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `langtype` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`idfile`),
  UNIQUE KEY `module` (`module`,`admin_file`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_logs`
--

DROP TABLE IF EXISTS `az_logs`;
CREATE TABLE `az_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lang` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_name` varchar(150)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_key` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_action` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_acess` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL,
  `log_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=683  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_logs`
--

INSERT INTO `az_logs` VALUES
(1, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475277710), 
(2, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475289388), 
(3, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1475289541), 
(4, 'vi', 'menu', 'Delete menu item', 'Item ID 8', '', 1, 1475289557), 
(5, 'vi', 'menu', 'Delete menu item', 'Item ID 9', '', 1, 1475289557), 
(6, 'vi', 'menu', 'Delete menu item', 'Item ID 10', '', 1, 1475289557), 
(7, 'vi', 'menu', 'Delete menu item', 'Item ID 11', '', 1, 1475289557), 
(8, 'vi', 'menu', 'Delete menu item', 'Item ID 12', '', 1, 1475289557), 
(9, 'vi', 'menu', 'Delete menu item', 'Item ID 13', '', 1, 1475289557), 
(10, 'vi', 'menu', 'Delete menu item', 'Item ID 14', '', 1, 1475289557), 
(11, 'vi', 'menu', 'Delete menu item', 'Item ID 15', '', 1, 1475289557), 
(12, 'vi', 'upload', 'Upload file', 'uploads/logo-2.png', '', 1, 1475289762), 
(13, 'vi', 'modules', 'Thiết lập module mới slider', '', '', 1, 1475290330), 
(14, 'vi', 'modules', 'Sửa module &ldquo;slider&rdquo;', '', '', 1, 1475290339), 
(15, 'vi', 'users', 'Xóa nhóm', 'group_id: 10', '', 1, 1475290348), 
(16, 'vi', 'users', 'Xóa nhóm', 'group_id: 11', '', 1, 1475290351), 
(17, 'vi', 'users', 'Xóa nhóm', 'group_id: 12', '', 1, 1475290354), 
(18, 'vi', 'modules', 'Thứ tự module: slider', '15 -> 3', '', 1, 1475290363), 
(19, 'vi', 'slider', 'Thêm nhóm', 'group_id: 1', '', 1, 1475290379), 
(20, 'vi', 'upload', 'Upload file', 'uploads/slider/images/4.jpg', '', 1, 1475290400), 
(21, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 1', '', 1, 1475290406), 
(22, 'vi', 'upload', 'Upload file', 'uploads/slider/images/3.jpg', '', 1, 1475290418), 
(23, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 2', '', 1, 1475290422), 
(24, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 2', '', 1, 1475290430), 
(25, 'vi', 'upload', 'Upload file', 'uploads/slider/images/2.jpg', '', 1, 1475290442), 
(26, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 3', '', 1, 1475290450), 
(27, 'vi', 'upload', 'Upload file', 'uploads/slider/images/1.jpg', '', 1, 1475290462), 
(28, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 4', '', 1, 1475290479), 
(29, 'vi', 'upload', 'Upload file', 'uploads/slider/images/5.jpg', '', 1, 1475290489), 
(30, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 5', '', 1, 1475290503), 
(31, 'vi', 'upload', 'Upload file', 'uploads/slider/images/6.jpg', '', 1, 1475290552), 
(32, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 6', '', 1, 1475290562), 
(33, 'vi', 'themes', 'Thêm block', 'Name : global slider', '', 1, 1475290610), 
(34, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1475290704), 
(35, 'vi', 'themes', 'Sửa block', 'Name : Menu Site', '', 1, 1475291383), 
(36, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1475293331), 
(37, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475296080), 
(38, 'vi', 'modules', 'Thiết lập module mới photos', '', '', 1, 1475296369), 
(39, 'vi', 'modules', 'Thứ tự module: photos', '16 -> 3', '', 1, 1475297254), 
(40, 'vi', 'modules', 'Sửa module &ldquo;photos&rdquo;', '', '', 1, 1475297261), 
(41, 'vi', 'photos', 'Add new Category', 'category_id: 1 Biệt thự', '', 1, 1475297294), 
(42, 'vi', 'photos', 'Add new Category', 'category_id: 2 Nhà phố', '', 1, 1475297308), 
(43, 'vi', 'photos', 'Add A Album', 'album_id: 1', '', 1, 1475297383), 
(44, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1475297414), 
(45, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1475297455), 
(46, 'vi', 'themes', 'Thêm block', 'Name : Tại sao bạn chọn Wonder?', '', 1, 1475298188), 
(47, 'vi', 'themes', 'Thêm block', 'Name : global company info', '', 1, 1475299032), 
(48, 'vi', 'themes', 'Sửa block', 'Name : Liên hệ', '', 1, 1475299050), 
(49, 'vi', 'themes', 'Sửa block', 'Name : Liên hệ', '', 1, 1475299136), 
(50, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1475299296), 
(51, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475300706), 
(52, 'vi', 'themes', 'Thêm block', 'Name : global company info', '', 1, 1475300751), 
(53, 'vi', 'themes', 'Sửa block', 'Name : global company info', '', 1, 1475300933), 
(54, 'vi', 'themes', 'Thêm block', 'Name : global company info', '', 1, 1475301095), 
(55, 'vi', 'themes', 'Thêm block', 'Name : Đối tác liên kết', '', 1, 1475301283), 
(56, 'vi', 'themes', 'Sửa block', 'Name : Đối tác liên kết', '', 1, 1475301296), 
(57, 'vi', 'themes', 'Thêm block', 'Name : global company info', '', 1, 1475301604), 
(58, 'vi', 'themes', 'Sửa block', 'Name : global company info', '', 1, 1475301648), 
(59, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475315547), 
(60, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475325697), 
(61, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475344057), 
(62, 'vi', 'photos', 'Edit A Album', 'album_id: 1', '', 1, 1475344274), 
(63, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1475344302), 
(64, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1475344323), 
(65, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1475344373), 
(66, 'vi', 'photos', 'Edit A Album', 'album_id: 1', '', 1, 1475344543), 
(67, 'vi', 'themes', 'Thêm block', 'Name : global slimmenu', '', 1, 1475345256), 
(68, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1475346346), 
(69, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475352238), 
(70, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1475354869), 
(71, 'vi', 'photos', 'Add new Category', 'category_id: 3 Căn hộ, penthouse', '', 1, 1475357457), 
(72, 'vi', 'photos', 'Add new Category', 'category_id: 4 Khách sạn, resort', '', 1, 1475357473), 
(73, 'vi', 'photos', 'Add new Category', 'category_id: 5 Bar, cafe, nhà hàng, karaoke', '', 1, 1475357489), 
(74, 'vi', 'photos', 'Add new Category', 'category_id: 6 Spa, beauty salon', '', 1, 1475357502), 
(75, 'vi', 'photos', 'Add new Category', 'category_id: 7 Showroom, shop, building, office', '', 1, 1475357516), 
(76, 'vi', 'photos', 'Add new Category', 'category_id: 8 Showroom, shop, building, office', '', 1, 1475357535), 
(77, 'vi', 'themes', 'Sửa block', 'Name : global slimmenu', '', 1, 1475357601), 
(78, 'vi', 'themes', 'Sửa block', 'Name : global slimmenu', '', 1, 1475357610), 
(79, 'vi', 'photos', 'Add A Album', 'album_id: 2', '', 1, 1475357892), 
(80, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1475357997), 
(81, 'vi', 'photos', 'Add A Album', 'album_id: 3', '', 1, 1475358126), 
(82, 'vi', 'photos', 'Add A Album', 'album_id: 4', '', 1, 1475358245), 
(83, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475394725), 
(84, 'vi', 'slider', 'Thêm nhóm', 'group_id: 2', '', 1, 1475394751), 
(85, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 7', '', 1, 1475394802), 
(86, 'vi', 'themes', 'Thêm block', 'Name : global slider', '', 1, 1475394865), 
(87, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1475394882), 
(88, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1475395127), 
(89, 'vi', 'modules', 'Thiết lập module mới weblinks', '', '', 1, 1475395555), 
(90, 'vi', 'modules', 'Sửa module &ldquo;weblinks&rdquo;', '', '', 1, 1475395561), 
(91, 'vi', 'modules', 'Thứ tự module: weblinks', '17 -> 1', '', 1, 1475395565), 
(92, 'vi', 'slider', 'log_del_photo', '7', '', 1, 1475395576), 
(93, 'vi', 'slider', 'log_del_group', '2', '', 1, 1475395580), 
(94, 'vi', 'weblinks', 'Thêm chủ đề', 'Báo giá tháng 10', '', 1, 1475395617), 
(95, 'vi', 'weblinks', 'Thêm liên kết mới', 'Trọn gói đ&#x002F;m²', '', 1, 1475395678), 
(96, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1475395704), 
(97, 'vi', 'upload', 'Upload file', 'uploads/weblinks/1-55-720x540.jpg', '', 1, 1475395735), 
(98, 'vi', 'weblinks', 'Sửa liên kết', 'Trọn gói đ&#x002F;m²', '', 1, 1475395740), 
(99, 'vi', 'modules', 'Cài lại module \"weblinks\"', '', '', 1, 1475396787), 
(100, 'vi', 'weblinks', 'Thêm chủ đề', 'Báo giá tháng 10', '', 1, 1475396808), 
(101, 'vi', 'weblinks', 'Thêm liên kết mới', 'Trọn gói đ&#x002F;m²', '', 1, 1475396829), 
(102, 'vi', 'weblinks', 'Thêm liên kết mới', 'Kiến trúc đ&#x002F;m²', '', 1, 1475399415), 
(103, 'vi', 'weblinks', 'Sửa liên kết', 'Trọn gói đ&#x002F;m²', '', 1, 1475399452), 
(104, 'vi', 'weblinks', 'Sửa liên kết', 'Trọn gói đ&#x002F;m²', '', 1, 1475399463), 
(105, 'vi', 'weblinks', 'Thêm liên kết mới', 'Nội thất đ&#x002F;m²', '', 1, 1475399873), 
(106, 'vi', 'weblinks', 'Sửa liên kết', 'Trọn gói đ&#x002F;m²', '', 1, 1475403456), 
(107, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1475405257), 
(108, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475405459), 
(109, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1475413320), 
(110, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1475413843), 
(111, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1475414260), 
(112, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:127.0.0.1', '', 0, 1475415644), 
(113, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475416170), 
(114, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1475416291), 
(115, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1475418661), 
(116, 'vi', 'photos', 'Edit A Album', 'album_id: 1', '', 1, 1475419491), 
(117, 'vi', 'photos', 'Edit A Album', 'album_id: 1', '', 1, 1475421786), 
(118, 'vi', 'photos', 'Edit A Album', 'album_id: 1', '', 1, 1475421813), 
(119, 'vi', 'photos', 'Edit A Album', 'album_id: 1', '', 1, 1475422085), 
(120, 'vi', 'themes', 'Thêm block', 'Name : global block album new', '', 1, 1475423292), 
(121, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1475423598), 
(122, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1475423631), 
(123, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1475423661), 
(124, 'vi', 'themes', 'Thêm block', 'Name : global block album new', '', 1, 1475424764), 
(125, 'vi', 'themes', 'Sửa block', 'Name : global block album new', '', 1, 1475424792), 
(126, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1475424878), 
(127, 'vi', 'modules', 'Thiết lập module mới shops', '', '', 1, 1475427388), 
(128, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1475427393), 
(129, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1475427517), 
(130, 'vi', 'modules', 'Thứ tự module: shops', '18 -> 1', '', 1, 1475427524), 
(131, 'vi', 'shops', 'log_add_catalog', 'id 1', '', 1, 1475427543), 
(132, 'vi', 'shops', 'log_add_catalog', 'id 2', '', 1, 1475427557), 
(133, 'vi', 'shops', 'log_add_catalog', 'id 3', '', 1, 1475427572), 
(134, 'vi', 'modules', 'Sửa module &ldquo;shops&rdquo;', '', '', 1, 1475427587), 
(135, 'vi', 'shops', 'Add A Product', 'ID: 1', '', 1, 1475427690), 
(136, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_10/absynth-magh-sideboard.jpg', '', 1, 1475427709), 
(137, 'vi', 'shops', 'Edit A Product', 'ID: 1', '', 1, 1475427714), 
(138, 'vi', 'themes', 'Thêm block', 'Name : global block catalogs', '', 1, 1475427747), 
(139, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs', '', 1, 1475427775), 
(140, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs', '', 1, 1475427775), 
(141, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1475427803), 
(142, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_10/absynth-magh-sideboard_1.jpg', '', 1, 1475427843), 
(143, 'vi', 'shops', 'Edit A Product', 'ID: 1', '', 1, 1475427847), 
(144, 'vi', 'themes', 'Sửa block', 'Name : global block catalogs', '', 1, 1475427946), 
(145, 'vi', 'themes', 'Sửa block', 'Name : Danh mục sản phẩm', '', 1, 1475427965), 
(146, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1475429475), 
(147, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475432904), 
(148, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_10/1-6.jpg', '', 1, 1475433703), 
(149, 'vi', 'shops', 'Add A Product', 'ID: 2', '', 1, 1475433709), 
(150, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1475434091), 
(151, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475441414), 
(152, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:127.0.0.1', '', 0, 1475470012), 
(153, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.251.18.108', '', 0, 1475471836), 
(154, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:171.251.18.108', '', 0, 1475475017), 
(155, 'vi', 'themes', 'Sửa block', 'Name : Danh mục sản phẩm', '', 1, 1475475833), 
(156, 'vi', 'themes', 'Sửa block', 'Name : Danh mục sản phẩm', '', 1, 1475475848), 
(157, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476424513), 
(158, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1476425541), 
(159, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1476425695), 
(160, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476427522), 
(161, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476427638), 
(162, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1476432249), 
(163, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1476432360), 
(164, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1476433390), 
(165, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1476433460), 
(166, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1476433574), 
(167, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476437957), 
(168, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476444179), 
(169, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1476444190), 
(170, 'vi', 'photos', 'Add A Album', 'album_id: 5', '', 1, 1476446094), 
(171, 'vi', 'photos', 'Edit A Album', 'album_id: 5', '', 1, 1476446554), 
(172, 'vi', 'shops', 'Add A Product', 'ID: 3', '', 1, 1476446658), 
(173, 'vi', 'shops', 'Add A Product', 'ID: 4', '', 1, 1476446666), 
(174, 'vi', 'themes', 'Thêm block', 'Name : global block bxproduct center', '', 1, 1476446806), 
(175, 'vi', 'themes', 'Sửa block', 'Name : global block bxproduct center', '', 1, 1476447133), 
(176, 'vi', 'themes', 'Sửa block', 'Name : global block bxproduct center', '', 1, 1476447184), 
(177, 'vi', 'shops', 'Edit A Product', 'ID: 1', '', 1, 1476448145), 
(178, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1476448173), 
(179, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476449973), 
(180, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476450471), 
(181, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476535451), 
(182, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476540532), 
(183, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476540587), 
(184, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476540616), 
(185, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1476540696), 
(186, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476547752), 
(187, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1476547802), 
(188, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476548920), 
(189, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476578669), 
(190, 'vi', 'upload', 'Upload file', 'uploads/quangcaol.jpg', '', 1, 1476578698), 
(191, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476578728), 
(192, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476578802), 
(193, 'vi', 'upload', 'Upload file', 'uploads/logo.png', '', 1, 1476578974), 
(194, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476578987), 
(195, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476608772), 
(196, 'vi', 'upload', 'Xóa file', 'uploads/logo.png', '', 1, 1476609574), 
(197, 'vi', 'upload', 'Upload file', 'uploads/logo.png', '', 1, 1476609580), 
(198, 'vi', 'about', 'Delete', 'ID: 1', '', 1, 1476610150), 
(199, 'vi', 'about', 'Delete', 'ID: 2', '', 1, 1476610152), 
(200, 'vi', 'about', 'Delete', 'ID: 3', '', 1, 1476610154), 
(201, 'vi', 'about', 'Delete', 'ID: 4', '', 1, 1476610155), 
(202, 'vi', 'about', 'Delete', 'ID: 5', '', 1, 1476610157), 
(203, 'vi', 'about', 'Delete', 'ID: 6', '', 1, 1476610158), 
(204, 'vi', 'about', 'Delete', 'ID: 7', '', 1, 1476610160), 
(205, 'vi', 'about', 'Delete', 'ID: 8', '', 1, 1476610161), 
(206, 'vi', 'about', 'Add', ' ', '', 1, 1476610187), 
(207, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476611720), 
(208, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476611729), 
(209, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476611746), 
(210, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476617752), 
(211, 'vi', 'contact', 'log_del_row', 'rowid 2', '', 1, 1476617830), 
(212, 'vi', 'contact', 'log_edit_row', 'id: 1 Dịch vụ', '', 1, 1476617863), 
(213, 'vi', 'contact', 'log_edit_row', 'id: 1 Dịch vụ', '', 1, 1476618025), 
(214, 'vi', 'contact', 'log_del', 'id 1', '', 1, 1476618035), 
(215, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476618130), 
(216, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476618201), 
(217, 'vi', 'contact', 'log_del_row', 'rowid 1', '', 1, 1476618210), 
(218, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476618213), 
(219, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476618346), 
(220, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1476618353), 
(221, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476618676), 
(222, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476618725), 
(223, 'vi', 'contact', 'log_add_row', 'Loại công trình', '', 1, 1476618955), 
(224, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476618960), 
(225, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476619330), 
(226, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476620965), 
(227, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476621242), 
(228, 'vi', 'contact', 'log_del', 'id 2', '', 1, 1476622785), 
(229, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:123.23.173.228', '', 0, 1476622788), 
(230, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:123.23.173.228', '', 0, 1476622946), 
(231, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.182.206.216', '', 0, 1476965608), 
(232, 'vi', 'upload', 'Xóa file', 'uploads/logo.png', '', 1, 1476965631), 
(233, 'vi', 'upload', 'Upload file', 'uploads/logo.png', '', 1, 1476965639), 
(234, 'vi', 'themes', 'Sửa block', 'Name : Liên hệ', '', 1, 1476968201), 
(235, 'vi', 'themes', 'Sửa block', 'Name : Đồng hàng cùng chúng tôi', '', 1, 1476968289), 
(236, 'vi', 'themes', 'Sửa block', 'Name : Đồng hành cùng chúng tôi', '', 1, 1476968540), 
(237, 'vi', 'upload', 'Xóa file', 'uploads/logo-2.png', '', 1, 1476968790), 
(238, 'vi', 'page', 'Add', ' ', '', 1, 1476968834), 
(239, 'vi', 'page', 'Add', ' ', '', 1, 1476968847), 
(240, 'vi', 'upload', 'Upload file', 'uploads/logo.jpg', '', 1, 1476969394), 
(241, 'vi', 'shops', 'Edit A Product', 'ID: 4', '', 1, 1476969968), 
(242, 'vi', 'shops', 'log_edit_catalog', 'id 3', '', 1, 1476970015), 
(243, 'vi', 'shops', 'log_edit_catalog', 'id 2', '', 1, 1476970021), 
(244, 'vi', 'shops', 'log_edit_catalog', 'id 1', '', 1, 1476970027), 
(245, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:113.182.206.216', '', 0, 1476970642), 
(246, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.182.206.216', '', 0, 1476971731), 
(247, 'vi', 'themes', 'Sửa block', 'Name : Liên hệ', '', 1, 1476971748), 
(248, 'vi', 'themes', 'Sửa block', 'Name : Liên hệ', '', 1, 1476971841), 
(249, 'vi', 'themes', 'Sửa block', 'Name : Liên hệ', '', 1, 1476972240), 
(250, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.182.206.216', '', 0, 1477025645), 
(251, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.182.206.216', '', 0, 1477048907), 
(252, 'vi', 'photos', 'Add A Album', 'album_id: 6', '', 1, 1477049122), 
(253, 'vi', 'photos', 'Add A Album', 'album_id: 7', '', 1, 1477049450), 
(254, 'vi', 'photos', 'Add A Album', 'album_id: 8', '', 1, 1477049636), 
(255, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:113.182.105.78', '', 0, 1477384553), 
(256, 'vi', 'users', 'log_edit_user', 'userid 1', '', 1, 1477384587), 
(257, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:42.115.130.47', '', 0, 1477385547), 
(258, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:118.70.187.75', '', 0, 1477385768), 
(259, 'vi', 'about', 'Edit', 'ID: 9', '', 1, 1477387189), 
(260, 'vi', 'upload', 'Upload file', 'uploads/slider/images/koenigseggageraone1interior-l-0ece498920e8a35e.jpg', '', 1, 1477387694), 
(261, 'vi', 'upload', 'Xóa file', 'uploads/slider/images/koenigseggageraone1interior-l-0ece498920e8a35e.jpg', '', 1, 1477387717), 
(262, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477388090), 
(263, 'vi', 'upload', 'Upload file', 'uploads/slider/images/5_56.jpg', '', 1, 1477389900), 
(264, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 3', '', 1, 1477389920), 
(265, 'vi', 'upload', 'Upload file', 'uploads/slider/images/ficha2_imagen1_highres_post_mail.jpg', '', 1, 1477390194), 
(266, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 3', '', 1, 1477390202), 
(267, 'vi', 'upload', 'Upload file', 'uploads/slider/images/baltic_park_molo_interior.jpg', '', 1, 1477390384), 
(268, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 2', '', 1, 1477390389), 
(269, 'vi', 'upload', 'Upload file', 'uploads/slider/images/art_work.jpg', '', 1, 1477390469), 
(270, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 4', '', 1, 1477390475), 
(271, 'vi', 'upload', 'Upload file', 'uploads/slider/images/bathroom_1_sharpversion.jpg', '', 1, 1477390569), 
(272, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 5', '', 1, 1477390574), 
(273, 'vi', 'upload', 'Upload file', 'uploads/slider/images/bedroom_12.jpg', '', 1, 1477390670), 
(274, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 6', '', 1, 1477390674), 
(275, 'vi', 'upload', 'Upload file', 'uploads/slider/images/bedroom_12_1.jpg', '', 1, 1477390746), 
(276, 'vi', 'upload', 'Xóa file', 'uploads/slider/images/bedroom_12.jpg', '', 1, 1477390756), 
(277, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 6', '', 1, 1477390759), 
(278, 'vi', 'login', '[quantriweb] Thoát khỏi tài khoản Quản trị', ' Client IP:118.70.187.75', '', 0, 1477392559), 
(279, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:118.70.187.75', '', 0, 1477392834), 
(280, 'vi', 'upload', 'Upload file', 'uploads/slider/images/kuchyn.jpg', '', 1, 1477392946), 
(281, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 2', '', 1, 1477392951), 
(282, 'vi', 'upload', 'Upload file', 'uploads/slider/images/04_hill_house_kitchen_detail_2000.jpg', '', 1, 1477393089), 
(283, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 1', '', 1, 1477393094), 
(284, 'vi', 'upload', 'Upload file', 'uploads/slider/images/apartment_revised_shot_5.jpg', '', 1, 1477393416), 
(285, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 8', '', 1, 1477393423), 
(286, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 8', '', 1, 1477393522), 
(287, 'vi', 'upload', 'Upload file', 'uploads/icon2.jpg', '', 1, 1477393765), 
(288, 'vi', 'upload', 'Upload file', 'uploads/icon3.jpg', '', 1, 1477393876), 
(289, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 8', '', 1, 1477394233), 
(290, 'vi', 'slider', 'log_change_weight_photo', 'photo_id:8', '', 1, 1477394366), 
(291, 'vi', 'slider', 'log_change_weight_photo', 'photo_id:8', '', 1, 1477394372), 
(292, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 1', '', 1, 1477394455), 
(293, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 1', '', 1, 1477394516), 
(294, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:1.52.85.83', '', 0, 1477401447), 
(295, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477402629), 
(296, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477402718), 
(297, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477402782), 
(298, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477402856), 
(299, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477402884), 
(300, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477402902), 
(301, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:118.70.26.25', '', 0, 1477407489), 
(302, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477407769), 
(303, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477408088), 
(304, 'vi', 'photos', 'Edit A Album', 'album_id: 7', '', 1, 1477408966), 
(305, 'vi', 'photos', 'Edit A Album', 'album_id: 7', '', 1, 1477409843), 
(306, 'vi', 'login', '[quantriweb] Thoát khỏi tài khoản Quản trị', ' Client IP:118.70.26.25', '', 0, 1477412462), 
(307, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:118.70.26.25', '', 0, 1477413778), 
(308, 'vi', 'photos', 'Edit A Album', 'album_id: 6', '', 1, 1477415839), 
(309, 'vi', 'photos', 'Edit A Album', 'album_id: 6', '', 1, 1477415944), 
(310, 'vi', 'photos', 'Edit A Album', 'album_id: 6', '', 1, 1477416196), 
(311, 'vi', 'photos', 'Edit A Album', 'album_id: 6', '', 1, 1477416304), 
(312, 'vi', 'photos', 'Edit A Album', 'album_id: 6', '', 1, 1477416473), 
(313, 'vi', 'upload', 'Upload file', 'uploads/dau-anh.png', '', 1, 1477417955), 
(314, 'vi', 'photos', 'Edit A Album', 'album_id: 5', '', 1, 1477418018), 
(315, 'vi', 'photos', 'Edit A Album', 'album_id: 5', '', 1, 1477418193), 
(316, 'vi', 'photos', 'Edit A Album', 'album_id: 4', '', 1, 1477419371), 
(317, 'vi', 'photos', 'Edit A Album', 'album_id: 4', '', 1, 1477419410), 
(318, 'vi', 'photos', 'Edit A Album', 'album_id: 3', '', 1, 1477420047), 
(319, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:113.182.105.78', '', 0, 1477449363), 
(320, 'vi', 'news', 'Xóa bài viêt', 'Ra mắt công ty mã nguồn mở đầu tiên tại Việt Nam, Hãy trở thành nhà cung cấp dịch vụ của NukeViet&#33;, Tuyển dụng lập trình viên PHP phát triển NukeViet, Tuyển dụng chuyên viên đồ hoạ phát triển NukeViet, Tuyển dụng lập trình viên front-end (HTML/CSS/JS) phát triển NukeViet, Mã nguồn mở NukeViet giành giải ba Nhân tài đất Việt 2011, NukeViet được ưu tiên mua sắm, sử dụng trong cơ quan, tổ chức nhà nước, Công ty VINADES tuyển dụng nhân viên kinh doanh, Chương trình thực tập sinh tại công ty VINADES, Học việc tại công ty VINADES, NukeViet được Bộ GD&amp;ĐT đưa vào Hướng dẫn thực hiện nhiệm vụ CNTT năm học 2015 - 2016, Hỗ trợ tập huấn và triển khai NukeViet cho các Phòng, Sở GD&amp;ĐT, NukeViet 4.0 có gì mới?, Chọn nhà cung cấp Hosting nào tốt cho NukeViet?', '', 1, 1477449403), 
(321, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tuyển dụng', '', 1, 1477449448), 
(322, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Đối tác', '', 1, 1477449454), 
(323, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Sản phẩm', '', 1, 1477449458), 
(324, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Thông cáo báo chí', '', 1, 1477449463), 
(325, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Bản tin nội bộ', '', 1, 1477449465), 
(326, 'vi', 'news', 'Xóa Chuyên mục và các bài viết', 'Tin công nghệ', '', 1, 1477449468), 
(327, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/bi-quyet-thiet-ke-noi-that-chung-cu-dep.jpg', '', 1, 1477449546), 
(328, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/bi-quyet-thiet-ke-noi-that-chung-cu-dep-3.jpg', '', 1, 1477449562), 
(329, 'vi', 'news', 'Thêm bài viết', 'BÍ QUYẾT THIẾT KẾ NỘI THẤT CHUNG CƯ MANG DẤU ẤN RIÊNG', '', 1, 1477449577), 
(330, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/khong_gian_phong_ngu_lang_man_va_phong_cach_voi_gam_mau_nau85.jpg', '', 1, 1477449655), 
(331, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau.jpg', '', 1, 1477449687), 
(332, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau2.jpg', '', 1, 1477449705), 
(333, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau3.jpg', '', 1, 1477449723), 
(334, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau5.jpg', '', 1, 1477449745), 
(335, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau6.jpg', '', 1, 1477449771), 
(336, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau7.jpg', '', 1, 1477449787), 
(337, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau9.jpg', '', 1, 1477449812), 
(338, 'vi', 'news', 'Thêm bài viết', 'XU HƯỚNG THIẾT KẾ', '', 1, 1477449818), 
(339, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/up-012.jpg', '', 1, 1477450042), 
(340, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/up-02.jpg', '', 1, 1477450062), 
(341, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/up-03.jpg', '', 1, 1477450087), 
(342, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/up-04.jpg', '', 1, 1477450115), 
(343, 'vi', 'news', 'Thêm bài viết', 'Cách bố trí sofa hợp phong thủy', '', 1, 1477450135), 
(344, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/kennedy_26311r153.jpg', '', 1, 1477450180), 
(345, 'vi', 'upload', 'Upload file', 'uploads/news/2016_10/image0021.jpg', '', 1, 1477450212), 
(346, 'vi', 'news', 'Thêm bài viết', 'Kinh nghiệm chọn mua sofa da', '', 1, 1477450222), 
(347, 'vi', 'themes', 'Thêm block', 'Name : Tin mới nhất', '', 1, 1477450313), 
(348, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:113.182.105.78', '', 0, 1477454834), 
(349, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:113.182.105.78', '', 0, 1477461212), 
(350, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:118.70.187.75', '', 0, 1477480959), 
(351, 'vi', 'photos', 'Edit A Album', 'album_id: 2', '', 1, 1477482286), 
(352, 'vi', 'login', '[quantriweb] Thoát khỏi tài khoản Quản trị', ' Client IP:118.70.187.75', '', 0, 1477482391), 
(353, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:118.70.187.75', '', 0, 1477482405), 
(354, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:118.70.187.75', '', 0, 1477482493), 
(355, 'vi', 'photos', 'Edit A Album', 'album_id: 2', '', 1, 1477482562), 
(356, 'vi', 'photos', 'Edit A Album', 'album_id: 2', '', 1, 1477482620), 
(357, 'vi', 'photos', 'Edit A Album', 'album_id: 2', '', 1, 1477482665), 
(358, 'vi', 'photos', 'Edit A Album', 'album_id: 2', '', 1, 1477482721), 
(359, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:118.70.187.75', '', 0, 1477482806), 
(360, 'vi', 'photos', 'Edit A Album', 'album_id: 2', '', 1, 1477482975), 
(361, 'vi', 'photos', 'Edit A Album', 'album_id: 1', '', 1, 1477483847), 
(362, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:::1', '', 0, 1477602584), 
(363, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:::1', '', 0, 1477603816), 
(364, 'vi', 'login', '[admin] Đăng nhập Thất bại', ' Client IP:::1', '', 0, 1477603818), 
(365, 'vi', 'login', '[quantriweb] Đăng nhập', ' Client IP:::1', '', 0, 1477604021), 
(366, 'vi', 'users', 'log_edit_user', 'userid 1', '', 1, 1477604151), 
(367, 'vi', 'slider', 'Thêm nhóm', 'group_id: 3', '', 1, 1477604171), 
(368, 'vi', 'slider', 'Thêm nhóm', 'group_id: 4', '', 1, 1477604171), 
(369, 'vi', 'slider', 'log_del_group', '3', '', 1, 1477604176), 
(370, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 9', '', 1, 1477604436), 
(371, 'vi', 'themes', 'Thêm block', 'Name : global slider', '', 1, 1477604496), 
(372, 'vi', 'upload', 'Upload file', 'uploads/slider/images/01.jpg', '', 1, 1477606308), 
(373, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 10', '', 1, 1477606330), 
(374, 'vi', 'upload', 'Upload file', 'uploads/slider/images/02.jpg', '', 1, 1477606412), 
(375, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 11', '', 1, 1477606430), 
(376, 'vi', 'upload', 'Upload file', 'uploads/slider/images/03.jpg', '', 1, 1477606584), 
(377, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 12', '', 1, 1477606588), 
(378, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 11', '', 1, 1477606612), 
(379, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477607352), 
(380, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477607855), 
(381, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477608436), 
(382, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477608777), 
(383, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 12', '', 1, 1477608861), 
(384, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 12', '', 1, 1477608988), 
(385, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477609086), 
(386, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477610886), 
(387, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477629200), 
(388, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477629225), 
(389, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 11', '', 1, 1477629272), 
(390, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477629648), 
(391, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477629791), 
(392, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477629801), 
(393, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477629806), 
(394, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477629912), 
(395, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477629917), 
(396, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477630234), 
(397, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477630234), 
(398, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477630321), 
(399, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477630325), 
(400, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 12', '', 1, 1477630380), 
(401, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477630755), 
(402, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1477630926), 
(403, 'vi', 'slider', 'Thêm nhóm', 'group_id: 5', '', 1, 1477631925), 
(404, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 13', '', 1, 1477631982), 
(405, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 14', '', 1, 1477632052), 
(406, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 15', '', 1, 1477632072), 
(407, 'vi', 'themes', 'Thêm block', 'Name : global slider', '', 1, 1477632113), 
(408, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1477632150), 
(409, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1477632234), 
(410, 'vi', 'slider', 'log_add_template', 'template_id: 5', '', 1, 1477633057), 
(411, 'vi', 'slider', 'log_edit_template', 'template_id: 5', '', 1, 1477633083), 
(412, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1477633148), 
(413, 'vi', 'themes', 'Thêm block', 'Name : global slider', '', 1, 1477635196), 
(414, 'vi', 'themes', 'Sửa block', 'Name : global slider', '', 1, 1477635238), 
(415, 'vi', 'themes', 'Thêm block', 'Name : global slider', '', 1, 1477636969), 
(416, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477668413), 
(417, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477668429), 
(418, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477669748), 
(419, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477669819), 
(420, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477670994), 
(421, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477670997), 
(422, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477671000), 
(423, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 13', '', 1, 1477671141), 
(424, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 14', '', 1, 1477671177), 
(425, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 15', '', 1, 1477671188), 
(426, 'vi', 'slider', 'Thêm nhóm', 'group_id: 6', '', 1, 1477671611), 
(427, 'vi', 'slider', 'log_add_template', 'template_id: 6', '', 1, 1477671671), 
(428, 'vi', 'upload', 'Upload file', 'uploads/slider/images/001.jpg', '', 1, 1477671816), 
(429, 'vi', 'upload', 'Upload file', 'uploads/slider/images/002.jpg', '', 1, 1477671817), 
(430, 'vi', 'upload', 'Upload file', 'uploads/slider/images/003.jpg', '', 1, 1477671817), 
(431, 'vi', 'upload', 'Upload file', 'uploads/slider/images/004.jpg', '', 1, 1477671817), 
(432, 'vi', 'upload', 'Upload file', 'uploads/slider/images/005.jpg', '', 1, 1477671817), 
(433, 'vi', 'upload', 'Upload file', 'uploads/slider/images/006.jpg', '', 1, 1477671818), 
(434, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 16', '', 1, 1477671825), 
(435, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 17', '', 1, 1477671848), 
(436, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 18', '', 1, 1477671859), 
(437, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 19', '', 1, 1477671877), 
(438, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 20', '', 1, 1477671891), 
(439, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 21', '', 1, 1477671911), 
(440, 'vi', 'themes', 'Thêm block', 'Name : global slider', '', 1, 1477671959), 
(441, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477671968), 
(442, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477673017), 
(443, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477673021), 
(444, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477673328), 
(445, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477673330), 
(446, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477673365), 
(447, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477673369), 
(448, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477673900), 
(449, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477674511), 
(450, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477674515), 
(451, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477674635), 
(452, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477674740), 
(453, 'vi', 'themes', 'Thêm block', 'Name : global slider', '', 1, 1477675020), 
(454, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477676540), 
(455, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477678288), 
(456, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477678327), 
(457, 'vi', 'themes', 'Thêm block', 'Name : Tin mới nhất', '', 1, 1477678889), 
(458, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477679860), 
(459, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477679906), 
(460, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477683138), 
(461, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477683145), 
(462, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477683151), 
(463, 'vi', 'news', 'Sửa bài viết', 'Bí quyết thiết ké nội thất chung cư theo phong cách riêng', '', 1, 1477684146), 
(464, 'vi', 'news', 'Sửa bài viết', 'Xu hướng thiết kế', '', 1, 1477684169), 
(465, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477684278), 
(466, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477684362), 
(467, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477684576), 
(468, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477684576), 
(469, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477686377), 
(470, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477718835), 
(471, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477718852), 
(472, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477718856), 
(473, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477718861), 
(474, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477719623), 
(475, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477719627), 
(476, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477719631), 
(477, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477719958), 
(478, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477719961), 
(479, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720064), 
(480, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720067), 
(481, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720138), 
(482, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720144), 
(483, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720243), 
(484, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720247), 
(485, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720812), 
(486, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720816), 
(487, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720818), 
(488, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720901), 
(489, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720980), 
(490, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477720983), 
(491, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721044), 
(492, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721044), 
(493, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721047), 
(494, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721235), 
(495, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721237), 
(496, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721240), 
(497, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721540), 
(498, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721542), 
(499, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721545), 
(500, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721767), 
(501, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477721770), 
(502, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477722446), 
(503, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477722450), 
(504, 'vi', 'weblinks', 'Sửa liên kết', 'Kiến trúc đ&#x002F;m²', '', 1, 1477722899), 
(505, 'vi', 'weblinks', 'Sửa liên kết', 'Kiến trúc đ&#x002F;m²', '', 1, 1477722965), 
(506, 'vi', 'weblinks', 'Sửa liên kết', 'Kiến trúc đ&#x002F;m²', '', 1, 1477723006), 
(507, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477723107), 
(508, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477723141), 
(509, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477723144), 
(510, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477723388), 
(511, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477723390), 
(512, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477723667), 
(513, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477723671), 
(514, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477724153), 
(515, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477724156), 
(516, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1477724261), 
(517, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1477724261), 
(518, 'vi', 'shops', 'Edit A Product', 'ID: 3', '', 1, 1477724350), 
(519, 'vi', 'shops', 'Edit A Product', 'ID: 1', '', 1, 1477724403), 
(520, 'vi', 'shops', 'Edit A Product', 'ID: 1', '', 1, 1477724467), 
(521, 'vi', 'shops', 'Edit A Product', 'ID: 3', '', 1, 1477724524), 
(522, 'vi', 'shops', 'Edit A Product', 'ID: 3', '', 1, 1477724565), 
(523, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1477724582), 
(524, 'vi', 'shops', 'Edit A Product', 'ID: 3', '', 1, 1477724598), 
(525, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1477724633), 
(526, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477725027), 
(527, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477725147), 
(528, 'vi', 'photos', 'Edit A Album', 'album_id: 8', '', 1, 1477725173), 
(529, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477726043), 
(530, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477726046), 
(531, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477726249), 
(532, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477726301), 
(533, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477726305), 
(534, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477769220), 
(535, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477769231), 
(536, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477769233), 
(537, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477769237), 
(538, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477769525), 
(539, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477769529), 
(540, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477769739), 
(541, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477770485), 
(542, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477770489), 
(543, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477770653), 
(544, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477773441), 
(545, 'vi', 'upload', 'Upload file', 'uploads/shops/files/thong-tin-van-tat-de-tham-khao.doc', '', 1, 1477773596), 
(546, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1477773682), 
(547, 'vi', 'shops', 'Edit A Product', 'ID: 3', '', 1, 1477773710), 
(548, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477774348), 
(549, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477774355), 
(550, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1477774419), 
(551, 'vi', 'shops', 'Edit A Product', 'ID: 4', '', 1, 1477774442), 
(552, 'vi', 'shops', 'Edit A Product', 'ID: 3', '', 1, 1477774454), 
(553, 'vi', 'shops', 'Edit A Product', 'ID: 2', '', 1, 1477774463), 
(554, 'vi', 'shops', 'Edit A Product', 'ID: 2', '', 1, 1477774469), 
(555, 'vi', 'shops', 'Edit A Product', 'ID: 1', '', 1, 1477774476), 
(556, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477774481), 
(557, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_10/111.jpg', '', 1, 1477774968), 
(558, 'vi', 'shops', 'log_edit_catalog', 'id 1', '', 1, 1477775045), 
(559, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477775926), 
(560, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477776125), 
(561, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477776509), 
(562, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477776521), 
(563, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477776549), 
(564, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477776711), 
(565, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477776730), 
(566, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_10/12.jpg', '', 1, 1477776851), 
(567, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_10/12_1.jpg', '', 1, 1477776851), 
(568, 'vi', 'shops', 'log_edit_catalog', 'id 3', '', 1, 1477776889), 
(569, 'vi', 'upload', 'Upload file', 'uploads/11.jpg', '', 1, 1477776954), 
(570, 'vi', 'shops', 'log_edit_catalog', 'id 1', '', 1, 1477776959), 
(571, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_10/11.jpg', '', 1, 1477776982), 
(572, 'vi', 'shops', 'log_edit_catalog', 'id 1', '', 1, 1477776988), 
(573, 'vi', 'upload', 'Upload file', 'uploads/shops/2016_10/13.jpg', '', 1, 1477777037), 
(574, 'vi', 'shops', 'log_edit_catalog', 'id 1', '', 1, 1477777042), 
(575, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477777120), 
(576, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477777123), 
(577, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477777332), 
(578, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477777335), 
(579, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477777548), 
(580, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477777676), 
(581, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477777683), 
(582, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477777685), 
(583, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477777690), 
(584, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477800828), 
(585, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477802596), 
(586, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477802613), 
(587, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477802616), 
(588, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477802621), 
(589, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477802694), 
(590, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477802766), 
(591, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477802769), 
(592, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477802816), 
(593, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477844467), 
(594, 'vi', 'about', 'Edit', 'ID: 9', '', 1, 1477844978), 
(595, 'vi', 'themes', 'Thiết lập layout theme: \"default\"', '', '', 1, 1477845117), 
(596, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477845212), 
(597, 'vi', 'themes', 'Thêm block', 'Name : global about', '', 1, 1477845414), 
(598, 'vi', 'themes', 'Sửa block', 'Name : global about', '', 1, 1477845445), 
(599, 'vi', 'themes', 'Sửa block', 'Name : global about', '', 1, 1477845458), 
(600, 'vi', 'upload', 'Upload file', 'uploads/page/nguhanh.jpg', '', 1, 1477845689), 
(601, 'vi', 'page', 'Edit', 'ID: 1', '', 1, 1477845695), 
(602, 'vi', 'page', 'Edit', 'ID: 1', '', 1, 1477845808), 
(603, 'vi', 'contact', 'log_edit_row', 'id: 3 Loại công trình', '', 1, 1477846331), 
(604, 'vi', 'themes', 'Thêm block', 'Name : global counter', '', 1, 1477846523), 
(605, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477848131), 
(606, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477885430), 
(607, 'vi', 'slider', 'Thêm nhóm', 'group_id: 7', '', 1, 1477885475), 
(608, 'vi', 'upload', 'Upload file', 'uploads/slider/images/1453868678.png', '', 1, 1477885528), 
(609, 'vi', 'upload', 'Upload file', 'uploads/slider/images/1453868688.png', '', 1, 1477885529), 
(610, 'vi', 'upload', 'Upload file', 'uploads/slider/images/1453868707.png', '', 1, 1477885529), 
(611, 'vi', 'upload', 'Upload file', 'uploads/slider/images/1456475557.png', '', 1, 1477885530), 
(612, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 22', '', 1, 1477885543), 
(613, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 23', '', 1, 1477885560), 
(614, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 24', '', 1, 1477885579), 
(615, 'vi', 'slider', 'Thêm ảnh', 'photo_id: 25', '', 1, 1477885600), 
(616, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 25', '', 1, 1477885610), 
(617, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 22', '', 1, 1477885630), 
(618, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 23', '', 1, 1477885645), 
(619, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 24', '', 1, 1477885663), 
(620, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 25', '', 1, 1477885710), 
(621, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477885717), 
(622, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477885721), 
(623, 'vi', 'themes', 'Thêm block', 'Name : global slider', '', 1, 1477885855), 
(624, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 24', '', 1, 1477888426), 
(625, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477888507), 
(626, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477888513), 
(627, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477888521), 
(628, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477889385), 
(629, 'vi', 'upload', 'Upload file', 'uploads/slider/images/01_1.jpg', '', 1, 1477889412), 
(630, 'vi', 'upload', 'Upload file', 'uploads/slider/images/02_1.jpg', '', 1, 1477889413), 
(631, 'vi', 'upload', 'Upload file', 'uploads/slider/images/03_1.jpg', '', 1, 1477889413), 
(632, 'vi', 'upload', 'Upload file', 'uploads/slider/images/04.jpg', '', 1, 1477889414), 
(633, 'vi', 'upload', 'Upload file', 'uploads/slider/images/05.jpg', '', 1, 1477889415), 
(634, 'vi', 'upload', 'Upload file', 'uploads/slider/images/06.jpg', '', 1, 1477889415), 
(635, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 1', '', 1, 1477889422), 
(636, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 2', '', 1, 1477889455), 
(637, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 3', '', 1, 1477889462), 
(638, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 4', '', 1, 1477889470), 
(639, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 5', '', 1, 1477889478), 
(640, 'vi', 'slider', 'Chỉnh sửa ảnh', 'photo_id: 6', '', 1, 1477889487), 
(641, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477889990), 
(642, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477889994), 
(643, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477890451), 
(644, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477890480), 
(645, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477890579), 
(646, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477890579), 
(647, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477890582), 
(648, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477890958), 
(649, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477890982), 
(650, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477891122), 
(651, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477891185), 
(652, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477891190), 
(653, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477891280), 
(654, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477891313), 
(655, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477891320), 
(656, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477891393), 
(657, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477891721), 
(658, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477891725), 
(659, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477891996), 
(660, 'vi', 'shops', 'Cấu hình module', 'Setting', '', 1, 1477892046), 
(661, 'vi', 'shops', 'Edit A Product', 'ID: 4', '', 1, 1477892065), 
(662, 'vi', 'shops', 'Edit A Product', 'ID: 3', '', 1, 1477892080), 
(663, 'vi', 'shops', 'Edit A Product', 'ID: 2', '', 1, 1477892091), 
(664, 'vi', 'shops', 'log_edit_catalog', 'id 2', '', 1, 1477892148), 
(665, 'vi', 'shops', 'log_edit_catalog', 'id 3', '', 1, 1477892158), 
(666, 'vi', 'shops', 'log_edit_catalog', 'id 2', '', 1, 1477892181), 
(667, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477892186), 
(668, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477892189), 
(669, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477892228), 
(670, 'vi', 'shops', 'log_edit_catalog', 'id 1', '', 1, 1477892246), 
(671, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477892252), 
(672, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477892256), 
(673, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:::1', '', 0, 1477893750), 
(674, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477893818), 
(675, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1477893821), 
(676, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:::1', '', 0, 1477893823), 
(677, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:14.167.35.21', '', 0, 1477845960), 
(678, 'vi', 'login', '[admin] Đăng nhập', ' Client IP:14.175.225.154', '', 0, 1478747560), 
(679, 'vi', 'themes', 'Sửa block', 'Name : Liên hệ', '', 1, 1478747675), 
(680, 'vi', 'themes', 'Sửa block', 'Name : Đồng hành cùng chúng tôi', '', 1, 1478747712), 
(681, 'vi', 'webtools', 'Dọn dẹp hệ thống', 'clearcache, clearfiletemp, clearerrorlogs, clearip_logs', '', 1, 1478747847), 
(682, 'vi', 'login', '[admin] Thoát khỏi tài khoản Quản trị', ' Client IP:14.175.225.154', '', 0, 1478748445);


-- ---------------------------------------


--
-- Table structure for table `az_notification`
--

DROP TABLE IF EXISTS `az_notification`;
CREATE TABLE `az_notification` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `send_to` mediumint(8) unsigned NOT NULL,
  `send_from` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `area` tinyint(1) unsigned NOT NULL,
  `language` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `obid` int(11) unsigned NOT NULL DEFAULT '0',
  `type` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `view` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_plugin`
--

DROP TABLE IF EXISTS `az_plugin`;
CREATE TABLE `az_plugin` (
  `pid` tinyint(4) NOT NULL AUTO_INCREMENT,
  `plugin_file` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `plugin_area` tinyint(4) NOT NULL,
  `weight` tinyint(4) NOT NULL,
  PRIMARY KEY (`pid`),
  UNIQUE KEY `plugin_file` (`plugin_file`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_plugin`
--

INSERT INTO `az_plugin` VALUES
(1, 'qrcode.php', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `az_sessions`
--

DROP TABLE IF EXISTS `az_sessions`;
CREATE TABLE `az_sessions` (
  `session_id` varchar(50)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `onl_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `session_id` (`session_id`),
  KEY `onl_time` (`onl_time`)
) ENGINE=MEMORY  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_sessions`
--

INSERT INTO `az_sessions` VALUES
('son8a63hchvt614o1b35pu7s57', 0, 'guest', 1487340807);


-- ---------------------------------------


--
-- Table structure for table `az_setup`
--

DROP TABLE IF EXISTS `az_setup`;
CREATE TABLE `az_setup` (
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `tables` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `version` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup_time` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `lang` (`lang`,`module`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_setup_extensions`
--

DROP TABLE IF EXISTS `az_setup_extensions`;
CREATE TABLE `az_setup_extensions` (
  `id` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_sys` tinyint(1) NOT NULL DEFAULT '0',
  `is_virtual` tinyint(1) NOT NULL DEFAULT '0',
  `basename` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `table_prefix` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `version` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `addtime` int(11) NOT NULL DEFAULT '0',
  `author` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  UNIQUE KEY `title` (`type`,`title`),
  KEY `id` (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_setup_extensions`
--

INSERT INTO `az_setup_extensions` VALUES
(0, 'module', 'about', 0, 0, 'page', 'about', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'siteterms', 0, 0, 'page', 'siteterms', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(19, 'module', 'banners', 1, 0, 'banners', 'banners', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(20, 'module', 'contact', 0, 1, 'contact', 'contact', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(1, 'module', 'news', 0, 1, 'news', 'news', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(21, 'module', 'voting', 0, 0, 'voting', 'voting', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'slider', 0, 1, 'slider', 'slider', '4.0.27 1421848859', 1475290328, 'DANGDINHTU (dlinhvan@gmail.com)', ''), 
(284, 'module', 'seek', 1, 0, 'seek', 'seek', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(24, 'module', 'users', 1, 1, 'users', 'users', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(27, 'module', 'statistics', 0, 0, 'statistics', 'statistics', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(29, 'module', 'menu', 0, 0, 'menu', 'menu', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(283, 'module', 'feeds', 1, 0, 'feeds', 'feeds', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(282, 'module', 'page', 1, 1, 'page', 'page', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(281, 'module', 'comment', 1, 0, 'comment', 'comment', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(312, 'module', 'freecontent', 0, 0, 'freecontent', 'freecontent', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(307, 'theme', 'default', 0, 0, 'default', 'default', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(311, 'theme', 'mobile_default', 0, 0, 'mobile_default', 'mobile_default', '4.0.29 1463652000', 1475277519, 'VINADES (contact@vinades.vn)', ''), 
(0, 'module', 'photos', 0, 1, 'photos', 'photos', '1.3.11 1464001200', 1475296368, 'KENNY NGUYEN (nguyentiendat713@gmail.com)', ''), 
(0, 'module', 'weblinks', 0, 1, 'weblinks', 'weblinks', '4.0.28 1287532800', 1475395554, 'VINADES (contact@vinades.vn)', ''), 
(31, 'module', 'shops', 0, 1, 'shops', 'shops', '4.0.29 1475427381', 1475427381, 'VINADES.,JSC (nukeviet.store@vinades.vn)', 'Module shops cho phép xây dựng website thương mại điện tử nhanh chóng và chuyên nghiệp.');


-- ---------------------------------------


--
-- Table structure for table `az_setup_language`
--

DROP TABLE IF EXISTS `az_setup_language`;
CREATE TABLE `az_setup_language` (
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `setup` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_setup_language`
--

INSERT INTO `az_setup_language` VALUES
('vi', 1);


-- ---------------------------------------


--
-- Table structure for table `az_shops_block`
--

DROP TABLE IF EXISTS `az_shops_block`;
CREATE TABLE `az_shops_block` (
  `bid` int(11) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_block`
--

INSERT INTO `az_shops_block` VALUES
(1, 4, 0), 
(1, 3, 0), 
(1, 2, 0), 
(1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `az_shops_block_cat`
--

DROP TABLE IF EXISTS `az_shops_block_cat`;
CREATE TABLE `az_shops_block_cat` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `image` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_description` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_keywords` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`bid`),
  UNIQUE KEY `vi_alias` (`vi_alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_block_cat`
--

INSERT INTO `az_shops_block_cat` VALUES
(1, 0, '', 1, 1476446751, 1476446751, 'Sản phẩm mới', 'San-pham-moi', '', '');


-- ---------------------------------------


--
-- Table structure for table `az_shops_carrier`
--

DROP TABLE IF EXISTS `az_shops_carrier`;
CREATE TABLE `az_shops_carrier` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_carrier_config`
--

DROP TABLE IF EXISTS `az_shops_carrier_config`;
CREATE TABLE `az_shops_carrier_config` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_carrier_config_items`
--

DROP TABLE IF EXISTS `az_shops_carrier_config_items`;
CREATE TABLE `az_shops_carrier_config_items` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `cid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) unsigned NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_carrier_config_location`
--

DROP TABLE IF EXISTS `az_shops_carrier_config_location`;
CREATE TABLE `az_shops_carrier_config_location` (
  `cid` tinyint(3) unsigned NOT NULL,
  `iid` smallint(4) unsigned NOT NULL,
  `lid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `cid` (`cid`,`lid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_carrier_config_weight`
--

DROP TABLE IF EXISTS `az_shops_carrier_config_weight`;
CREATE TABLE `az_shops_carrier_config_weight` (
  `iid` smallint(4) unsigned NOT NULL,
  `weight` float unsigned NOT NULL,
  `weight_unit` varchar(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `carrier_price` float NOT NULL,
  `carrier_price_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_catalogs`
--

DROP TABLE IF EXISTS `az_shops_catalogs`;
CREATE TABLE `az_shops_catalogs` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewcat` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` int(11) NOT NULL DEFAULT '0',
  `subcatid` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(4) NOT NULL DEFAULT '3',
  `typeprice` tinyint(4) NOT NULL DEFAULT '2',
  `form` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `group_price` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `viewdescriptionhtml` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `cat_allow_point` tinyint(1) NOT NULL DEFAULT '0',
  `cat_number_point` tinyint(4) NOT NULL DEFAULT '0',
  `cat_number_product` tinyint(4) NOT NULL DEFAULT '0',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_title_custom` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_description` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_descriptionhtml` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_keywords` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`catid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_catalogs`
--

INSERT INTO `az_shops_catalogs` VALUES
(1, 0, '2016_10/13.jpg', 1, 1, 0, 'viewcat_page_gird', 0, '', 1, 8, 3, 1, '', '', 1, '', 1475427543, 1477892246, '6', 0, 0, 0, 'Nội thất', '', 'noi-that', '', '10 năm kinh nghiệm trong ngành kiến trúc, nội thất và xây dựng, với hàng trăm khách hàng mỗi năm, Wonder là một công ty danh tiếng và đáng tin cậy trong việc cung cấp dịch vụ cho khách hàng tư nhân và doanh nghiệp.', ''), 
(2, 0, '', 2, 2, 0, 'viewcat_page_gird', 0, '', 1, 8, 3, 1, '', '', 1, '', 1475427557, 1477892181, '6', 0, 0, 0, 'Vật liệu nội thất', '', 'vat-lieu-noi-that', '', '', ''), 
(3, 0, '2016_10/12.jpg', 3, 3, 0, 'viewcat_page_gird', 0, '', 1, 8, 3, 1, '', '', 1, '', 1475427572, 1477892158, '6', 0, 0, 0, 'Đèn chiếu sáng', '', 'den-chieu-sang', '', 'Wonder áp dụng phong cách thiết kế đơn giản, bố trí nội thất thông minh, ánh sáng tràn ngập không gian với các khung cửa kính lớn và thiên về xu hướng cảnh quan màu xanh lá.', '');


-- ---------------------------------------


--
-- Table structure for table `az_shops_coupons`
--

DROP TABLE IF EXISTS `az_shops_coupons`;
CREATE TABLE `az_shops_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `code` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(1)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'p',
  `discount` float NOT NULL DEFAULT '0',
  `total_amount` float NOT NULL DEFAULT '0',
  `date_start` int(11) unsigned NOT NULL DEFAULT '0',
  `date_end` int(11) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon` int(11) unsigned NOT NULL DEFAULT '0',
  `uses_per_coupon_count` int(11) NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_coupons_history`
--

DROP TABLE IF EXISTS `az_shops_coupons_history`;
CREATE TABLE `az_shops_coupons_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_coupons_product`
--

DROP TABLE IF EXISTS `az_shops_coupons_product`;
CREATE TABLE `az_shops_coupons_product` (
  `cid` int(11) unsigned NOT NULL,
  `pid` int(11) unsigned NOT NULL,
  UNIQUE KEY `cid` (`cid`,`pid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_discounts`
--

DROP TABLE IF EXISTS `az_shops_discounts`;
CREATE TABLE `az_shops_discounts` (
  `did` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` smallint(6) NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `begin_time` int(11) unsigned NOT NULL DEFAULT '0',
  `end_time` int(11) unsigned NOT NULL DEFAULT '0',
  `config` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  KEY `begin_time` (`begin_time`,`end_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_field`
--

DROP TABLE IF EXISTS `az_shops_field`;
CREATE TABLE `az_shops_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `listtemplate` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `tab` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'textbox',
  `field_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sql_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `match_regex` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_callback` varchar(75)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `class` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `language` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_value` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_field_value_vi`
--

DROP TABLE IF EXISTS `az_shops_field_value_vi`;
CREATE TABLE `az_shops_field_value_vi` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `rows_id` int(11) unsigned NOT NULL,
  `field_id` mediumint(8) NOT NULL,
  `field_value` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `rows_id` (`rows_id`,`field_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_files`
--

DROP TABLE IF EXISTS `az_shops_files`;
CREATE TABLE `az_shops_files` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `filesize` int(11) unsigned NOT NULL DEFAULT '0',
  `extension` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `download_groups` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '-1',
  `status` tinyint(1) unsigned DEFAULT '1',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_files`
--

INSERT INTO `az_shops_files` VALUES
(1, 'thong-tin-van-tat-de-tham-khao.doc', 75776, 'doc', 1477773602, '-1', 1, 'Bản báo giá sản phẩm', '');


-- ---------------------------------------


--
-- Table structure for table `az_shops_files_rows`
--

DROP TABLE IF EXISTS `az_shops_files_rows`;
CREATE TABLE `az_shops_files_rows` (
  `id_rows` int(11) unsigned NOT NULL,
  `id_files` mediumint(8) unsigned NOT NULL,
  `download_hits` mediumint(8) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `id_files` (`id_files`,`id_rows`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_files_rows`
--

INSERT INTO `az_shops_files_rows` VALUES
(3, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `az_shops_group`
--

DROP TABLE IF EXISTS `az_shops_group`;
CREATE TABLE `az_shops_group` (
  `groupid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `image` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `viewgroup` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubgroup` int(11) NOT NULL DEFAULT '0',
  `subgroupid` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `indetail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `numpro` int(11) unsigned NOT NULL DEFAULT '0',
  `in_order` tinyint(2) NOT NULL DEFAULT '0',
  `is_require` tinyint(1) NOT NULL DEFAULT '0',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_description` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_keywords` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`groupid`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_group_cateid`
--

DROP TABLE IF EXISTS `az_shops_group_cateid`;
CREATE TABLE `az_shops_group_cateid` (
  `groupid` mediumint(8) unsigned NOT NULL,
  `cateid` mediumint(8) unsigned NOT NULL,
  UNIQUE KEY `groupid` (`groupid`,`cateid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_group_items`
--

DROP TABLE IF EXISTS `az_shops_group_items`;
CREATE TABLE `az_shops_group_items` (
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `group_id` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pro_id`,`group_id`),
  KEY `pro_id` (`pro_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_group_quantity`
--

DROP TABLE IF EXISTS `az_shops_group_quantity`;
CREATE TABLE `az_shops_group_quantity` (
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `listgroup` varchar(247)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) unsigned NOT NULL,
  UNIQUE KEY `pro_id` (`pro_id`,`listgroup`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_location`
--

DROP TABLE IF EXISTS `az_shops_location`;
CREATE TABLE `az_shops_location` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(4) unsigned NOT NULL DEFAULT '0',
  `sort` mediumint(8) NOT NULL DEFAULT '0',
  `lev` smallint(4) NOT NULL DEFAULT '0',
  `numsub` int(11) NOT NULL DEFAULT '0',
  `subid` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_money_vi`
--

DROP TABLE IF EXISTS `az_shops_money_vi`;
CREATE TABLE `az_shops_money_vi` (
  `id` mediumint(11) NOT NULL,
  `code` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange` float NOT NULL DEFAULT '0',
  `round` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `number_format` varchar(5)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',||.',
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_money_vi`
--

INSERT INTO `az_shops_money_vi` VALUES
(840, 'USD', 'US Dollar', '21000', '0.01', ',||.'), 
(704, 'VND', 'Vietnam Dong', '1', '100', ',||.');


-- ---------------------------------------


--
-- Table structure for table `az_shops_orders`
--

DROP TABLE IF EXISTS `az_shops_orders`;
CREATE TABLE `az_shops_orders` (
  `order_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_code` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `order_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_email` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_phone` varchar(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_address` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_id` int(11) unsigned NOT NULL DEFAULT '0',
  `shop_id` int(11) unsigned NOT NULL DEFAULT '0',
  `who_is` int(2) unsigned NOT NULL DEFAULT '0',
  `unit_total` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_total` double unsigned NOT NULL DEFAULT '0',
  `order_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `postip` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_view` tinyint(2) NOT NULL DEFAULT '0',
  `transaction_status` tinyint(4) NOT NULL,
  `transaction_id` int(11) NOT NULL DEFAULT '0',
  `transaction_count` int(11) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `user_id` (`user_id`),
  KEY `order_time` (`order_time`),
  KEY `shop_id` (`shop_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_orders_id`
--

DROP TABLE IF EXISTS `az_shops_orders_id`;
CREATE TABLE `az_shops_orders_id` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `proid` mediumint(9) NOT NULL,
  `num` mediumint(9) NOT NULL,
  `price` int(11) NOT NULL,
  `discount_id` smallint(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `orderid` (`order_id`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_orders_id_group`
--

DROP TABLE IF EXISTS `az_shops_orders_id_group`;
CREATE TABLE `az_shops_orders_id_group` (
  `order_i` int(11) NOT NULL,
  `group_id` mediumint(8) NOT NULL,
  UNIQUE KEY `orderid` (`order_i`,`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_orders_shipping`
--

DROP TABLE IF EXISTS `az_shops_orders_shipping`;
CREATE TABLE `az_shops_orders_shipping` (
  `id` tinyint(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` tinyint(11) unsigned NOT NULL,
  `ship_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_phone` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_location_id` mediumint(8) unsigned NOT NULL,
  `ship_address_extend` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ship_shops_id` tinyint(3) unsigned NOT NULL,
  `ship_carrier_id` tinyint(3) unsigned NOT NULL,
  `weight` float NOT NULL DEFAULT '0',
  `weight_unit` char(20)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `ship_price` float NOT NULL DEFAULT '0',
  `ship_price_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `add_time` (`add_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_payment`
--

DROP TABLE IF EXISTS `az_shops_payment`;
CREATE TABLE `az_shops_payment` (
  `payment` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `paymentname` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `images_button` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`payment`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_point`
--

DROP TABLE IF EXISTS `az_shops_point`;
CREATE TABLE `az_shops_point` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `point_total` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_point_history`
--

DROP TABLE IF EXISTS `az_shops_point_history`;
CREATE TABLE `az_shops_point_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL DEFAULT '0',
  `order_id` int(11) NOT NULL,
  `point` int(11) NOT NULL DEFAULT '0',
  `time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_point_queue`
--

DROP TABLE IF EXISTS `az_shops_point_queue`;
CREATE TABLE `az_shops_point_queue` (
  `order_id` int(11) NOT NULL,
  `point` mediumint(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_review`
--

DROP TABLE IF EXISTS `az_shops_review`;
CREATE TABLE `az_shops_review` (
  `review_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `sender` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int(1) NOT NULL,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`review_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_rows`
--

DROP TABLE IF EXISTS `az_shops_rows`;
CREATE TABLE `az_shops_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `listcatid` int(11) NOT NULL DEFAULT '0',
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `product_code` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `product_number` int(11) NOT NULL DEFAULT '0',
  `product_price` float NOT NULL DEFAULT '0',
  `price_config` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `money_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_unit` smallint(4) NOT NULL,
  `product_weight` float NOT NULL DEFAULT '0',
  `weight_unit` char(20)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `discount_id` smallint(6) NOT NULL DEFAULT '0',
  `homeimgfile` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `homeimgalt` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `otherimage` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `gift_from` int(11) unsigned NOT NULL DEFAULT '0',
  `gift_to` int(11) unsigned NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ratingdetail` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `allowed_send` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitslm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `num_sell` mediumint(8) NOT NULL DEFAULT '0',
  `showprice` tinyint(2) NOT NULL DEFAULT '0',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_gift_content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `vi_address` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `vi_alias` (`vi_alias`),
  KEY `listcatid` (`listcatid`),
  KEY `user_id` (`user_id`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_rows`
--

INSERT INTO `az_shops_rows` VALUES
(1, 1, 1, 1475427690, 1477774476, 1, 1475427690, 0, 2, 'S000001', 300, '2500000', '', 'VND', 1, '0', 'g', 0, '2016_10/absynth-magh-sideboard_1.jpg', 1, '', '', 0, 0, 0, 0, 1, 6, 1, '0', 1, 1, 1, 13, 0, 0, 0, 1, 'ABCDE', 'abcde', '<h3 id=\"reply-title\">Absynth-magh-sideboard</h3>', '<h3 id=\"reply-title\">Absynth-magh-sideboard</h3>', '', ''), 
(2, 3, 1, 1475433709, 1477892091, 1, 1475433709, 0, 2, 'S000002', 1, '132000', '', 'VND', 1, '0', 'g', 0, '2016_10/1-6.jpg', 1, '', '', 0, 0, 0, 0, 1, 6, 1, '0', 1, 1, 1, 11, 0, 0, 0, 1, 'Bóng đèn led – Ledbulb philips 10.5W', 'bong-den-led-ledbulb-philips-10-5w', 'Chỉ số truyền màu (CRI) được dùng để mô tả hiệu ứng của một nguồn sáng trên diện mạo màu. Ánh sáng ngoài trời tự nhiên có CRI là 100 và được dùng làm tiêu chuẩn so sánh đối với tất cả các nguồn sáng khác. CRI của các bóng đèn LED Philips luôn cao hơn 80, gần với giá trị nguồn ánh sáng mặt trời, phản ánh mức độ chân thật và tự nhiên của màu sắc.', '<p><strong>Thông số kỹ thuật</strong></p><ul>	<li><strong>Chất liệu :</strong>&nbsp;Thủy tinh</li>	<li><strong>Công suất :&nbsp;</strong>10.5w</li>	<li><strong>Màu sắc :&nbsp;</strong>Trắng</li>	<li><strong>Điện áp và tần số :&nbsp;</strong>AC 230V / 50-60Hz</li>	<li><strong>Quang thông</strong>: 1055&nbsp;Lm</li>	<li><strong>Nhiệt độ màu :&nbsp;</strong>2700K / 4000K</li>	<li><strong>Tuổi thọ :&nbsp;&nbsp;</strong>&gt; 20,000 giờ</li>	<li><strong>Chỉ số hoàn màu</strong>: 80Ra</li>	<li><strong>Đuôi đèn</strong>: A60</li></ul>', '', ''), 
(3, 1, 1, 1476446658, 1477892080, 1, 1476446658, 0, 2, 'S000003', 210, '1575000', '', 'VND', 1, '0', 'g', 0, '2016_10/absynth-magh-sideboard_1.jpg', 1, '', '', 0, 0, 0, 0, 1, 6, 1, '0', 1, 1, 1, 14, 0, 0, 0, 1, '10 năm kinh nghiệm', '10-nam-kinh-nghiem', '<h3 id=\"reply-title\">10 năm kinh nghiệm trong ngành kiến trúc</h3>', '<h3 id=\"reply-title\">10 năm kinh nghiệm trong ngành kiến trúc</h3>', '', ''), 
(4, 3, 1, 1476446666, 1477892065, 1, 1476446666, 0, 2, 'S000004', 0, '132000', '', 'VND', 1, '0', 'g', 0, '2016_10/1-6.jpg', 1, '', '', 0, 0, 0, 0, 1, 6, 1, '0', 1, 1, 1, 9, 0, 0, 0, 1, 'Bóng đèn led – Ledbulb philips 10.5W', 'bong-den-led-ledbulb-philips-10-5w1', 'Chỉ số truyền màu (CRI) được dùng để mô tả hiệu ứng của một nguồn sáng trên diện mạo màu. Ánh sáng ngoài trời tự nhiên có CRI là 100 và được dùng làm tiêu chuẩn so sánh đối với tất cả các nguồn sáng khác. CRI của các bóng đèn LED Philips luôn cao hơn 80, gần với giá trị nguồn ánh sáng mặt trời, phản ánh mức độ chân thật và tự nhiên của màu sắc.', '<p><strong>Thông số kỹ thuật</strong></p><ul>	<li><strong>Chất liệu :</strong>&nbsp;Thủy tinh</li>	<li><strong>Công suất :&nbsp;</strong>10.5w</li>	<li><strong>Màu sắc :&nbsp;</strong>Trắng</li>	<li><strong>Điện áp và tần số :&nbsp;</strong>AC 230V / 50-60Hz</li>	<li><strong>Quang thông</strong>: 1055&nbsp;Lm</li>	<li><strong>Nhiệt độ màu :&nbsp;</strong>2700K / 4000K</li>	<li><strong>Tuổi thọ :&nbsp;&nbsp;</strong>&gt; 20,000 giờ</li>	<li><strong>Chỉ số hoàn màu</strong>: 80Ra</li>	<li><strong>Đuôi đèn</strong>: A60</li></ul>', '', '');


-- ---------------------------------------


--
-- Table structure for table `az_shops_shops`
--

DROP TABLE IF EXISTS `az_shops_shops`;
CREATE TABLE `az_shops_shops` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `address` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL,
  `status` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_shops_carrier`
--

DROP TABLE IF EXISTS `az_shops_shops_carrier`;
CREATE TABLE `az_shops_shops_carrier` (
  `shops_id` tinyint(3) unsigned NOT NULL,
  `carrier_id` tinyint(3) unsigned NOT NULL,
  `config_id` tinyint(3) unsigned NOT NULL,
  UNIQUE KEY `shops_id` (`shops_id`,`carrier_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_tabs`
--

DROP TABLE IF EXISTS `az_shops_tabs`;
CREATE TABLE `az_shops_tabs` (
  `id` int(3) unsigned NOT NULL AUTO_INCREMENT,
  `icon` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `content` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_tabs`
--

INSERT INTO `az_shops_tabs` VALUES
(1, '', 'content_detail', 1, 1, 'Thông tin sản phẩm'), 
(2, '', 'content_comments', 2, 1, 'Bình luận'), 
(3, '', 'content_rate', 3, 1, 'Đánh giá sản phẩm'), 
(4, '', 'content_download', 4, 1, 'Tải báo giá');


-- ---------------------------------------


--
-- Table structure for table `az_shops_tags_id_vi`
--

DROP TABLE IF EXISTS `az_shops_tags_id_vi`;
CREATE TABLE `az_shops_tags_id_vi` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `sid` (`id`,`tid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_tags_id_vi`
--

INSERT INTO `az_shops_tags_id_vi` VALUES
(2, 1, 'mô tả'), 
(2, 2, 'diện mạo'), 
(2, 3, 'ánh sáng'), 
(2, 4, 'ngoài trời'), 
(2, 5, 'tự nhiên'), 
(2, 6, 'tiêu chuẩn'), 
(2, 7, 'so sánh'), 
(2, 8, 'tất cả'), 
(2, 9, 'bóng đèn'), 
(2, 10, 'giá trị'), 
(2, 11, 'mặt trời'), 
(2, 12, 'phản ánh'), 
(2, 13, 'mức độ'), 
(4, 1, 'mô tả'), 
(4, 2, 'diện mạo'), 
(4, 3, 'ánh sáng'), 
(4, 4, 'ngoài trời'), 
(4, 5, 'tự nhiên'), 
(4, 6, 'tiêu chuẩn'), 
(4, 7, 'so sánh'), 
(4, 8, 'tất cả'), 
(4, 9, 'bóng đèn'), 
(4, 10, 'giá trị'), 
(4, 11, 'mặt trời'), 
(4, 12, 'phản ánh'), 
(4, 13, 'mức độ'), 
(3, 14, 'kinh nghiệm');


-- ---------------------------------------


--
-- Table structure for table `az_shops_tags_vi`
--

DROP TABLE IF EXISTS `az_shops_tags_vi`;
CREATE TABLE `az_shops_tags_vi` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numpro` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=15  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_tags_vi`
--

INSERT INTO `az_shops_tags_vi` VALUES
(1, 2, 'mô-tả', '', '', 'mô tả'), 
(2, 2, 'diện-mạo', '', '', 'diện mạo'), 
(3, 2, 'ánh-sáng', '', '', 'ánh sáng'), 
(4, 2, 'ngoài-trời', '', '', 'ngoài trời'), 
(5, 2, 'tự-nhiên', '', '', 'tự nhiên'), 
(6, 2, 'tiêu-chuẩn', '', '', 'tiêu chuẩn'), 
(7, 2, 'so-sánh', '', '', 'so sánh'), 
(8, 2, 'tất-cả', '', '', 'tất cả'), 
(9, 2, 'bóng-đèn', '', '', 'bóng đèn'), 
(10, 2, 'giá-trị', '', '', 'giá trị'), 
(11, 2, 'mặt-trời', '', '', 'mặt trời'), 
(12, 2, 'phản-ánh', '', '', 'phản ánh'), 
(13, 2, 'mức-độ', '', '', 'mức độ'), 
(14, 1, 'kinh-nghiệm', '', '', 'kinh nghiệm');


-- ---------------------------------------


--
-- Table structure for table `az_shops_template`
--

DROP TABLE IF EXISTS `az_shops_template`;
CREATE TABLE `az_shops_template` (
  `id` mediumint(8) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_transaction`
--

DROP TABLE IF EXISTS `az_shops_transaction`;
CREATE TABLE `az_shops_transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_time` int(11) NOT NULL DEFAULT '0',
  `transaction_status` int(11) NOT NULL,
  `order_id` int(11) NOT NULL DEFAULT '0',
  `userid` int(11) NOT NULL DEFAULT '0',
  `payment` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `payment_id` varchar(22)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `payment_time` int(11) NOT NULL DEFAULT '0',
  `payment_amount` float NOT NULL DEFAULT '0',
  `payment_data` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `order_id` (`order_id`),
  KEY `payment_id` (`payment_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_units`
--

DROP TABLE IF EXISTS `az_shops_units`;
CREATE TABLE `az_shops_units` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vi_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `vi_note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_units`
--

INSERT INTO `az_shops_units` VALUES
(1, 'Cái', '');


-- ---------------------------------------


--
-- Table structure for table `az_shops_warehouse`
--

DROP TABLE IF EXISTS `az_shops_warehouse`;
CREATE TABLE `az_shops_warehouse` (
  `wid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_warehouse_logs`
--

DROP TABLE IF EXISTS `az_shops_warehouse_logs`;
CREATE TABLE `az_shops_warehouse_logs` (
  `logid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `wid` int(11) unsigned NOT NULL DEFAULT '0',
  `pro_id` int(11) unsigned NOT NULL DEFAULT '0',
  `quantity` int(11) unsigned NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `money_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`logid`),
  KEY `wid` (`wid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_warehouse_logs_group`
--

DROP TABLE IF EXISTS `az_shops_warehouse_logs_group`;
CREATE TABLE `az_shops_warehouse_logs_group` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `logid` int(11) unsigned NOT NULL DEFAULT '0',
  `listgroup` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) unsigned NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `money_unit` char(3)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `logid` (`logid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_shops_weight_vi`
--

DROP TABLE IF EXISTS `az_shops_weight_vi`;
CREATE TABLE `az_shops_weight_vi` (
  `id` tinyint(2) unsigned NOT NULL AUTO_INCREMENT,
  `code` char(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange` float NOT NULL DEFAULT '0',
  `round` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_weight_vi`
--

INSERT INTO `az_shops_weight_vi` VALUES
(1, 'g', 'Gram', '1', '0.1'), 
(2, 'kg', 'Kilogam', '1000', '0.1');


-- ---------------------------------------


--
-- Table structure for table `az_shops_wishlist`
--

DROP TABLE IF EXISTS `az_shops_wishlist`;
CREATE TABLE `az_shops_wishlist` (
  `wid` smallint(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `listid` text  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`wid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_shops_wishlist`
--

INSERT INTO `az_shops_wishlist` VALUES
(1, 1, '1');


-- ---------------------------------------


--
-- Table structure for table `az_upload_dir`
--

DROP TABLE IF EXISTS `az_upload_dir`;
CREATE TABLE `az_upload_dir` (
  `did` mediumint(8) NOT NULL AUTO_INCREMENT,
  `dirname` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT '0',
  `thumb_type` tinyint(4) NOT NULL DEFAULT '0',
  `thumb_width` smallint(6) NOT NULL DEFAULT '0',
  `thumb_height` smallint(6) NOT NULL DEFAULT '0',
  `thumb_quality` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`did`),
  UNIQUE KEY `name` (`dirname`)
) ENGINE=MyISAM  AUTO_INCREMENT=52  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_upload_dir`
--

INSERT INTO `az_upload_dir` VALUES
(0, '', 0, 4, 250, 250, 90), 
(1, 'uploads', 1477777025, 0, 0, 0, 0), 
(2, 'uploads/about', 1477389365, 0, 0, 0, 0), 
(3, 'uploads/banners', 1477386870, 0, 0, 0, 0), 
(4, 'uploads/contact', 1477386889, 0, 0, 0, 0), 
(5, 'uploads/freecontent', 1477386890, 0, 0, 0, 0), 
(6, 'uploads/menu', 1477386892, 0, 0, 0, 0), 
(7, 'uploads/news', 1477386894, 0, 0, 0, 0), 
(8, 'uploads/news/2016_01', 1477386899, 0, 0, 0, 0), 
(9, 'uploads/news/source', 0, 0, 0, 0, 0), 
(10, 'uploads/news/temp_pic', 0, 0, 0, 0, 0), 
(11, 'uploads/news/topics', 0, 0, 0, 0, 0), 
(12, 'uploads/page', 1477389391, 0, 0, 0, 0), 
(13, 'uploads/siteterms', 0, 0, 0, 0, 0), 
(14, 'uploads/users', 0, 0, 0, 0, 0), 
(15, 'uploads/users/groups', 0, 0, 0, 0, 0), 
(16, 'uploads/slider', 0, 0, 0, 0, 0), 
(17, 'uploads/slider/images', 1475290398, 0, 0, 0, 0), 
(18, 'uploads/slider/thumbs', 0, 0, 0, 0, 0), 
(19, 'uploads/slider/temp', 0, 0, 0, 0, 0), 
(20, 'uploads/photos', 1477386901, 0, 0, 0, 0), 
(21, 'uploads/photos/images', 1477386905, 0, 0, 0, 0), 
(22, 'uploads/photos/thumbs', 0, 0, 0, 0, 0), 
(23, 'uploads/photos/temp', 0, 0, 0, 0, 0), 
(24, 'uploads/photos/images/2016', 1477386907, 0, 0, 0, 0), 
(25, 'uploads/photos/images/2016/10', 1477386911, 0, 0, 0, 0), 
(26, 'uploads/photos/thumbs/2016', 0, 0, 0, 0, 0), 
(27, 'uploads/photos/thumbs/2016/10', 0, 0, 0, 0, 0), 
(28, 'uploads/photos/images/2016/10/mai-nguyen-dinh-huy', 0, 0, 0, 0, 0), 
(29, 'uploads/photos/images/2016/10/hua-ha-phuong', 0, 0, 0, 0, 0), 
(30, 'uploads/photos/images/2016/10/dang-thu-trang', 1477389373, 0, 0, 0, 0), 
(31, 'uploads/photos/images/2016/10/taing-hong', 0, 0, 0, 0, 0), 
(32, 'uploads/weblinks', 1475395725, 0, 0, 0, 0), 
(33, 'uploads/weblinks/cat', 0, 0, 0, 0, 0), 
(34, 'uploads/shops/temp_pic', 0, 0, 0, 0, 0), 
(35, 'uploads/shops/2016_10', 1475427697, 0, 0, 0, 0), 
(36, 'uploads/shops/files', 1477773564, 0, 0, 0, 0), 
(37, 'uploads/photos/images/2016/10/fox-beer-club', 1477389375, 0, 0, 0, 0), 
(38, 'uploads/photos/images/2016/10/nguyen-trung-dung', 0, 0, 0, 0, 0), 
(39, 'uploads/photos/images/2016/10/nguyen-ngoc-tranh', 0, 0, 0, 0, 0), 
(40, 'uploads/photos/images/2016/10/huynh-van-ky', 1477389383, 0, 0, 0, 0), 
(41, 'uploads/photos/images/2016/10/nguyen-thanh-phong', 0, 0, 0, 0, 0), 
(42, 'uploads/photos/images/2016/10/tran-thanh-sang', 0, 0, 0, 0, 0), 
(43, 'uploads/photos/images/2016/10/dam-mai-lam', 0, 0, 0, 0, 0), 
(44, 'uploads/photos/images/2016/10/vu-si-loi', 0, 0, 0, 0, 0), 
(45, 'uploads/photos/images/2016/10/nguyen-huy-thang', 0, 0, 0, 0, 0), 
(46, 'uploads/photos/images/2016/10/horizon-school', 0, 0, 0, 0, 0), 
(47, 'uploads/news/2016_10', 1477449534, 0, 0, 0, 0), 
(48, 'uploads/photos/images/2016/10/london-college-design-school', 0, 0, 0, 0, 0), 
(49, 'uploads/photos/images/2016/10/caffe-hoang-long', 0, 0, 0, 0, 0), 
(50, 'uploads/shops', 1477777029, 0, 0, 0, 0), 
(51, 'uploads/shops/2015_05', 0, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `az_upload_file`
--

DROP TABLE IF EXISTS `az_upload_file`;
CREATE TABLE `az_upload_file` (
  `name` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `ext` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `type` varchar(5)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `filesize` int(11) NOT NULL DEFAULT '0',
  `src` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `srcwidth` int(11) NOT NULL DEFAULT '0',
  `srcheight` int(11) NOT NULL DEFAULT '0',
  `sizes` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mtime` int(11) NOT NULL DEFAULT '0',
  `did` int(11) NOT NULL DEFAULT '0',
  `title` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alt` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  UNIQUE KEY `did` (`did`,`title`),
  KEY `userid` (`userid`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_upload_file`
--

INSERT INTO `az_upload_file` VALUES
('logo.jpg', 'jpg', 'image', 32066, 'assets/logo.jpg', 80, 80, '200|128', 1, 1477598812, 1, 'logo.jpg', 'logo'), 
('4.jpg', 'jpg', 'image', 261309, 'assets/slider/images/4.jpg', 80, 46, '1500|844', 1, 1475290402, 17, '4.jpg', '4'), 
('3.jpg', 'jpg', 'image', 344015, 'assets/slider/images/3.jpg', 80, 46, '1500|844', 1, 1475290419, 17, '3.jpg', '3'), 
('2.jpg', 'jpg', 'image', 257874, 'assets/slider/images/2.jpg', 80, 46, '1500|844', 1, 1475290444, 17, '2.jpg', '2'), 
('1.jpg', 'jpg', 'image', 300763, 'assets/slider/images/1.jpg', 80, 46, '1500|844', 1, 1475290464, 17, '1.jpg', '1'), 
('5.jpg', 'jpg', 'image', 291233, 'assets/slider/images/5.jpg', 80, 46, '1500|844', 1, 1475290493, 17, '5.jpg', '5'), 
('6.jpg', 'jpg', 'image', 275082, 'assets/slider/images/6.jpg', 80, 46, '1500|844', 1, 1475290556, 17, '6.jpg', '6'), 
('1-55-720x540.jpg', 'jpg', 'image', 108543, 'assets/weblinks/1-55-720x540.jpg', 80, 60, '720|540', 1, 1475395735, 32, '1-55-720x540.jpg', '1 55 720x540'), 
('absynth-ma...jpg', 'jpg', 'image', 21683, 'assets/shops/2016_10/absynth-magh-sideboard.jpg', 62, 80, '600|770', 1, 1475427710, 35, 'absynth-magh-sideboard.jpg', 'Absynth magh sideboard'), 
('absynth-ma...jpg', 'jpg', 'image', 21683, 'assets/shops/2016_10/absynth-magh-sideboard_1.jpg', 80, 80, '600|770', 1, 1475427843, 35, 'absynth-magh-sideboard_1.jpg', 'Absynth magh sideboard'), 
('1-6.jpg', 'jpg', 'image', 73380, 'assets/shops/2016_10/1-6.jpg', 80, 80, '600|764', 1, 1475433705, 35, '1-6.jpg', '1 6'), 
('quangcaol.jpg', 'jpg', 'image', 110970, 'assets/quangcaol.jpg', 80, 80, '230|400', 1, 1477598813, 1, 'quangcaol.jpg', 'quangcaol'), 
('logo.png', 'png', 'image', 36649, 'assets/logo.png', 80, 80, '877|877', 1, 1477598812, 1, 'logo.png', 'logo'), 
('webnhanh.jpg', 'jpg', 'image', 74347, 'assets/banners/webnhanh.jpg', 80, 80, '572|72', 1, 1476547990, 3, 'webnhanh.jpg', 'webnhanh'), 
('vinades.jpg', 'jpg', 'image', 104940, 'assets/banners/vinades.jpg', 80, 80, '212|400', 1, 1476547990, 3, 'vinades.jpg', 'vinades'), 
('123host_nu...jpg', 'jpg', 'image', 77788, 'assets/banners/123host_nukeviet.jpg', 80, 80, '250|250', 1, 1476547990, 3, '123host_nukeviet.jpg', '123host nukeviet'), 
('edugate.jpg', 'jpg', 'image', 28008, 'assets/freecontent/edugate.jpg', 80, 80, '130|71', 1, 1476547990, 5, 'edugate.jpg', 'edugate'), 
('shop.jpg', 'jpg', 'image', 26352, 'assets/freecontent/shop.jpg', 80, 80, '130|71', 1, 1476547991, 5, 'shop.jpg', 'shop'), 
('toa-soan-d...jpg', 'jpg', 'image', 28737, 'assets/freecontent/toa-soan-dien-tu.jpg', 80, 80, '130|71', 1, 1476547991, 5, 'toa-soan-dien-tu.jpg', 'toa soan dien tu'), 
('cms.jpg', 'jpg', 'image', 29026, 'assets/freecontent/cms.jpg', 80, 80, '130|71', 1, 1476547992, 5, 'cms.jpg', 'cms'), 
('portal.jpg', 'jpg', 'image', 25973, 'assets/freecontent/portal.jpg', 80, 80, '130|71', 1, 1476547990, 5, 'portal.jpg', 'portal'), 
('hoptac.jpg', 'jpg', 'image', 12871, 'assets/news/hoptac.jpg', 80, 66, '382|314', 1, 1476547991, 7, 'hoptac.jpg', 'hoptac'), 
('chuc-mung-...jpg', 'jpg', 'image', 130708, 'assets/news/chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 80, 62, '461|360', 1, 1476547991, 7, 'chuc-mung-nukeviet-thong-tu-20-bo-tttt.jpg', 'chuc mung nukeviet thong tu 20 bo tttt'), 
('tuyendung-...jpg', 'jpg', 'image', 83783, 'assets/news/tuyendung-kythuat.jpg', 80, 80, '300|300', 1, 1476547992, 7, 'tuyendung-kythuat.jpg', 'tuyendung kythuat'), 
('tap-huan-p...jpg', 'jpg', 'image', 132379, 'assets/news/tap-huan-pgd-ha-dong-2015.jpg', 80, 52, '460|295', 1, 1476547992, 7, 'tap-huan-pgd-ha-dong-2015.jpg', 'tap huan pgd ha dong 2015'), 
('nangly.jpg', 'jpg', 'image', 34802, 'assets/news/nangly.jpg', 80, 53, '500|332', 1, 1476547992, 7, 'nangly.jpg', 'nangly'), 
('nukeviet-cms.jpg', 'jpg', 'image', 83489, 'assets/news/nukeviet-cms.jpg', 80, 55, '500|345', 1, 1476547992, 7, 'nukeviet-cms.jpg', 'nukeviet cms'), 
('thuc-tap-sinh.jpg', 'jpg', 'image', 71135, 'assets/news/thuc-tap-sinh.jpg', 80, 63, '460|360', 1, 1476547992, 7, 'thuc-tap-sinh.jpg', 'thuc tap sinh'), 
('nukeviet-n...jpg', 'jpg', 'image', 18611, 'assets/news/nukeviet-nhantaidatviet2011.jpg', 80, 54, '400|268', 1, 1476547992, 7, 'nukeviet-nhantaidatviet2011.jpg', 'nukeviet nhantaidatviet2011'), 
('tuyen-dung...png', 'png', 'image', 118910, 'assets/news/tuyen-dung-nvkd.png', 80, 56, '400|279', 1, 1476547992, 7, 'tuyen-dung-nvkd.png', 'tuyen dung nvkd'), 
('hoc-viec-t...jpg', 'jpg', 'image', 167193, 'assets/news/hoc-viec-tai-cong-ty-vinades.jpg', 80, 63, '460|360', 1, 1476547991, 7, 'hoc-viec-tai-cong-ty-vinades.jpg', 'hoc viec tai cong ty vinades'), 
('litespeed-...jpg', 'jpg', 'image', 36867, 'assets/news/2016_01/litespeed-benchmark.jpg', 80, 80, '540|292', 1, 1476547993, 8, 'litespeed-benchmark.jpg', 'litespeed benchmark'), 
('cpanel-ddo...jpg', 'jpg', 'image', 82476, 'assets/news/2016_01/cpanel-ddos-protection-malware-scanner.jpg', 80, 80, '540|300', 1, 1476547993, 8, 'cpanel-ddos-protection-malware-scanner.jpg', 'cpanel ddos protection malware scanner'), 
('cc-by-nc-sa.png', 'png', 'image', 417, 'assets/news/2016_01/cc-by-nc-sa.png', 80, 80, '80|15', 1, 1476547992, 8, 'cc-by-nc-sa.png', 'cc by nc sa'), 
('support247.jpg', 'jpg', 'image', 39576, 'assets/news/2016_01/support247.jpg', 80, 80, '540|151', 1, 1476547993, 8, 'support247.jpg', 'support247'), 
('how-to-cho...jpg', 'jpg', 'image', 55022, 'assets/news/2016_01/how-to-choose-hosting.jpg', 80, 50, '540|338', 1, 1476547993, 8, 'how-to-choose-hosting.jpg', 'how to choose hosting'), 
('hosting-12...jpg', 'jpg', 'image', 45292, 'assets/news/2016_01/hosting-123host-nukeviet.jpg', 80, 80, '540|298', 1, 1476547993, 8, 'hosting-123host-nukeviet.jpg', 'hosting 123host nukeviet'), 
('123host-ne...jpg', 'jpg', 'image', 65162, 'assets/news/2016_01/123host-network-security.jpg', 80, 80, '540|310', 1, 1476547992, 8, '123host-network-security.jpg', '123host network security'), 
('cloudlinux...jpg', 'jpg', 'image', 66150, 'assets/news/2016_01/cloudlinux-security.jpg', 80, 80, '540|312', 1, 1476547993, 8, 'cloudlinux-security.jpg', 'cloudlinux security'), 
('logo-nukev...png', 'png', 'image', 13223, 'assets/about/logo-nukeviet3-flag-180x75.png', 80, 80, '180|75', 1, 1476547990, 2, 'logo-nukeviet3-flag-180x75.png', 'logo nukeviet3 flag 180x75'), 
('w.png', 'png', 'image', 12156, 'assets/about/w.png', 80, 80, '288|143', 1, 1476547990, 2, 'w.png', 'w'), 
('nukevietvn...png', 'png', 'image', 11586, 'assets/about/nukevietvn_180x84.png', 80, 80, '180|84', 1, 1476547990, 2, 'nukevietvn_180x84.png', 'nukevietvn 180x84'), 
('nukevietcm...png', 'png', 'image', 13125, 'assets/about/nukevietcms_laco_180x57.png', 80, 80, '180|57', 1, 1476547990, 2, 'nukevietcms_laco_180x57.png', 'nukevietcms laco 180x57'), 
('nukevietcms.png', 'png', 'image', 85684, 'assets/about/nukevietcms.png', 80, 80, '1500|700', 1, 1476547990, 2, 'nukevietcms.png', 'nukevietcms'), 
('nukevietcm...png', 'png', 'image', 13319, 'assets/about/nukevietcms_mu_noel_180x84.png', 80, 80, '180|84', 1, 1476547990, 2, 'nukevietcms_mu_noel_180x84.png', 'nukevietcms mu noel 180x84'), 
('nukevietcm...png', 'png', 'image', 11974, 'assets/about/nukevietcms-180x84.png', 80, 80, '180|84', 1, 1476547990, 2, 'nukevietcms-180x84.png', 'nukevietcms 180x84'), 
('nukevietvn.png', 'png', 'image', 81035, 'assets/about/nukevietvn.png', 80, 80, '1500|700', 1, 1476547990, 2, 'nukevietvn.png', 'nukevietvn'), 
('wc-1110x694-1.jpg', 'jpg', 'image', 303220, 'assets/photos/images/2016/10/dang-thu-trang/wc-1110x694-1.jpg', 80, 80, '1110|694', 1, 1476548001, 30, 'wc-1110x694-1.jpg', 'wc 1110x694 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 264749, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-ngu-master-3-1110x606-1.jpg', 80, 80, '1110|606', 1, 1476548001, 30, 'dtt-phong-ngu-master-3-1110x606-1.jpg', 'dtt phong ngu master 3 1110x606 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 671759, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-ngu-master-4-1.jpg', 80, 80, '900|1200', 1, 1476548002, 30, 'dtt-phong-ngu-master-4-1.jpg', 'dtt phong ngu master 4 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 287201, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-ngu-phu-2-1110x694-1.jpg', 80, 80, '1110|694', 1, 1476548001, 30, 'dtt-phong-ngu-phu-2-1110x694-1.jpg', 'dtt phong ngu phu 2 1110x694 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 273782, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-khach-3-1110x601-1.jpg', 80, 80, '1110|601', 1, 1476548000, 30, 'dtt-phong-khach-3-1110x601-1.jpg', 'dtt phong khach 3 1110x601 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 281248, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-ngu-phu-1-1110x694-1.jpg', 80, 80, '1110|694', 1, 1476548001, 30, 'dtt-phong-ngu-phu-1-1110x694-1.jpg', 'dtt phong ngu phu 1 1110x694 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 281042, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-an-2-1110x601-1.jpg', 80, 80, '1110|601', 1, 1476548000, 30, 'dtt-phong-an-2-1110x601-1.jpg', 'dtt phong an 2 1110x601 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 293884, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-bep-2-1110x601-1.jpg', 80, 80, '1110|601', 1, 1476548000, 30, 'dtt-phong-bep-2-1110x601-1.jpg', 'dtt phong bep 2 1110x601 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 290552, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-khach-2-1110x601-1.jpg', 80, 80, '1110|601', 1, 1476548000, 30, 'dtt-phong-khach-2-1110x601-1.jpg', 'dtt phong khach 2 1110x601 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 218879, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-khach-1-1110x463-1.jpg', 80, 80, '1110|463', 1, 1476548000, 30, 'dtt-phong-khach-1-1110x463-1.jpg', 'dtt phong khach 1 1110x463 1'), 
('dtt-phong-...jpg', 'jpg', 'image', 265930, 'assets/photos/images/2016/10/dang-thu-trang/dtt-phong-ngu-master-1-1110x594-1.jpg', 80, 80, '1110|594', 1, 1476548001, 30, 'dtt-phong-ngu-master-1-1110x594-1.jpg', 'dtt phong ngu master 1 1110x594 1'), 
('8-37.jpg', 'jpg', 'image', 792796, 'assets/photos/images/2016/10/fox-beer-club/8-37.jpg', 80, 80, '1500|611', 1, 1476548009, 37, '8-37.jpg', '8 37'), 
('4-55.jpg', 'jpg', 'image', 963930, 'assets/photos/images/2016/10/fox-beer-club/4-55.jpg', 80, 80, '1500|999', 1, 1476548007, 37, '4-55.jpg', '4 55'), 
('3-55.jpg', 'jpg', 'image', 710132, 'assets/photos/images/2016/10/fox-beer-club/3-55.jpg', 80, 80, '1500|591', 1, 1476548006, 37, '3-55.jpg', '3 55'), 
('5-52.jpg', 'jpg', 'image', 992508, 'assets/photos/images/2016/10/fox-beer-club/5-52.jpg', 80, 80, '1500|999', 1, 1476548006, 37, '5-52.jpg', '5 52'), 
('9-33.jpg', 'jpg', 'image', 1068428, 'assets/photos/images/2016/10/fox-beer-club/9-33.jpg', 80, 80, '1500|999', 1, 1476548009, 37, '9-33.jpg', '9 33'), 
('11-26.jpg', 'jpg', 'image', 1621379, 'assets/photos/images/2016/10/fox-beer-club/11-26.jpg', 80, 80, '1500|1454', 1, 1476548005, 37, '11-26.jpg', '11 26'), 
('6-50.jpg', 'jpg', 'image', 1054320, 'assets/photos/images/2016/10/fox-beer-club/6-50.jpg', 80, 80, '1500|999', 1, 1476548008, 37, '6-50.jpg', '6 50'), 
('1-55.jpg', 'jpg', 'image', 893340, 'assets/photos/images/2016/10/fox-beer-club/1-55.jpg', 80, 80, '1500|837', 1, 1476548002, 37, '1-55.jpg', '1 55'), 
('2-55.jpg', 'jpg', 'image', 1118190, 'assets/photos/images/2016/10/fox-beer-club/2-55.jpg', 80, 80, '1500|999', 1, 1476548004, 37, '2-55.jpg', '2 55'), 
('10-30.jpg', 'jpg', 'image', 976721, 'assets/photos/images/2016/10/fox-beer-club/10-30.jpg', 80, 80, '1500|686', 1, 1476548003, 37, '10-30.jpg', '10 30'), 
('8-30.jpg', 'jpg', 'image', 282111, 'assets/photos/images/2016/10/huynh-van-ky/8-30.jpg', 80, 80, '1100|614', 1, 1477049636, 40, '8-30.jpg', '8 30'), 
('3-47.jpg', 'jpg', 'image', 224944, 'assets/photos/images/2016/10/huynh-van-ky/3-47.jpg', 80, 80, '1000|540', 1, 1477049636, 40, '3-47.jpg', '3 47'), 
('12-18.jpg', 'jpg', 'image', 148844, 'assets/photos/images/2016/10/huynh-van-ky/12-18.jpg', 80, 80, '1133|517', 1, 1477049636, 40, '12-18.jpg', '12 18'), 
('5-44.jpg', 'jpg', 'image', 296850, 'assets/photos/images/2016/10/huynh-van-ky/5-44.jpg', 80, 80, '1100|614', 1, 1477049636, 40, '5-44.jpg', '5 44'), 
('11-19.jpg', 'jpg', 'image', 387734, 'assets/photos/images/2016/10/huynh-van-ky/11-19.jpg', 80, 80, '1100|825', 1, 1477049636, 40, '11-19.jpg', '11 19'), 
('9-26.jpg', 'jpg', 'image', 230196, 'assets/photos/images/2016/10/huynh-van-ky/9-26.jpg', 80, 80, '1100|614', 1, 1477049636, 40, '9-26.jpg', '9 26'), 
('6-42.jpg', 'jpg', 'image', 303727, 'assets/photos/images/2016/10/huynh-van-ky/6-42.jpg', 80, 80, '1100|614', 1, 1477049636, 40, '6-42.jpg', '6 42'), 
('10-23.jpg', 'jpg', 'image', 400158, 'assets/photos/images/2016/10/huynh-van-ky/10-23.jpg', 80, 80, '943|1100', 1, 1477049636, 40, '10-23.jpg', '10 23'), 
('2-47.jpg', 'jpg', 'image', 288007, 'assets/photos/images/2016/10/huynh-van-ky/2-47.jpg', 80, 80, '1000|628', 1, 1477049636, 40, '2-47.jpg', '2 47'), 
('1-47.jpg', 'jpg', 'image', 314814, 'assets/photos/images/2016/10/huynh-van-ky/1-47.jpg', 80, 80, '1000|558', 1, 1477049636, 40, '1-47.jpg', '1 47'), 
('7-35.jpg', 'jpg', 'image', 407913, 'assets/photos/images/2016/10/huynh-van-ky/7-35.jpg', 80, 80, '1100|660', 1, 1477049636, 40, '7-35.jpg', '7 35'), 
('4-47.jpg', 'jpg', 'image', 376009, 'assets/photos/images/2016/10/huynh-van-ky/4-47.jpg', 80, 80, '1100|660', 1, 1477049636, 40, '4-47.jpg', '4 47'), 
('5_56.jpg', 'jpg', 'image', 664776, 'assets/slider/images/5_56.jpg', 80, 80, '1500|844', 1, 1477389900, 17, '5_56.jpg', '5 56'), 
('ficha2_ima...jpg', 'jpg', 'image', 596703, 'assets/slider/images/ficha2_imagen1_highres_post_mail.jpg', 80, 80, '1500|844', 1, 1477390196, 17, 'ficha2_imagen1_highres_post_mail.jpg', 'Ficha2 Imagen1 HighRes POST MAIL'), 
('baltic_par...jpg', 'jpg', 'image', 648535, 'assets/slider/images/baltic_park_molo_interior.jpg', 80, 80, '1343|756', 1, 1477390384, 17, 'baltic_park_molo_interior.jpg', 'Baltic Park Molo Interior'), 
('art_work.jpg', 'jpg', 'image', 616377, 'assets/slider/images/art_work.jpg', 80, 80, '1500|844', 1, 1477390470, 17, 'art_work.jpg', 'Art work'), 
('bathroom_1...jpg', 'jpg', 'image', 464173, 'assets/slider/images/bathroom_1_sharpversion.jpg', 80, 80, '1500|844', 1, 1477390569, 17, 'bathroom_1_sharpversion.jpg', 'Bathroom 1 SharpVersion'), 
('kuchyn.jpg', 'jpg', 'image', 712969, 'assets/slider/images/kuchyn.jpg', 80, 80, '1500|844', 1, 1477392947, 17, 'kuchyn.jpg', 'kuchyn'), 
('bedroom_12_1.jpg', 'jpg', 'image', 660683, 'assets/slider/images/bedroom_12_1.jpg', 80, 80, '1500|844', 1, 1477390746, 17, 'bedroom_12_1.jpg', 'Bedroom 12'), 
('04_hill_ho...jpg', 'jpg', 'image', 655113, 'assets/slider/images/04_hill_house_kitchen_detail_2000.jpg', 80, 80, '1500|844', 1, 1477393089, 17, '04_hill_house_kitchen_detail_2000.jpg', '04 Hill House Kitchen Detail 2000'), 
('apartment_...jpg', 'jpg', 'image', 725689, 'assets/slider/images/apartment_revised_shot_5.jpg', 80, 80, '1500|844', 1, 1477393417, 17, 'apartment_revised_shot_5.jpg', 'Apartment revised shot 5'), 
('icon2.jpg', 'jpg', 'image', 84612, 'assets/icon2.jpg', 80, 80, '877|567', 1, 1477598813, 1, 'icon2.jpg', 'icon2'), 
('icon3.jpg', 'jpg', 'image', 91955, 'assets/icon3.jpg', 80, 80, '877|567', 1, 1477598812, 1, 'icon3.jpg', 'icon3'), 
('dau-anh.png', 'png', 'image', 11642, 'assets/dau-anh.png', 80, 80, '319|204', 1, 1477598813, 1, 'dau-anh.png', 'Dau anh'), 
('bi-quyet-t...jpg', 'jpg', 'image', 94388, 'assets/news/2016_10/bi-quyet-thiet-ke-noi-that-chung-cu-dep.jpg', 80, 80, '600|575', 1, 1477449547, 47, 'bi-quyet-thiet-ke-noi-that-chung-cu-dep.jpg', 'AZVIET CMS'), 
('bi-quyet-t...jpg', 'jpg', 'image', 66067, 'assets/news/2016_10/bi-quyet-thiet-ke-noi-that-chung-cu-dep-3.jpg', 80, 80, '600|400', 1, 1477449563, 47, 'bi-quyet-thiet-ke-noi-that-chung-cu-dep-3.jpg', 'AZVIET CMS'), 
('khong_gian...jpg', 'jpg', 'image', 60025, 'assets/news/2016_10/khong_gian_phong_ngu_lang_man_va_phong_cach_voi_gam_mau_nau85.jpg', 80, 80, '927|593', 1, 1477449656, 47, 'khong_gian_phong_ngu_lang_man_va_phong_cach_voi_gam_mau_nau85.jpg', 'AZVIET CMS'), 
('phong-ngu-...jpg', 'jpg', 'image', 201281, 'assets/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau.jpg', 80, 80, '1043|780', 1, 1477449688, 47, 'phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau.jpg', 'AZVIET CMS'), 
('phong-ngu-...jpg', 'jpg', 'image', 116630, 'assets/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau2.jpg', 80, 80, '750|1128', 1, 1477449705, 47, 'phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau2.jpg', 'AZVIET CMS'), 
('phong-ngu-...jpg', 'jpg', 'image', 133711, 'assets/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau3.jpg', 80, 80, '970|1200', 1, 1477449724, 47, 'phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau3.jpg', 'AZVIET CMS'), 
('phong-ngu-...jpg', 'jpg', 'image', 60025, 'assets/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau5.jpg', 80, 80, '927|593', 1, 1477449745, 47, 'phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau5.jpg', 'AZVIET CMS'), 
('phong-ngu-...jpg', 'jpg', 'image', 66431, 'assets/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau6.jpg', 80, 80, '919|607', 1, 1477449771, 47, 'phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau6.jpg', 'AZVIET CMS'), 
('phong-ngu-...jpg', 'jpg', 'image', 58296, 'assets/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau7.jpg', 80, 80, '924|597', 1, 1477449788, 47, 'phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau7.jpg', 'AZVIET CMS'), 
('phong-ngu-...jpg', 'jpg', 'image', 60354, 'assets/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau9.jpg', 80, 80, '914|594', 1, 1477449813, 47, 'phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau9.jpg', 'phong ngu phong cach va toi gian voi gam mau nau9'), 
('up-012.jpg', 'jpg', 'image', 244756, 'assets/news/2016_10/up-012.jpg', 80, 80, '700|474', 1, 1477450052, 47, 'up-012.jpg', 'up 012'), 
('up-02.jpg', 'jpg', 'image', 1250203, 'assets/news/2016_10/up-02.jpg', 80, 80, '700|529', 1, 1477450071, 47, 'up-02.jpg', 'up 02'), 
('up-03.jpg', 'jpg', 'image', 48171, 'assets/news/2016_10/up-03.jpg', 80, 80, '700|420', 1, 1477450092, 47, 'up-03.jpg', 'up 03'), 
('up-04.jpg', 'jpg', 'image', 57730, 'assets/news/2016_10/up-04.jpg', 80, 80, '700|522', 1, 1477450124, 47, 'up-04.jpg', 'up 04'), 
('kennedy_26...jpg', 'jpg', 'image', 1627807, 'assets/news/2016_10/kennedy_26311r153.jpg', 80, 80, '900|671', 1, 1477450184, 47, 'kennedy_26311r153.jpg', 'KENNEDY 26311R153'), 
('image0021.jpg', 'jpg', 'image', 216451, 'assets/news/2016_10/image0021.jpg', 80, 80, '600|400', 1, 1477450213, 47, 'image0021.jpg', 'image0021'), 
('01.jpg', 'jpg', 'image', 204823, 'assets/slider/images/01.jpg', 80, 80, '900|600', 1, 1477606308, 17, '01.jpg', '01'), 
('02.jpg', 'jpg', 'image', 769316, 'assets/slider/images/02.jpg', 80, 80, '1500|1029', 1, 1477606412, 17, '02.jpg', '02'), 
('03.jpg', 'jpg', 'image', 723884, 'assets/slider/images/03.jpg', 80, 80, '1500|844', 1, 1477606584, 17, '03.jpg', '03'), 
('001.jpg', 'jpg', 'image', 37638, 'assets/slider/images/001.jpg', 80, 80, '432|288', 1, 1477671816, 17, '001.jpg', '001'), 
('002.jpg', 'jpg', 'image', 147324, 'assets/slider/images/002.jpg', 80, 80, '580|387', 1, 1477671817, 17, '002.jpg', '002'), 
('003.jpg', 'jpg', 'image', 5139, 'assets/slider/images/003.jpg', 80, 80, '275|183', 1, 1477671817, 17, '003.jpg', '003'), 
('004.jpg', 'jpg', 'image', 76211, 'assets/slider/images/004.jpg', 80, 80, '623|831', 1, 1477671817, 17, '004.jpg', '004'), 
('005.jpg', 'jpg', 'image', 83085, 'assets/slider/images/005.jpg', 80, 80, '600|900', 1, 1477671817, 17, '005.jpg', '005'), 
('006.jpg', 'jpg', 'image', 88620, 'assets/slider/images/006.jpg', 80, 80, '500|671', 1, 1477671818, 17, '006.jpg', '006'), 
('thong-tin-...doc', 'doc', 'file', 75776, 'assets/images/msword.png', 32, 32, '|', 1, 1477773597, 36, 'thong-tin-van-tat-de-tham-khao.doc', 'Thong tin van tat de tham khao'), 
('111.jpg', 'jpg', 'image', 53421, 'assets/shops/2016_10/111.jpg', 80, 80, '386|572', 1, 1477774968, 35, '111.jpg', '111'), 
('12.jpg', 'jpg', 'image', 28306, 'assets/shops/2016_10/12.jpg', 80, 80, '386|572', 1, 1477776851, 35, '12.jpg', '12'), 
('12_1.jpg', 'jpg', 'image', 28306, 'assets/shops/2016_10/12_1.jpg', 80, 80, '386|572', 1, 1477776851, 35, '12_1.jpg', '12'), 
('11.jpg', 'jpg', 'image', 14121, 'assets/11.jpg', 80, 80, '184|273', 1, 1477776954, 1, '11.jpg', '11'), 
('11.jpg', 'jpg', 'image', 14121, 'assets/shops/2016_10/11.jpg', 80, 80, '184|273', 1, 1477776982, 35, '11.jpg', '11'), 
('logo-2_37f...png', 'png', 'image', 5489, 'assets/logo-2_37f5857749616f304e954cf1f37101b3.png', 80, 80, '144|88', 1, 1477598813, 1, 'logo-2_37f5857749616f304e954cf1f37101b3.png', 'logo 2 37f5857749616f304e954cf1f37101b3'), 
('13.jpg', 'jpg', 'image', 141416, 'assets/shops/2016_10/13.jpg', 80, 80, '386|572', 1, 1477777037, 35, '13.jpg', '13'), 
('nguhanh.jpg', 'jpg', 'image', 51879, 'assets/page/nguhanh.jpg', 80, 80, '368|368', 1, 1477845689, 12, 'nguhanh.jpg', 'nguhanh'), 
('1453868678.png', 'png', 'image', 969, 'assets/slider/images/1453868678.png', 80, 80, '100|100', 1, 1477885528, 17, '1453868678.png', '1453868678'), 
('1453868688.png', 'png', 'image', 886, 'assets/slider/images/1453868688.png', 80, 80, '100|100', 1, 1477885529, 17, '1453868688.png', '1453868688'), 
('1453868707.png', 'png', 'image', 611, 'assets/slider/images/1453868707.png', 80, 80, '100|100', 1, 1477885529, 17, '1453868707.png', '1453868707'), 
('1456475557.png', 'png', 'image', 846, 'assets/slider/images/1456475557.png', 80, 80, '100|100', 1, 1477885530, 17, '1456475557.png', '1456475557'), 
('01_1.jpg', 'jpg', 'image', 149922, 'assets/slider/images/01_1.jpg', 80, 80, '1228|819', 1, 1477889412, 17, '01_1.jpg', '01'), 
('02_1.jpg', 'jpg', 'image', 641726, 'assets/slider/images/02_1.jpg', 80, 80, '1500|844', 1, 1477889413, 17, '02_1.jpg', '02'), 
('03_1.jpg', 'jpg', 'image', 373813, 'assets/slider/images/03_1.jpg', 80, 80, '1500|844', 1, 1477889413, 17, '03_1.jpg', '03'), 
('04.jpg', 'jpg', 'image', 792331, 'assets/slider/images/04.jpg', 80, 80, '1500|844', 1, 1477889414, 17, '04.jpg', '04'), 
('05.jpg', 'jpg', 'image', 630879, 'assets/slider/images/05.jpg', 80, 80, '1500|844', 1, 1477889415, 17, '05.jpg', '05'), 
('06.jpg', 'jpg', 'image', 596235, 'assets/slider/images/06.jpg', 80, 80, '1500|844', 1, 1477889416, 17, '06.jpg', '06');


-- ---------------------------------------


--
-- Table structure for table `az_users`
--

DROP TABLE IF EXISTS `az_users`;
CREATE TABLE `az_users` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(80)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `gender` char(1)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `photo` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `birthday` int(11) NOT NULL,
  `sig` text  COLLATE utf8mb4_unicode_ci,
  `regdate` int(11) NOT NULL DEFAULT '0',
  `question` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `passlostkey` varchar(50)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `view_mail` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `remember` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `in_groups` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checknum` varchar(40)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_login` int(11) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(45)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_agent` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_openid` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `idsite` int(11) NOT NULL DEFAULT '0',
  `safemode` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `safekey` varchar(40)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`),
  KEY `idsite` (`idsite`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_users`
--

INSERT INTO `az_users` VALUES
(1, 1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '{SSHA}n4LQU0WwNdqTSjAe13aSq1Yg4o92VEs3', 'info@azvietco.vn', 'admin', '', '', '', 0, '', 1475277543, 'món ăn', 'gà chỉ', '', 1, 1, '1', 1, '', 1475277543, '', '', '', 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `az_users_config`
--

DROP TABLE IF EXISTS `az_users_config`;
CREATE TABLE `az_users_config` (
  `config` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci,
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`config`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_users_config`
--

INSERT INTO `az_users_config` VALUES
('access_admin', 'a:6:{s:12:\"access_addus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:14:\"access_waiting\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_editus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:12:\"access_delus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_passus\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}s:13:\"access_groups\";a:3:{i:1;b:1;i:2;b:1;i:3;b:1;}}', 1352873462), 
('password_simple', '000000|1234|2000|12345|111111|123123|123456|11223344|654321|696969|1234567|12345678|87654321|123456789|23456789|1234567890|66666666|68686868|66668888|88888888|99999999|999999999|1234569|12345679|aaaaaa|abc123|abc123@|abc@123|admin123|admin123@|admin@123|nuke123|nuke123@|nuke@123|adobe1|adobe123|azerty|baseball|dragon|football|harley|iloveyou|jennifer|jordan|letmein|macromedia|master|michael|monkey|mustang|password|photoshop|pussy|qwerty|shadow|superman|hoilamgi|khongbiet|khongco|khongcopass', 1475277519), 
('deny_email', 'yoursite.com|mysite.com|localhost|xxx', 1475277519), 
('deny_name', 'anonimo|anonymous|god|linux|nobody|operator|root', 1475277519), 
('avatar_width', '80', 1475277519), 
('avatar_height', '80', 1475277519), 
('active_group_newusers', '0', 1475277519), 
('siteterms_vi', '<p> Để trở thành thành viên, bạn phải cam kết đồng ý với các điều khoản dưới đây. Chúng tôi có thể thay đổi lại những điều khoản này vào bất cứ lúc nào và chúng tôi sẽ cố gắng thông báo đến bạn kịp thời.<br /> <br /> Bạn cam kết không gửi bất cứ bài viết có nội dung lừa đảo, thô tục, thiếu văn hoá; vu khống, khiêu khích, đe doạ người khác; liên quan đến các vấn đề tình dục hay bất cứ nội dung nào vi phạm luật pháp của quốc gia mà bạn đang sống, luật pháp của quốc gia nơi đặt máy chủ của website này hay luật pháp quốc tế. Nếu vẫn cố tình vi phạm, ngay lập tức bạn sẽ bị cấm tham gia vào website. Địa chỉ IP của tất cả các bài viết đều được ghi nhận lại để bảo vệ các điều khoản cam kết này trong trường hợp bạn không tuân thủ.<br /> <br /> Bạn đồng ý rằng website có quyền gỡ bỏ, sửa, di chuyển hoặc khoá bất kỳ bài viết nào trong website vào bất cứ lúc nào tuỳ theo nhu cầu công việc.<br /> <br /> Đăng ký làm thành viên của chúng tôi, bạn cũng phải đồng ý rằng, bất kỳ thông tin cá nhân nào mà bạn cung cấp đều được lưu trữ trong cơ sở dữ liệu của hệ thống. Mặc dù những thông tin này sẽ không được cung cấp cho bất kỳ người thứ ba nào khác mà không được sự đồng ý của bạn, chúng tôi không chịu trách nhiệm về việc những thông tin cá nhân này của bạn bị lộ ra bên ngoài từ những kẻ phá hoại có ý đồ xấu tấn công vào cơ sở dữ liệu của hệ thống.</p>', 1274757129);


-- ---------------------------------------


--
-- Table structure for table `az_users_field`
--

DROP TABLE IF EXISTS `az_users_field`;
CREATE TABLE `az_users_field` (
  `fid` mediumint(8) NOT NULL AUTO_INCREMENT,
  `field` varchar(25)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` int(10) unsigned NOT NULL DEFAULT '1',
  `field_type` enum('number','date','textbox','textarea','editor','select','radio','checkbox','multiselect')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'textbox',
  `field_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sql_choices` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `match_type` enum('none','alphanumeric','email','url','regex','callback')  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'none',
  `match_regex` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_callback` varchar(75)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `min_length` int(11) NOT NULL DEFAULT '0',
  `max_length` bigint(20) unsigned NOT NULL DEFAULT '0',
  `required` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_register` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `user_editable` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `show_profile` tinyint(4) NOT NULL DEFAULT '1',
  `class` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `language` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`fid`),
  UNIQUE KEY `field` (`field`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_users_groups`
--

DROP TABLE IF EXISTS `az_users_groups`;
CREATE TABLE `az_users_groups` (
  `group_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `content` text  COLLATE utf8mb4_unicode_ci,
  `group_type` tinyint(4) unsigned NOT NULL DEFAULT '0' COMMENT '0:Sys, 1:approval, 2:public',
  `group_color` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_avatar` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `exp_time` int(11) NOT NULL,
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL,
  `idsite` int(11) unsigned NOT NULL DEFAULT '0',
  `numbers` mediumint(9) unsigned NOT NULL DEFAULT '0',
  `siteus` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `config` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`group_id`),
  UNIQUE KEY `ktitle` (`title`,`idsite`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_users_groups`
--

INSERT INTO `az_users_groups` VALUES
(1, 'Super admin', '', 'Super Admin', '', 0, '', '', 0, 1475277519, 0, 1, 1, 0, 1, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(2, 'General admin', '', 'General Admin', '', 0, '', '', 0, 1475277519, 0, 2, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(3, 'Module admin', '', 'Module Admin', '', 0, '', '', 0, 1475277519, 0, 3, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(4, 'Users', '', 'Users', '', 0, '', '', 0, 1475277519, 0, 4, 1, 0, 1, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(7, 'New Users', '', 'New Users', '', 0, '', '', 0, 1475277519, 0, 5, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(5, 'Guest', '', 'Guest', '', 0, '', '', 0, 1475277519, 0, 6, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}'), 
(6, 'All', '', 'All', '', 0, '', '', 0, 1475277519, 0, 7, 1, 0, 0, 0, 'a:7:{s:17:\"access_groups_add\";i:1;s:17:\"access_groups_del\";i:1;s:12:\"access_addus\";i:0;s:14:\"access_waiting\";i:0;s:13:\"access_editus\";i:0;s:12:\"access_delus\";i:0;s:13:\"access_passus\";i:0;}');


-- ---------------------------------------


--
-- Table structure for table `az_users_groups_users`
--

DROP TABLE IF EXISTS `az_users_groups_users`;
CREATE TABLE `az_users_groups_users` (
  `group_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `is_leader` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `approved` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `data` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`group_id`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_users_groups_users`
--

INSERT INTO `az_users_groups_users` VALUES
(1, 1, 1, 1, '0');


-- ---------------------------------------


--
-- Table structure for table `az_users_info`
--

DROP TABLE IF EXISTS `az_users_info`;
CREATE TABLE `az_users_info` (
  `userid` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_users_info`
--

INSERT INTO `az_users_info` VALUES
(1);


-- ---------------------------------------


--
-- Table structure for table `az_users_openid`
--

DROP TABLE IF EXISTS `az_users_openid`;
CREATE TABLE `az_users_openid` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `openid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `opid` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`opid`),
  KEY `userid` (`userid`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_users_question`
--

DROP TABLE IF EXISTS `az_users_question`;
CREATE TABLE `az_users_question` (
  `qid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(240)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `lang` char(2)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`qid`),
  UNIQUE KEY `title` (`title`,`lang`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_users_question`
--

INSERT INTO `az_users_question` VALUES
(1, 'Bạn thích môn thể thao nào nhất', 'vi', 1, 1274840238, 1274840238), 
(2, 'Món ăn mà bạn yêu thích', 'vi', 2, 1274840250, 1274840250), 
(3, 'Thần tượng điện ảnh của bạn', 'vi', 3, 1274840257, 1274840257), 
(4, 'Bạn thích nhạc sỹ nào nhất', 'vi', 4, 1274840264, 1274840264), 
(5, 'Quê ngoại của bạn ở đâu', 'vi', 5, 1274840270, 1274840270), 
(6, 'Tên cuốn sách &quot;gối đầu giường&quot;', 'vi', 6, 1274840278, 1274840278), 
(7, 'Ngày lễ mà bạn luôn mong đợi', 'vi', 7, 1274840285, 1274840285);


-- ---------------------------------------


--
-- Table structure for table `az_users_reg`
--

DROP TABLE IF EXISTS `az_users_reg`;
CREATE TABLE `az_users_reg` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `md5username` char(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(80)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `first_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `last_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `regdate` int(11) unsigned NOT NULL DEFAULT '0',
  `question` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `checknum` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `users_info` text  COLLATE utf8mb4_unicode_ci,
  `openid_info` text  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`userid`),
  UNIQUE KEY `login` (`username`),
  UNIQUE KEY `md5username` (`md5username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_vi_about`
--

DROP TABLE IF EXISTS `az_vi_about`;
CREATE TABLE `az_vi_about` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=10  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_about`
--

INSERT INTO `az_vi_about` VALUES
(9, 'Về One-interior', 'Ve-One-interior', '', '', 0, '', 'Nôi dung đang cập nhật!', '', 1, '6', '', 0, 1, 1, 1476610187, 1477844978, 1);


-- ---------------------------------------


--
-- Table structure for table `az_vi_about_config`
--

DROP TABLE IF EXISTS `az_vi_about_config`;
CREATE TABLE `az_vi_about_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_about_config`
--

INSERT INTO `az_vi_about_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `az_vi_blocks_groups`
--

DROP TABLE IF EXISTS `az_vi_blocks_groups`;
CREATE TABLE `az_vi_blocks_groups` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `theme` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(55)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `exp_time` int(11) DEFAULT '0',
  `active` varchar(10)  COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `all_func` tinyint(4) NOT NULL DEFAULT '0',
  `weight` int(11) NOT NULL DEFAULT '0',
  `config` text  COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`bid`),
  KEY `theme` (`theme`),
  KEY `module` (`module`),
  KEY `position` (`position`),
  KEY `exp_time` (`exp_time`)
) ENGINE=MyISAM  AUTO_INCREMENT=55  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_blocks_groups`
--

INSERT INTO `az_vi_blocks_groups` VALUES
(3, 'default', 'news', 'global.block_category.php', 'Chủ đề', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 1, 'a:2:{s:5:\"catid\";i:0;s:12:\"title_length\";i:25;}'), 
(4, 'default', 'theme', 'global.module_menu.php', 'Module Menu', '', 'no_title', '[LEFT]', 0, '1', 1, '6', 0, 2, ''), 
(7, 'default', 'about', 'global.about.php', 'Giới thiệu', '', 'border', '[RIGHT]', 0, '1', 1, '6', 1, 1, ''), 
(8, 'default', 'banners', 'global.banners.php', 'Quảng cáo cột phải', '', 'no_title', '[RIGHT]', 0, '1', 1, '6', 1, 2, 'a:1:{s:12:\"idplanbanner\";i:3;}'), 
(9, 'default', 'voting', 'global.voting_random.php', 'Thăm dò ý kiến', '', 'primary', '[RIGHT]', 0, '1', 1, '6', 1, 3, ''), 
(10, 'default', 'news', 'global.block_tophits.php', 'Tin xem nhiều', '', 'primary', '[RIGHT]', 0, '1', 1, '6', 1, 4, 'a:6:{s:10:\"number_day\";i:3650;s:6:\"numrow\";i:10;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";s:7:\"nocatid\";a:2:{i:0;i:10;i:1;i:11;}}'), 
(22, 'mobile_default', 'menu', 'global.metismenu.php', 'Menu Site', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(23, 'mobile_default', 'users', 'global.user_button.php', 'Sign In', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 2, ''), 
(24, 'mobile_default', 'contact', 'global.contact_default.php', 'Contact Default', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 1, ''), 
(25, 'mobile_default', 'contact', 'global.contact_form.php', 'Feedback', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 2, ''), 
(26, 'mobile_default', 'theme', 'global.social.php', 'Social icon', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 3, 'a:4:{s:8:\"facebook\";s:32:\"http://www.facebook.com/nukeviet\";s:11:\"google_plus\";s:32:\"https://www.google.com/+nukeviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/nukeviet\";s:7:\"twitter\";s:28:\"https://twitter.com/nukeviet\";}'), 
(27, 'mobile_default', 'theme', 'global.QR_code.php', 'QR code', '', 'no_title', '[SOCIAL_ICONS]', 0, '1', 1, '6', 1, 4, 'a:3:{s:5:\"level\";s:1:\"L\";s:15:\"pixel_per_point\";i:4;s:11:\"outer_frame\";i:1;}'), 
(28, 'mobile_default', 'theme', 'global.copyright.php', 'Copyright', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, 'a:5:{s:12:\"copyright_by\";s:0:\"\";s:13:\"copyright_url\";s:0:\"\";s:9:\"design_by\";s:12:\"VINADES.,JSC\";s:10:\"design_url\";s:18:\"http://vinades.vn/\";s:13:\"siteterms_url\";s:39:\"/index.php?language=vi&amp;nv=siteterms\";}'), 
(29, 'mobile_default', 'theme', 'global.menu_footer.php', 'Các chuyên mục chính', '', 'primary', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:1:{s:14:\"module_in_menu\";a:9:{i:0;s:5:\"about\";i:1;s:4:\"news\";i:2;s:5:\"users\";i:3;s:7:\"contact\";i:4;s:6:\"voting\";i:5;s:7:\"banners\";i:6;s:4:\"seek\";i:7;s:5:\"feeds\";i:8;s:9:\"siteterms\";}}'), 
(30, 'mobile_default', 'theme', 'global.company_info.php', 'Công ty chủ quản', '', 'primary', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:\"company_name\";s:58:\"Công ty cổ phần phát triển nguồn mở Việt Nam\";s:15:\"company_address\";s:72:\"Phòng 2004 - Tòa nhà CT2 Nàng Hương, 583 Nguyễn Trãi, Hà Nội\";s:16:\"company_sortname\";s:12:\"VINADES.,JSC\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.984516000000013;s:20:\"company_mapcenterlng\";d:105.795475;s:14:\"company_maplat\";d:20.984515999999999;s:14:\"company_maplng\";d:105.79547500000001;s:15:\"company_mapzoom\";i:17;s:13:\"company_phone\";s:56:\"+84-4-85872007[+84485872007]|+84-904762534[+84904762534]\";s:11:\"company_fax\";s:14:\"+84-4-35500914\";s:13:\"company_email\";s:18:\"contact@vinades.vn\";s:15:\"company_website\";s:17:\"http://vinades.vn\";}'), 
(31, 'default', 'slider', 'global.slider.php', 'global slider', '', 'no_title', '[SLIDE]', 0, '1', 1, '6', 0, 1, 'a:7:{s:8:\"group_id\";i:1;s:6:\"numrow\";i:6;s:8:\"widthimg\";i:0;s:9:\"heightimg\";i:0;s:11:\"buttonstype\";s:4:\"none\";s:8:\"readmore\";s:8:\"readmore\";s:8:\"template\";s:11:\"nivo_slider\";}'), 
(32, 'default', 'theme', 'global.social.php', 'Đồng hành cùng chúng tôi', '', 'simple', '[MENU_FOOTER]', 0, '1', 1, '6', 1, 1, 'a:4:{s:8:\"facebook\";s:44:\"https://www.facebook.com/sieuthiwebquangtri/\";s:11:\"google_plus\";s:30:\"https://www.google.com/+azviet\";s:7:\"youtube\";s:37:\"https://www.youtube.com/user/azvietco\";s:7:\"twitter\";s:26:\"https://twitter.com/azviet\";}'), 
(33, 'default', 'theme', 'global.company_info.php', 'Liên hệ', '', 'simple', '[COMPANY_INFO]', 0, '1', 1, '6', 1, 1, 'a:17:{s:12:\"company_name\";s:0:\"\";s:16:\"company_sortname\";s:0:\"\";s:15:\"company_regcode\";s:0:\"\";s:16:\"company_regplace\";s:0:\"\";s:21:\"company_licensenumber\";s:0:\"\";s:22:\"company_responsibility\";s:0:\"\";s:15:\"company_address\";s:98:\"Công ty Công nghệ số Đạt Nguyễn, Phường 5, tp. Đông Hà, Quảng Trị, Việt Nam\";s:15:\"company_showmap\";i:1;s:20:\"company_mapcenterlat\";d:20.984617111784999;s:20:\"company_mapcenterlng\";d:105.79553367331999;s:14:\"company_maplat\";d:20.984515999999999;s:14:\"company_maplng\";d:105.79547500000001;s:15:\"company_mapzoom\";i:20;s:13:\"company_phone\";s:33:\"0914416567&#91;+840914416567&#93;\";s:11:\"company_fax\";s:0:\"\";s:13:\"company_email\";s:22:\"thangvinades@gmail.com\";s:15:\"company_website\";s:0:\"\";}'), 
(38, 'default', 'menu', 'global.slimmenu.php', 'global slimmenu', '', 'no_title', '[MENU_SITE]', 0, '1', 1, '6', 1, 1, 'a:2:{s:6:\"menuid\";i:1;s:12:\"title_length\";i:0;}'), 
(39, 'default', 'weblinks', 'global.block_weblink_bycat.php', 'global slider', '', 'no_title', '[BLOCK_GIA]', 0, '1', 1, '6', 0, 1, 'a:2:{s:5:\"catid\";a:1:{i:0;s:1:\"1\";}s:6:\"numrow\";i:5;}'), 
(41, 'default', 'photos', 'global.block_album_new.php', 'global block album new', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 1, 'a:3:{s:6:\"numrow\";i:8;s:12:\"title_length\";i:0;s:10:\"des_length\";i:0;}'), 
(42, 'default', 'shops', 'global.block_catalogs.php', 'Danh mục sản phẩm', '', 'simple', '[LEFT]', 0, '1', 1, '6', 0, 3, 'a:1:{s:7:\"cut_num\";i:0;}'), 
(43, 'default', 'shops', 'global.block_relates_product.php', 'global block bxproduct center', '', 'no_title', '[BLOCK_SHOP]', 0, '1', 1, '6', 0, 1, 'a:3:{s:7:\"blockid\";i:1;s:6:\"numrow\";i:4;s:7:\"cut_num\";i:24;}'), 
(46, 'default', 'slider', 'global.slider.php', 'global slider', '', 'no_title', '[BLOCK_DOITAC]', 0, '1', 1, '6', 0, 1, 'a:7:{s:8:\"group_id\";i:5;s:6:\"numrow\";i:10;s:8:\"widthimg\";i:0;s:9:\"heightimg\";i:0;s:11:\"buttonstype\";s:4:\"none\";s:8:\"readmore\";s:8:\"readmore\";s:8:\"template\";s:9:\"khachhang\";}'), 
(47, 'default', 'slider', 'global.slider.php', 'global slider', '', 'no_title', '[BLOCK_VIDEOS]', 0, '1', 1, '6', 0, 1, 'a:7:{s:8:\"group_id\";i:4;s:6:\"numrow\";i:5;s:8:\"widthimg\";i:600;s:9:\"heightimg\";i:200;s:11:\"buttonstype\";s:4:\"none\";s:8:\"readmore\";s:8:\"readmore\";s:8:\"template\";s:8:\"pinwheel\";}'), 
(48, 'default', 'slider', 'global.slider.php', 'global slider', '', 'no_title', '[BLOCK_KHACHHANG]', 0, '1', 1, '6', 0, 1, 'a:7:{s:8:\"group_id\";i:5;s:6:\"numrow\";i:5;s:8:\"widthimg\";i:0;s:9:\"heightimg\";i:0;s:11:\"buttonstype\";s:4:\"none\";s:8:\"readmore\";s:8:\"readmore\";s:8:\"template\";s:9:\"khachhang\";}'), 
(50, 'default', 'slider', 'global.slider.php', 'global slider', '', 'no_title', '[BLOCK_TRANGDIEM]', 0, '1', 1, '6', 0, 1, 'a:7:{s:8:\"group_id\";i:6;s:6:\"numrow\";i:10;s:8:\"widthimg\";i:0;s:9:\"heightimg\";i:0;s:11:\"buttonstype\";s:4:\"none\";s:8:\"readmore\";s:8:\"readmore\";s:8:\"template\";s:9:\"Trangdiem\";}'), 
(51, 'default', 'news', 'global.block_groups.php', 'Tin mới nhất', '/one/groups/Tin-moi-nhat/', 'no_title', '[BLOCK_COLLEC]', 0, '1', 1, '6', 0, 1, 'a:5:{s:7:\"blockid\";i:2;s:6:\"numrow\";i:4;s:11:\"showtooltip\";i:1;s:16:\"tooltip_position\";s:6:\"bottom\";s:14:\"tooltip_length\";s:3:\"150\";}'), 
(52, 'default', 'about', 'global.page_list.php', 'global about', '', 'no_title', '[LEFT-ABOUT]', 0, '1', 1, '6', 0, 1, 'a:2:{s:12:\"title_length\";i:24;s:6:\"numrow\";i:5;}'), 
(53, 'default', 'statistics', 'global.counter.php', 'global counter', '', 'no_title', '[FOOTER_SITE]', 0, '1', 1, '6', 1, 1, ''), 
(54, 'default', 'slider', 'global.slider.php', 'global slider', '', 'no_title', '[TOP]', 0, '1', 1, '6', 0, 2, 'a:7:{s:8:\"group_id\";i:7;s:6:\"numrow\";i:10;s:8:\"widthimg\";i:0;s:9:\"heightimg\";i:0;s:11:\"buttonstype\";s:4:\"none\";s:8:\"readmore\";s:8:\"readmore\";s:8:\"template\";s:8:\"bxslider\";}');


-- ---------------------------------------


--
-- Table structure for table `az_vi_blocks_weight`
--

DROP TABLE IF EXISTS `az_vi_blocks_weight`;
CREATE TABLE `az_vi_blocks_weight` (
  `bid` mediumint(8) NOT NULL DEFAULT '0',
  `func_id` mediumint(8) NOT NULL DEFAULT '0',
  `weight` mediumint(8) NOT NULL DEFAULT '0',
  UNIQUE KEY `bid` (`bid`,`func_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_blocks_weight`
--

INSERT INTO `az_vi_blocks_weight` VALUES
(3, 4, 1), 
(3, 5, 1), 
(3, 6, 1), 
(3, 7, 1), 
(3, 8, 1), 
(3, 9, 1), 
(3, 10, 1), 
(3, 11, 1), 
(3, 12, 1), 
(4, 18, 1), 
(4, 19, 1), 
(4, 20, 1), 
(4, 21, 1), 
(4, 22, 1), 
(4, 23, 1), 
(4, 24, 1), 
(4, 25, 1), 
(4, 26, 1), 
(4, 27, 1), 
(4, 30, 1), 
(4, 31, 1), 
(4, 32, 1), 
(4, 33, 1), 
(4, 34, 1), 
(4, 35, 1), 
(4, 36, 1), 
(7, 1, 1), 
(7, 37, 1), 
(7, 38, 1), 
(7, 39, 1), 
(7, 40, 1), 
(7, 46, 1), 
(7, 47, 1), 
(7, 48, 1), 
(7, 49, 1), 
(7, 56, 1), 
(7, 59, 1), 
(7, 4, 1), 
(7, 5, 1), 
(7, 6, 1), 
(7, 7, 1), 
(7, 8, 1), 
(7, 9, 1), 
(7, 10, 1), 
(7, 11, 1), 
(7, 12, 1), 
(7, 50, 1), 
(7, 58, 1), 
(7, 53, 1), 
(7, 54, 1), 
(7, 30, 1), 
(7, 31, 1), 
(7, 32, 1), 
(7, 33, 1), 
(7, 34, 1), 
(7, 35, 1), 
(7, 36, 1), 
(7, 18, 1), 
(7, 19, 1), 
(7, 20, 1), 
(7, 21, 1), 
(7, 22, 1), 
(7, 23, 1), 
(7, 24, 1), 
(7, 25, 1), 
(7, 26, 1), 
(7, 27, 1), 
(7, 28, 1), 
(7, 57, 1), 
(8, 1, 2), 
(8, 37, 2), 
(8, 38, 2), 
(8, 39, 2), 
(8, 40, 2), 
(8, 46, 2), 
(8, 47, 2), 
(8, 48, 2), 
(8, 49, 2), 
(8, 56, 2), 
(8, 59, 2), 
(8, 4, 2), 
(8, 5, 2), 
(8, 6, 2), 
(8, 7, 2), 
(8, 8, 2), 
(8, 9, 2), 
(8, 10, 2), 
(8, 11, 2), 
(8, 12, 2), 
(8, 50, 2), 
(8, 58, 2), 
(8, 53, 2), 
(8, 54, 2), 
(8, 30, 2), 
(8, 31, 2), 
(8, 32, 2), 
(8, 33, 2), 
(8, 34, 2), 
(8, 35, 2), 
(8, 36, 2), 
(8, 18, 2), 
(8, 19, 2), 
(8, 20, 2), 
(8, 21, 2), 
(8, 22, 2), 
(8, 23, 2), 
(8, 24, 2), 
(8, 25, 2), 
(8, 26, 2), 
(8, 27, 2), 
(8, 28, 2), 
(8, 57, 2), 
(9, 1, 3), 
(9, 37, 3), 
(9, 38, 3), 
(9, 39, 3), 
(9, 40, 3), 
(9, 46, 3), 
(9, 47, 3), 
(9, 48, 3), 
(9, 49, 3), 
(9, 56, 3), 
(9, 59, 3), 
(9, 4, 3), 
(9, 5, 3), 
(9, 6, 3), 
(9, 7, 3), 
(9, 8, 3), 
(9, 9, 3), 
(9, 10, 3), 
(9, 11, 3), 
(9, 12, 3), 
(9, 50, 3), 
(9, 58, 3), 
(9, 53, 3), 
(9, 54, 3), 
(9, 30, 3), 
(9, 31, 3), 
(9, 32, 3), 
(9, 33, 3), 
(9, 34, 3), 
(9, 35, 3), 
(9, 36, 3), 
(9, 18, 3), 
(9, 19, 3), 
(9, 20, 3), 
(9, 21, 3), 
(9, 22, 3), 
(9, 23, 3), 
(9, 24, 3), 
(9, 25, 3), 
(9, 26, 3), 
(9, 27, 3), 
(9, 28, 3), 
(9, 57, 3), 
(10, 1, 4), 
(10, 37, 4), 
(10, 38, 4), 
(10, 39, 4), 
(10, 40, 4), 
(10, 46, 4), 
(10, 47, 4), 
(10, 48, 4), 
(10, 49, 4), 
(10, 56, 4), 
(10, 59, 4), 
(10, 4, 4), 
(10, 5, 4), 
(10, 6, 4), 
(10, 7, 4), 
(10, 8, 4), 
(10, 9, 4), 
(10, 10, 4), 
(10, 11, 4), 
(10, 12, 4), 
(10, 50, 4), 
(10, 58, 4), 
(10, 53, 4), 
(10, 54, 4), 
(10, 30, 4), 
(10, 31, 4), 
(10, 32, 4), 
(10, 33, 4), 
(10, 34, 4), 
(10, 35, 4), 
(10, 36, 4), 
(10, 18, 4), 
(10, 19, 4), 
(10, 20, 4), 
(10, 21, 4), 
(10, 22, 4), 
(10, 23, 4), 
(10, 24, 4), 
(10, 25, 4), 
(10, 26, 4), 
(10, 27, 4), 
(10, 28, 4), 
(10, 57, 4), 
(30, 1, 1), 
(30, 37, 1), 
(30, 38, 1), 
(30, 39, 1), 
(30, 40, 1), 
(30, 46, 1), 
(30, 47, 1), 
(30, 48, 1), 
(30, 49, 1), 
(30, 56, 1), 
(30, 59, 1), 
(30, 4, 1), 
(30, 5, 1), 
(30, 6, 1), 
(30, 7, 1), 
(30, 8, 1), 
(30, 9, 1), 
(30, 10, 1), 
(30, 11, 1), 
(30, 12, 1), 
(30, 50, 1), 
(30, 58, 1), 
(30, 53, 1), 
(30, 54, 1), 
(30, 30, 1), 
(30, 31, 1), 
(30, 32, 1), 
(30, 33, 1), 
(30, 34, 1), 
(30, 35, 1), 
(30, 36, 1), 
(30, 18, 1), 
(30, 19, 1), 
(30, 20, 1), 
(30, 21, 1), 
(30, 22, 1), 
(30, 23, 1), 
(30, 24, 1), 
(30, 25, 1), 
(30, 26, 1), 
(30, 27, 1), 
(30, 28, 1), 
(30, 57, 1), 
(28, 1, 1), 
(28, 37, 1), 
(28, 38, 1), 
(28, 39, 1), 
(28, 40, 1), 
(28, 46, 1), 
(28, 47, 1), 
(28, 48, 1), 
(28, 49, 1), 
(28, 56, 1), 
(28, 59, 1), 
(28, 4, 1), 
(28, 5, 1), 
(28, 6, 1), 
(28, 7, 1), 
(28, 8, 1), 
(28, 9, 1), 
(28, 10, 1), 
(28, 11, 1), 
(28, 12, 1), 
(28, 50, 1), 
(28, 58, 1), 
(28, 53, 1), 
(28, 54, 1), 
(28, 30, 1), 
(28, 31, 1), 
(28, 32, 1), 
(28, 33, 1), 
(28, 34, 1), 
(28, 35, 1), 
(28, 36, 1), 
(28, 18, 1), 
(28, 19, 1), 
(28, 20, 1), 
(28, 21, 1), 
(28, 22, 1), 
(28, 23, 1), 
(28, 24, 1), 
(28, 25, 1), 
(28, 26, 1), 
(28, 27, 1), 
(28, 28, 1), 
(28, 57, 1), 
(29, 1, 1), 
(29, 37, 1), 
(29, 38, 1), 
(29, 39, 1), 
(29, 40, 1), 
(29, 46, 1), 
(29, 47, 1), 
(29, 48, 1), 
(29, 49, 1), 
(29, 56, 1), 
(29, 59, 1), 
(29, 4, 1), 
(29, 5, 1), 
(29, 6, 1), 
(29, 7, 1), 
(29, 8, 1), 
(29, 9, 1), 
(29, 10, 1), 
(29, 11, 1), 
(29, 12, 1), 
(29, 50, 1), 
(29, 58, 1), 
(29, 53, 1), 
(29, 54, 1), 
(29, 30, 1), 
(29, 31, 1), 
(29, 32, 1), 
(29, 33, 1), 
(29, 34, 1), 
(29, 35, 1), 
(29, 36, 1), 
(29, 18, 1), 
(29, 19, 1), 
(29, 20, 1), 
(29, 21, 1), 
(29, 22, 1), 
(29, 23, 1), 
(29, 24, 1), 
(29, 25, 1), 
(29, 26, 1), 
(29, 27, 1), 
(29, 28, 1), 
(29, 57, 1), 
(22, 1, 1), 
(22, 37, 1), 
(22, 38, 1), 
(22, 39, 1), 
(22, 40, 1), 
(22, 46, 1), 
(22, 47, 1), 
(22, 48, 1), 
(22, 49, 1), 
(22, 56, 1), 
(22, 59, 1), 
(22, 4, 1), 
(22, 5, 1), 
(22, 6, 1), 
(22, 7, 1), 
(22, 8, 1), 
(22, 9, 1), 
(22, 10, 1), 
(22, 11, 1), 
(22, 12, 1), 
(22, 50, 1), 
(22, 58, 1), 
(22, 53, 1), 
(22, 54, 1), 
(22, 30, 1), 
(22, 31, 1), 
(22, 32, 1), 
(22, 33, 1), 
(22, 34, 1), 
(22, 35, 1), 
(22, 36, 1), 
(22, 18, 1), 
(22, 19, 1), 
(22, 20, 1), 
(22, 21, 1), 
(22, 22, 1), 
(22, 23, 1), 
(22, 24, 1), 
(22, 25, 1), 
(22, 26, 1), 
(22, 27, 1), 
(22, 28, 1), 
(22, 57, 1), 
(23, 1, 2), 
(23, 37, 2), 
(23, 38, 2), 
(23, 39, 2), 
(23, 40, 2), 
(23, 46, 2), 
(23, 47, 2), 
(23, 48, 2), 
(23, 49, 2), 
(23, 56, 2), 
(23, 59, 2), 
(23, 4, 2), 
(23, 5, 2), 
(23, 6, 2), 
(23, 7, 2), 
(23, 8, 2), 
(23, 9, 2), 
(23, 10, 2), 
(23, 11, 2), 
(23, 12, 2), 
(23, 50, 2), 
(23, 58, 2), 
(23, 53, 2), 
(23, 54, 2), 
(23, 30, 2), 
(23, 31, 2), 
(23, 32, 2), 
(23, 33, 2), 
(23, 34, 2), 
(23, 35, 2), 
(23, 36, 2), 
(23, 18, 2), 
(23, 19, 2), 
(23, 20, 2), 
(23, 21, 2), 
(23, 22, 2), 
(23, 23, 2), 
(23, 24, 2), 
(23, 25, 2), 
(23, 26, 2), 
(23, 27, 2), 
(23, 28, 2), 
(23, 57, 2), 
(24, 1, 1), 
(24, 37, 1), 
(24, 38, 1), 
(24, 39, 1), 
(24, 40, 1), 
(24, 46, 1), 
(24, 47, 1), 
(24, 48, 1), 
(24, 49, 1), 
(24, 56, 1), 
(24, 59, 1), 
(24, 4, 1), 
(24, 5, 1), 
(24, 6, 1), 
(24, 7, 1), 
(24, 8, 1), 
(24, 9, 1), 
(24, 10, 1), 
(24, 11, 1), 
(24, 12, 1), 
(24, 50, 1), 
(24, 58, 1), 
(24, 53, 1), 
(24, 54, 1), 
(24, 30, 1), 
(24, 31, 1), 
(24, 32, 1), 
(24, 33, 1), 
(24, 34, 1), 
(24, 35, 1), 
(24, 36, 1), 
(24, 18, 1), 
(24, 19, 1), 
(24, 20, 1), 
(24, 21, 1), 
(24, 22, 1), 
(24, 23, 1), 
(24, 24, 1), 
(24, 25, 1), 
(24, 26, 1), 
(24, 27, 1), 
(24, 28, 1), 
(24, 57, 1), 
(25, 1, 2), 
(25, 37, 2), 
(25, 38, 2), 
(25, 39, 2), 
(25, 40, 2), 
(25, 46, 2), 
(25, 47, 2), 
(25, 48, 2), 
(25, 49, 2), 
(25, 56, 2), 
(25, 59, 2), 
(25, 4, 2), 
(25, 5, 2), 
(25, 6, 2), 
(25, 7, 2), 
(25, 8, 2), 
(25, 9, 2), 
(25, 10, 2), 
(25, 11, 2), 
(25, 12, 2), 
(25, 50, 2), 
(25, 58, 2), 
(25, 53, 2), 
(25, 54, 2), 
(25, 30, 2), 
(25, 31, 2), 
(25, 32, 2), 
(25, 33, 2), 
(25, 34, 2), 
(25, 35, 2), 
(25, 36, 2), 
(25, 18, 2), 
(25, 19, 2), 
(25, 20, 2), 
(25, 21, 2), 
(25, 22, 2), 
(25, 23, 2), 
(25, 24, 2), 
(25, 25, 2), 
(25, 26, 2), 
(25, 27, 2), 
(25, 28, 2), 
(25, 57, 2), 
(26, 1, 3), 
(26, 37, 3), 
(26, 38, 3), 
(26, 39, 3), 
(26, 40, 3), 
(26, 46, 3), 
(26, 47, 3), 
(26, 48, 3), 
(26, 49, 3), 
(26, 56, 3), 
(26, 59, 3), 
(26, 4, 3), 
(26, 5, 3), 
(26, 6, 3), 
(26, 7, 3), 
(26, 8, 3), 
(26, 9, 3), 
(26, 10, 3), 
(26, 11, 3), 
(26, 12, 3), 
(26, 50, 3), 
(26, 58, 3), 
(26, 53, 3), 
(26, 54, 3), 
(26, 30, 3), 
(26, 31, 3), 
(26, 32, 3), 
(26, 33, 3), 
(26, 34, 3), 
(26, 35, 3), 
(26, 36, 3), 
(26, 18, 3), 
(26, 19, 3), 
(26, 20, 3), 
(26, 21, 3), 
(26, 22, 3), 
(26, 23, 3), 
(26, 24, 3), 
(26, 25, 3), 
(26, 26, 3), 
(26, 27, 3), 
(26, 28, 3), 
(26, 57, 3), 
(27, 1, 4), 
(27, 37, 4), 
(27, 38, 4), 
(27, 39, 4), 
(27, 40, 4), 
(27, 46, 4), 
(27, 47, 4), 
(27, 48, 4), 
(27, 49, 4), 
(27, 56, 4), 
(27, 59, 4), 
(27, 4, 4), 
(27, 5, 4), 
(27, 6, 4), 
(27, 7, 4), 
(27, 8, 4), 
(27, 9, 4), 
(27, 10, 4), 
(27, 11, 4), 
(27, 12, 4), 
(27, 50, 4), 
(27, 58, 4), 
(27, 53, 4), 
(27, 54, 4), 
(27, 30, 4), 
(27, 31, 4), 
(27, 32, 4), 
(27, 33, 4), 
(27, 34, 4), 
(27, 35, 4), 
(27, 36, 4), 
(27, 18, 4), 
(27, 19, 4), 
(27, 20, 4), 
(27, 21, 4), 
(27, 22, 4), 
(27, 23, 4), 
(27, 24, 4), 
(27, 25, 4), 
(27, 26, 4), 
(27, 27, 4), 
(27, 28, 4), 
(27, 57, 4), 
(7, 60, 1), 
(8, 60, 2), 
(9, 60, 3), 
(10, 60, 4), 
(30, 60, 1), 
(28, 60, 1), 
(29, 60, 1), 
(22, 60, 1), 
(23, 60, 2), 
(24, 60, 1), 
(25, 60, 2), 
(26, 60, 3), 
(27, 60, 4), 
(31, 4, 1), 
(7, 64, 1), 
(7, 73, 1), 
(7, 62, 1), 
(7, 61, 1), 
(7, 63, 1), 
(7, 69, 1), 
(8, 64, 2), 
(8, 73, 2), 
(8, 62, 2), 
(8, 61, 2), 
(8, 63, 2), 
(8, 69, 2), 
(9, 64, 3), 
(9, 73, 3), 
(9, 62, 3), 
(9, 61, 3), 
(9, 63, 3), 
(9, 69, 3), 
(10, 64, 4), 
(10, 73, 4), 
(10, 62, 4), 
(10, 61, 4), 
(10, 63, 4), 
(10, 69, 4), 
(30, 64, 1), 
(30, 73, 1), 
(30, 62, 1), 
(30, 61, 1), 
(30, 63, 1), 
(30, 69, 1), 
(28, 64, 1), 
(28, 73, 1), 
(28, 62, 1), 
(28, 61, 1), 
(28, 63, 1), 
(28, 69, 1), 
(29, 64, 1), 
(29, 73, 1), 
(29, 62, 1), 
(29, 61, 1), 
(29, 63, 1), 
(29, 69, 1), 
(22, 64, 1), 
(22, 73, 1), 
(22, 62, 1), 
(22, 61, 1), 
(22, 63, 1), 
(22, 69, 1), 
(23, 64, 2), 
(23, 73, 2), 
(23, 62, 2), 
(23, 61, 2), 
(23, 63, 2), 
(23, 69, 2), 
(24, 64, 1), 
(24, 73, 1), 
(24, 62, 1), 
(24, 61, 1), 
(24, 63, 1), 
(24, 69, 1), 
(25, 64, 2), 
(25, 73, 2), 
(25, 62, 2), 
(25, 61, 2), 
(25, 63, 2), 
(25, 69, 2), 
(26, 64, 3), 
(26, 73, 3), 
(26, 62, 3), 
(26, 61, 3), 
(26, 63, 3), 
(26, 69, 3), 
(27, 64, 4), 
(27, 73, 4), 
(27, 62, 4), 
(27, 61, 4), 
(27, 63, 4), 
(27, 69, 4), 
(32, 1, 1), 
(32, 4, 1), 
(32, 5, 1), 
(32, 6, 1), 
(32, 7, 1), 
(32, 8, 1), 
(32, 9, 1), 
(32, 10, 1), 
(32, 11, 1), 
(32, 12, 1), 
(32, 64, 1), 
(32, 73, 1), 
(32, 62, 1), 
(32, 61, 1), 
(32, 63, 1), 
(32, 69, 1), 
(32, 60, 1), 
(32, 18, 1), 
(32, 19, 1), 
(32, 20, 1), 
(32, 21, 1), 
(32, 22, 1), 
(32, 23, 1), 
(32, 24, 1), 
(32, 25, 1), 
(32, 26, 1), 
(32, 27, 1), 
(32, 28, 1), 
(32, 56, 1), 
(32, 30, 1), 
(32, 31, 1), 
(32, 32, 1), 
(32, 33, 1), 
(32, 34, 1), 
(32, 35, 1), 
(32, 36, 1), 
(32, 57, 1), 
(32, 37, 1), 
(32, 38, 1), 
(32, 39, 1), 
(32, 40, 1), 
(32, 58, 1), 
(32, 59, 1), 
(32, 50, 1), 
(32, 46, 1), 
(32, 47, 1), 
(32, 48, 1), 
(32, 49, 1), 
(32, 53, 1), 
(32, 54, 1), 
(33, 1, 1), 
(33, 4, 1), 
(33, 5, 1), 
(33, 6, 1), 
(33, 7, 1), 
(33, 8, 1), 
(33, 9, 1), 
(33, 10, 1), 
(33, 11, 1), 
(33, 12, 1), 
(33, 64, 1), 
(33, 73, 1), 
(33, 62, 1), 
(33, 61, 1), 
(33, 63, 1), 
(33, 69, 1), 
(33, 60, 1), 
(33, 18, 1), 
(33, 19, 1), 
(33, 20, 1), 
(33, 21, 1), 
(33, 22, 1), 
(33, 23, 1), 
(33, 24, 1), 
(33, 25, 1), 
(33, 26, 1), 
(33, 27, 1), 
(33, 28, 1), 
(33, 56, 1), 
(33, 30, 1), 
(33, 31, 1), 
(33, 32, 1), 
(33, 33, 1), 
(33, 34, 1), 
(33, 35, 1), 
(33, 36, 1), 
(33, 57, 1), 
(33, 37, 1), 
(33, 38, 1), 
(33, 39, 1), 
(33, 40, 1), 
(33, 58, 1), 
(33, 59, 1), 
(33, 50, 1), 
(33, 46, 1), 
(33, 47, 1), 
(33, 48, 1), 
(33, 49, 1), 
(33, 53, 1), 
(33, 54, 1), 
(38, 1, 1), 
(38, 4, 1), 
(38, 5, 1), 
(38, 6, 1), 
(38, 7, 1), 
(38, 8, 1), 
(38, 9, 1), 
(38, 10, 1), 
(38, 11, 1), 
(38, 12, 1), 
(38, 64, 1), 
(38, 73, 1), 
(38, 62, 1), 
(38, 61, 1), 
(38, 63, 1), 
(38, 69, 1), 
(38, 60, 1), 
(38, 18, 1), 
(38, 19, 1), 
(38, 20, 1), 
(38, 21, 1), 
(38, 22, 1), 
(38, 23, 1), 
(38, 24, 1), 
(38, 25, 1), 
(38, 26, 1), 
(38, 27, 1), 
(38, 28, 1), 
(38, 56, 1), 
(38, 30, 1), 
(38, 31, 1), 
(38, 32, 1), 
(38, 33, 1), 
(38, 34, 1), 
(38, 35, 1), 
(38, 36, 1), 
(38, 57, 1), 
(38, 37, 1), 
(38, 38, 1), 
(38, 39, 1), 
(38, 40, 1), 
(38, 58, 1), 
(38, 59, 1), 
(38, 50, 1), 
(38, 46, 1), 
(38, 47, 1), 
(38, 48, 1), 
(38, 49, 1), 
(38, 53, 1), 
(38, 54, 1), 
(39, 4, 1), 
(33, 75, 1), 
(33, 79, 1), 
(33, 74, 1), 
(32, 75, 1), 
(32, 79, 1), 
(32, 74, 1), 
(38, 75, 1), 
(38, 79, 1), 
(38, 74, 1), 
(7, 75, 1), 
(7, 79, 1), 
(7, 74, 1), 
(8, 75, 2), 
(8, 79, 2), 
(8, 74, 2), 
(9, 75, 3), 
(9, 79, 3), 
(9, 74, 3), 
(10, 75, 4), 
(10, 79, 4), 
(10, 74, 4), 
(30, 75, 1), 
(30, 79, 1), 
(30, 74, 1), 
(28, 75, 1), 
(28, 79, 1), 
(28, 74, 1), 
(29, 75, 1), 
(29, 79, 1), 
(29, 74, 1), 
(22, 75, 1), 
(22, 79, 1), 
(22, 74, 1), 
(23, 75, 2), 
(23, 79, 2), 
(23, 74, 2), 
(24, 75, 1), 
(24, 79, 1), 
(24, 74, 1), 
(25, 75, 2), 
(25, 79, 2), 
(25, 74, 2), 
(26, 75, 3), 
(26, 79, 3), 
(26, 74, 3), 
(27, 75, 4), 
(27, 79, 4), 
(27, 74, 4), 
(41, 4, 1), 
(33, 92, 1), 
(33, 108, 1), 
(33, 87, 1), 
(33, 101, 1), 
(33, 82, 1), 
(33, 93, 1), 
(33, 94, 1), 
(33, 85, 1), 
(33, 90, 1), 
(33, 89, 1), 
(33, 102, 1), 
(33, 84, 1), 
(33, 109, 1), 
(33, 107, 1), 
(33, 95, 1), 
(33, 105, 1), 
(33, 88, 1), 
(33, 81, 1), 
(32, 92, 1), 
(32, 108, 1), 
(32, 87, 1), 
(32, 101, 1), 
(32, 82, 1), 
(32, 93, 1), 
(32, 94, 1), 
(32, 85, 1), 
(32, 90, 1), 
(32, 89, 1), 
(32, 102, 1), 
(32, 84, 1), 
(32, 109, 1), 
(32, 107, 1), 
(32, 95, 1), 
(32, 105, 1), 
(32, 88, 1), 
(32, 81, 1), 
(38, 92, 1), 
(38, 108, 1), 
(38, 87, 1), 
(38, 101, 1), 
(38, 82, 1), 
(38, 93, 1), 
(38, 94, 1), 
(38, 85, 1), 
(38, 90, 1), 
(38, 89, 1), 
(38, 102, 1), 
(38, 84, 1), 
(38, 109, 1), 
(38, 107, 1), 
(38, 95, 1), 
(38, 105, 1), 
(38, 88, 1), 
(38, 81, 1), 
(7, 92, 1), 
(7, 108, 1), 
(7, 87, 1), 
(7, 101, 1), 
(7, 82, 1), 
(7, 93, 1), 
(7, 94, 1), 
(7, 85, 1), 
(7, 90, 1), 
(7, 89, 1), 
(7, 102, 1), 
(7, 84, 1), 
(7, 109, 1), 
(7, 107, 1), 
(7, 95, 1), 
(7, 105, 1), 
(7, 88, 1), 
(7, 81, 1), 
(8, 92, 2), 
(8, 108, 2), 
(8, 87, 2), 
(8, 101, 2), 
(8, 82, 2), 
(8, 93, 2), 
(8, 94, 2), 
(8, 85, 2), 
(8, 90, 2), 
(8, 89, 2), 
(8, 102, 2), 
(8, 84, 2), 
(8, 109, 2), 
(8, 107, 2), 
(8, 95, 2), 
(8, 105, 2), 
(8, 88, 2), 
(8, 81, 2), 
(9, 92, 3), 
(9, 108, 3), 
(9, 87, 3), 
(9, 101, 3), 
(9, 82, 3), 
(9, 93, 3), 
(9, 94, 3), 
(9, 85, 3), 
(9, 90, 3), 
(9, 89, 3), 
(9, 102, 3), 
(9, 84, 3), 
(9, 109, 3), 
(9, 107, 3), 
(9, 95, 3), 
(9, 105, 3), 
(9, 88, 3), 
(9, 81, 3), 
(10, 92, 4), 
(10, 108, 4), 
(10, 87, 4), 
(10, 101, 4), 
(10, 82, 4), 
(10, 93, 4), 
(10, 94, 4), 
(10, 85, 4), 
(10, 90, 4), 
(10, 89, 4), 
(10, 102, 4), 
(10, 84, 4), 
(10, 109, 4), 
(10, 107, 4), 
(10, 95, 4), 
(10, 105, 4), 
(10, 88, 4), 
(10, 81, 4), 
(30, 92, 1), 
(30, 108, 1), 
(30, 87, 1), 
(30, 101, 1), 
(30, 82, 1), 
(30, 93, 1), 
(30, 94, 1), 
(30, 85, 1), 
(30, 90, 1), 
(30, 89, 1), 
(30, 102, 1), 
(30, 84, 1), 
(30, 109, 1), 
(30, 107, 1), 
(30, 95, 1), 
(30, 105, 1), 
(30, 88, 1), 
(30, 81, 1), 
(28, 92, 1), 
(28, 108, 1), 
(28, 87, 1), 
(28, 101, 1), 
(28, 82, 1), 
(28, 93, 1), 
(28, 94, 1), 
(28, 85, 1), 
(28, 90, 1), 
(28, 89, 1), 
(28, 102, 1), 
(28, 84, 1), 
(28, 109, 1), 
(28, 107, 1), 
(28, 95, 1), 
(28, 105, 1), 
(28, 88, 1), 
(28, 81, 1), 
(29, 92, 1), 
(29, 108, 1), 
(29, 87, 1), 
(29, 101, 1), 
(29, 82, 1), 
(29, 93, 1), 
(29, 94, 1), 
(29, 85, 1), 
(29, 90, 1), 
(29, 89, 1), 
(29, 102, 1), 
(29, 84, 1), 
(29, 109, 1), 
(29, 107, 1), 
(29, 95, 1), 
(29, 105, 1), 
(29, 88, 1), 
(29, 81, 1), 
(22, 92, 1), 
(22, 108, 1), 
(22, 87, 1), 
(22, 101, 1), 
(22, 82, 1), 
(22, 93, 1), 
(22, 94, 1), 
(22, 85, 1), 
(22, 90, 1), 
(22, 89, 1), 
(22, 102, 1), 
(22, 84, 1), 
(22, 109, 1), 
(22, 107, 1), 
(22, 95, 1), 
(22, 105, 1), 
(22, 88, 1), 
(22, 81, 1), 
(23, 92, 2), 
(23, 108, 2), 
(23, 87, 2), 
(23, 101, 2), 
(23, 82, 2), 
(23, 93, 2), 
(23, 94, 2), 
(23, 85, 2), 
(23, 90, 2), 
(23, 89, 2), 
(23, 102, 2), 
(23, 84, 2), 
(23, 109, 2), 
(23, 107, 2), 
(23, 95, 2), 
(23, 105, 2), 
(23, 88, 2), 
(23, 81, 2), 
(24, 92, 1), 
(24, 108, 1), 
(24, 87, 1), 
(24, 101, 1), 
(24, 82, 1), 
(24, 93, 1), 
(24, 94, 1), 
(24, 85, 1), 
(24, 90, 1), 
(24, 89, 1), 
(24, 102, 1), 
(24, 84, 1), 
(24, 109, 1), 
(24, 107, 1), 
(24, 95, 1), 
(24, 105, 1), 
(24, 88, 1), 
(24, 81, 1), 
(25, 92, 2), 
(25, 108, 2), 
(25, 87, 2), 
(25, 101, 2), 
(25, 82, 2), 
(25, 93, 2), 
(25, 94, 2), 
(25, 85, 2), 
(25, 90, 2), 
(25, 89, 2), 
(25, 102, 2), 
(25, 84, 2), 
(25, 109, 2), 
(25, 107, 2), 
(25, 95, 2), 
(25, 105, 2), 
(25, 88, 2), 
(25, 81, 2), 
(26, 92, 3), 
(26, 108, 3), 
(26, 87, 3), 
(26, 101, 3), 
(26, 82, 3), 
(26, 93, 3), 
(26, 94, 3), 
(26, 85, 3), 
(26, 90, 3), 
(26, 89, 3), 
(26, 102, 3), 
(26, 84, 3), 
(26, 109, 3), 
(26, 107, 3), 
(26, 95, 3), 
(26, 105, 3), 
(26, 88, 3), 
(26, 81, 3), 
(27, 92, 4), 
(27, 108, 4), 
(27, 87, 4), 
(27, 101, 4), 
(27, 82, 4), 
(27, 93, 4), 
(27, 94, 4), 
(27, 85, 4), 
(27, 90, 4), 
(27, 89, 4), 
(27, 102, 4), 
(27, 84, 4), 
(27, 109, 4), 
(27, 107, 4), 
(27, 95, 4), 
(27, 105, 4), 
(27, 88, 4), 
(27, 81, 4), 
(42, 92, 1), 
(42, 108, 1), 
(42, 87, 1), 
(42, 101, 1), 
(42, 82, 1), 
(42, 93, 1), 
(42, 94, 1), 
(42, 85, 1), 
(42, 90, 1), 
(42, 89, 1), 
(42, 102, 1), 
(42, 84, 1), 
(42, 109, 1), 
(42, 107, 1), 
(42, 95, 1), 
(42, 105, 1), 
(42, 88, 1), 
(42, 81, 1), 
(43, 4, 1), 
(46, 4, 1), 
(47, 4, 1), 
(48, 4, 1), 
(50, 4, 1), 
(51, 4, 1), 
(52, 1, 1), 
(52, 3, 1), 
(53, 92, 1), 
(53, 108, 1), 
(53, 87, 1), 
(53, 101, 1), 
(53, 82, 1), 
(53, 93, 1), 
(53, 94, 1), 
(53, 85, 1), 
(53, 90, 1), 
(53, 89, 1), 
(53, 102, 1), 
(53, 84, 1), 
(53, 109, 1), 
(53, 107, 1), 
(53, 95, 1), 
(53, 105, 1), 
(53, 88, 1), 
(53, 81, 1), 
(53, 75, 1), 
(53, 79, 1), 
(53, 74, 1), 
(53, 3, 1), 
(53, 1, 1), 
(53, 4, 1), 
(53, 5, 1), 
(53, 6, 1), 
(53, 7, 1), 
(53, 8, 1), 
(53, 9, 1), 
(53, 10, 1), 
(53, 11, 1), 
(53, 12, 1), 
(53, 64, 1), 
(53, 73, 1), 
(53, 62, 1), 
(53, 61, 1), 
(53, 63, 1), 
(53, 69, 1), 
(53, 60, 1), 
(53, 18, 1), 
(53, 19, 1), 
(53, 20, 1), 
(53, 21, 1), 
(53, 22, 1), 
(53, 23, 1), 
(53, 24, 1), 
(53, 25, 1), 
(53, 26, 1), 
(53, 27, 1), 
(53, 28, 1), 
(53, 56, 1), 
(53, 30, 1), 
(53, 31, 1), 
(53, 32, 1), 
(53, 33, 1), 
(53, 34, 1), 
(53, 35, 1), 
(53, 36, 1), 
(53, 57, 1), 
(53, 37, 1), 
(53, 38, 1), 
(53, 39, 1), 
(53, 40, 1), 
(53, 58, 1), 
(53, 59, 1), 
(53, 50, 1), 
(53, 46, 1), 
(53, 47, 1), 
(53, 48, 1), 
(53, 49, 1), 
(53, 53, 1), 
(53, 54, 1), 
(54, 4, 2), 
(33, 3, 1), 
(32, 3, 1);


-- ---------------------------------------


--
-- Table structure for table `az_vi_comment`
--

DROP TABLE IF EXISTS `az_vi_comment`;
CREATE TABLE `az_vi_comment` (
  `cid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` int(11) NOT NULL DEFAULT '0',
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_time` int(11) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `post_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `likes` mediumint(9) NOT NULL DEFAULT '0',
  `dislikes` mediumint(9) NOT NULL DEFAULT '0',
  PRIMARY KEY (`cid`),
  KEY `mod_id` (`module`,`area`,`id`),
  KEY `post_time` (`post_time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_vi_contact_department`
--

DROP TABLE IF EXISTS `az_vi_contact_department`;
CREATE TABLE `az_vi_contact_department` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `phone` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `fax` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `others` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `cats` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admins` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `weight` smallint(5) NOT NULL,
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `full_name` (`full_name`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_contact_department`
--

INSERT INTO `az_vi_contact_department` VALUES
(3, 'Loại công trình', 'Loai-cong-trinh', '', '0914416567', '84053.857560', '', '', '', '{\"viber\":\"myViber\",\"skype\":\"mySkype\",\"yahoo\":\"myYahoo\"}', 'Biệt thự|Nhà phố|Căn hộ, penthouse|Khách sạn, resort|Bar, cafe, nhà hàng, karaoke|Spa, beauty salon|Showroom, shop, building, office|Loại công trình khác...', '1/1/1/0', 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `az_vi_contact_reply`
--

DROP TABLE IF EXISTS `az_vi_contact_reply`;
CREATE TABLE `az_vi_contact_reply` (
  `rid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `reply_content` text  COLLATE utf8mb4_unicode_ci,
  `reply_time` int(11) unsigned NOT NULL DEFAULT '0',
  `reply_aid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`rid`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_vi_contact_send`
--

DROP TABLE IF EXISTS `az_vi_contact_send`;
CREATE TABLE `az_vi_contact_send` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `send_time` int(11) unsigned NOT NULL DEFAULT '0',
  `sender_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_email` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_phone` varchar(20)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sender_goidichvu` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_khuvuc` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_dientich` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender_ip` varchar(15)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `is_reply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sender_name` (`sender_name`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_contact_send`
--

INSERT INTO `az_vi_contact_send` VALUES
(12, 3, 'Showroom, shop, building, office', 'Nhà ăn chuyên gia', 'Bó tay chấm con mẹ nó com', 1476622926, 0, 'Nguyễn Văn Vương', 'azvietco@gmail.com', '0932495121', 'Thi công phần Thô', 'Đà Nẵng', '1000m2', '123.23.173.228', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `az_vi_freecontent_blocks`
--

DROP TABLE IF EXISTS `az_vi_freecontent_blocks`;
CREATE TABLE `az_vi_freecontent_blocks` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_freecontent_blocks`
--

INSERT INTO `az_vi_freecontent_blocks` VALUES
(1, 'Sản phẩm', 'Sản phẩm của công ty cổ phần phát triển nguồn mở Việt Nam - VINADES.,JSC');


-- ---------------------------------------


--
-- Table structure for table `az_vi_freecontent_rows`
--

DROP TABLE IF EXISTS `az_vi_freecontent_rows`;
CREATE TABLE `az_vi_freecontent_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `bid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `target` varchar(10)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '_blank|_self|_parent|_top',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `start_time` int(11) NOT NULL DEFAULT '0',
  `end_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0: In-Active, 1: Active, 2: Expired',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  AUTO_INCREMENT=6  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_freecontent_rows`
--

INSERT INTO `az_vi_freecontent_rows` VALUES
(1, 1, 'Hệ quản trị nội dung NukeViet', '<ul>
	<li>Giải thưởng Nhân tài đất Việt 2011, 10.000+ website đang sử dụng</li>
	<li>Được Bộ GD&amp;ĐT khuyến khích sử dụng trong các cơ sở giáo dục</li>
	<li>Bộ TT&amp;TT quy định ưu tiên sử dụng trong cơ quan nhà nước</li>
</ul>', 'http://vinades.vn/vi/san-pham/nukeviet/', '_blank', 'cms.jpg', 1475277519, 0, 1), 
(2, 1, 'Cổng thông tin doanh nghiệp', '<ul>
	<li>Tích hợp bán hàng trực tuyến</li>
	<li>Tích hợp các nghiệp vụ quản lý (quản lý khách hàng, quản lý nhân sự, quản lý tài liệu)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-doanh-nghiep-NukeViet-portal/', '_blank', 'portal.jpg', 1475277519, 0, 1), 
(3, 1, 'Cổng thông tin Phòng giáo dục, Sở giáo dục', '<ul>
	<li>Tích hợp chung website hàng trăm trường</li>
	<li>Tích hợp các ứng dụng trực tuyến (Tra điểm SMS, Tra cứu văn bằng, Học bạ điện tử ...)</li>
</ul>', 'http://vinades.vn/vi/san-pham/Cong-thong-tin-giao-duc-NukeViet-Edugate/', '_blank', 'edugate.jpg', 1475277519, 0, 1), 
(4, 1, 'Tòa soạn báo điện tử chuyên nghiệp', '<ul>
	<li>Bảo mật đa tầng, phân quyền linh hoạt</li>
	<li>Hệ thống bóc tin tự động, đăng bài tự động, cùng nhiều chức năng tiên tiến khác...</li>
</ul>', 'http://vinades.vn/vi/san-pham/Toa-soan-bao-dien-tu/', '_blank', 'toa-soan-dien-tu.jpg', 1475277519, 0, 1), 
(5, 1, 'Giải pháp bán hàng trực tuyến', '<ul><li>Tích hợp các tính năng cơ bản bán hàng trực tuyến</li><li>Tích hợp với các cổng thanh toán, ví điện tử trên toàn quốc</li></ul>', 'http://vinades.vn', '_blank', 'shop.jpg', 1475277519, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `az_vi_menu`
--

DROP TABLE IF EXISTS `az_vi_menu`;
CREATE TABLE `az_vi_menu` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_menu`
--

INSERT INTO `az_vi_menu` VALUES
(1, 'Top Menu');


-- ---------------------------------------


--
-- Table structure for table `az_vi_menu_rows`
--

DROP TABLE IF EXISTS `az_vi_menu_rows`;
CREATE TABLE `az_vi_menu_rows` (
  `id` mediumint(5) NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(5) unsigned NOT NULL,
  `mid` smallint(5) NOT NULL DEFAULT '0',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `lev` int(11) NOT NULL DEFAULT '0',
  `subitem` text  COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `module_name` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `op` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `target` tinyint(4) DEFAULT '0',
  `css` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `active_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parentid` (`parentid`,`mid`)
) ENGINE=MyISAM  AUTO_INCREMENT=58  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_menu_rows`
--

INSERT INTO `az_vi_menu_rows` VALUES
(2, 0, 1, 'Shops', '/index.php?language=vi&nv=shops', '', '', 2, 10, 0, '53,54,55', '6', 'shops', '', 1, '', 0, 1), 
(3, 0, 1, 'Giới thiệu', '/index.php?language=vi&nv=about', '', '', 5, 16, 0, '', '6', 'about', '', 1, '', 0, 1), 
(42, 0, 1, 'Phong thủy', '/index.php?language=vi&nv=page&op=Phong-thuy.html', '', '', 4, 15, 0, '', '6', 'page', '', 1, '', 0, 1), 
(41, 0, 1, 'Bảng giá', '/index.php?language=vi&nv=page&op=Bang-gia.html', '', '', 3, 14, 0, '', '6', 'page', '', 1, '', 0, 1), 
(7, 0, 1, 'Liên hệ', '/index.php?language=vi&nv=contact', '', '', 6, 17, 0, '', '6', 'contact', '', 1, '', 0, 1), 
(43, 23, 1, 'Biệt thự', '/one/index.php?language=vi&nv=photos&amp;op=biet-thu', '', '', 1, 2, 1, '', '6', 'photos', 'biet-thu', 1, '', 1, 1), 
(44, 23, 1, 'Nhà phố', '/one/index.php?language=vi&nv=photos&amp;op=nha-pho', '', '', 2, 3, 1, '', '6', 'photos', 'nha-pho', 1, '', 1, 1), 
(45, 23, 1, 'Căn hộ, penthouse', '/one/index.php?language=vi&nv=photos&amp;op=can-ho-penthouse', '', '', 3, 4, 1, '', '6', 'photos', 'can-ho-penthouse', 1, '', 1, 1), 
(46, 23, 1, 'Khách sạn, resort', '/one/index.php?language=vi&nv=photos&amp;op=khach-san-resort', '', '', 4, 5, 1, '', '6', 'photos', 'khach-san-resort', 1, '', 1, 1), 
(47, 23, 1, 'Bar, cafe, nhà hàng, karaoke', '/one/index.php?language=vi&nv=photos&amp;op=bar-cafe-nha-hang-karaoke', '', '', 5, 6, 1, '', '6', 'photos', 'bar-cafe-nha-hang-karaoke', 1, '', 1, 1), 
(48, 23, 1, 'Spa, beauty salon', '/one/index.php?language=vi&nv=photos&amp;op=spa-beauty-salon', '', '', 6, 7, 1, '', '6', 'photos', 'spa-beauty-salon', 1, '', 1, 1), 
(49, 23, 1, 'Showroom, shop, building, office', '/one/index.php?language=vi&nv=photos&amp;op=showroom-shop-building-office', '', '', 7, 8, 1, '', '6', 'photos', 'showroom-shop-building-office', 1, '', 1, 1), 
(23, 0, 1, 'Dự án', '/index.php?language=vi&nv=photos', '', '', 1, 1, 0, '43,44,45,46,47,48,49,50', '6', 'photos', '', 1, '', 0, 1), 
(50, 23, 1, 'Showroom, shop, building, office', '/one/index.php?language=vi&nv=photos&amp;op=showroom-shop-building-office-8', '', '', 8, 9, 1, '', '6', 'photos', 'showroom-shop-building-office-8', 1, '', 1, 1), 
(53, 2, 1, 'Nội thất', '/one/index.php?language=vi&nv=shops&amp;op=noi-that', '', '', 1, 11, 1, '', '1', 'shops', 'noi-that', 1, '', 1, 1), 
(54, 2, 1, 'Vật liệu nội thất', '/one/index.php?language=vi&nv=shops&amp;op=vat-lieu-noi-that', '', '', 2, 12, 1, '', '1', 'shops', 'vat-lieu-noi-that', 1, '', 1, 1), 
(55, 2, 1, 'Đèn chiếu sáng', '/one/index.php?language=vi&nv=shops&amp;op=den-chieu-sang', '', '', 3, 13, 1, '', '1', 'shops', 'den-chieu-sang', 1, '', 1, 1);


-- ---------------------------------------


--
-- Table structure for table `az_vi_modfuncs`
--

DROP TABLE IF EXISTS `az_vi_modfuncs`;
CREATE TABLE `az_vi_modfuncs` (
  `func_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `func_name` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `func_custom_name` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `in_module` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `show_func` tinyint(4) NOT NULL DEFAULT '0',
  `in_submenu` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `subweight` smallint(2) unsigned NOT NULL DEFAULT '1',
  `setting` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`func_id`),
  UNIQUE KEY `func_name` (`func_name`,`in_module`),
  UNIQUE KEY `alias` (`alias`,`in_module`)
) ENGINE=MyISAM  AUTO_INCREMENT=111  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_modfuncs`
--

INSERT INTO `az_vi_modfuncs` VALUES
(1, 'main', 'main', 'Main', 'about', 1, 0, 1, ''), 
(2, 'sitemap', 'sitemap', 'Sitemap', 'about', 0, 0, 0, ''), 
(3, 'rss', 'rss', 'Rss', 'about', 1, 0, 0, ''), 
(4, 'main', 'main', 'Main', 'news', 1, 0, 1, ''), 
(5, 'viewcat', 'viewcat', 'Viewcat', 'news', 1, 0, 2, ''), 
(6, 'topic', 'topic', 'Topic', 'news', 1, 0, 3, ''), 
(7, 'content', 'content', 'Content', 'news', 1, 1, 4, ''), 
(8, 'detail', 'detail', 'Detail', 'news', 1, 0, 5, ''), 
(9, 'tag', 'tag', 'Tag', 'news', 1, 0, 6, ''), 
(10, 'rss', 'rss', 'Rss', 'news', 1, 1, 7, ''), 
(11, 'search', 'search', 'Search', 'news', 1, 1, 8, ''), 
(12, 'groups', 'groups', 'Groups', 'news', 1, 0, 9, ''), 
(13, 'sitemap', 'sitemap', 'Sitemap', 'news', 0, 0, 0, ''), 
(14, 'print', 'print', 'Print', 'news', 0, 0, 0, ''), 
(15, 'rating', 'rating', 'Rating', 'news', 0, 0, 0, ''), 
(16, 'savefile', 'savefile', 'Savefile', 'news', 0, 0, 0, ''), 
(17, 'sendmail', 'sendmail', 'Sendmail', 'news', 0, 0, 0, ''), 
(18, 'main', 'main', 'Main', 'users', 1, 0, 1, ''), 
(19, 'login', 'login', 'Đăng nhập', 'users', 1, 1, 2, ''), 
(20, 'register', 'register', 'Đăng ký', 'users', 1, 1, 3, ''), 
(21, 'lostpass', 'lostpass', 'Khôi phục mật khẩu', 'users', 1, 1, 4, ''), 
(22, 'active', 'active', 'Kích hoạt tài khoản', 'users', 1, 0, 5, ''), 
(23, 'lostactivelink', 'lostactivelink', 'Lostactivelink', 'users', 1, 0, 6, ''), 
(24, 'editinfo', 'editinfo', 'Thiếp lập tài khoản', 'users', 1, 1, 7, ''), 
(25, 'memberlist', 'memberlist', 'Danh sách thành viên', 'users', 1, 1, 8, ''), 
(26, 'avatar', 'avatar', 'Avatar', 'users', 1, 0, 9, ''), 
(27, 'logout', 'logout', 'Thoát', 'users', 1, 1, 10, ''), 
(28, 'groups', 'groups', 'Quản lý nhóm', 'users', 1, 0, 11, ''), 
(29, 'oauth', 'oauth', 'Oauth', 'users', 0, 0, 0, ''), 
(30, 'main', 'main', 'Main', 'statistics', 1, 0, 1, ''), 
(31, 'allreferers', 'allreferers', 'Theo đường dẫn đến site', 'statistics', 1, 1, 2, ''), 
(32, 'allcountries', 'allcountries', 'Theo quốc gia', 'statistics', 1, 1, 3, ''), 
(33, 'allbrowsers', 'allbrowsers', 'Theo trình duyệt', 'statistics', 1, 1, 4, ''), 
(34, 'allos', 'allos', 'Theo hệ điều hành', 'statistics', 1, 1, 5, ''), 
(35, 'allbots', 'allbots', 'Theo máy chủ tìm kiếm', 'statistics', 1, 1, 6, ''), 
(36, 'referer', 'referer', 'Đường dẫn đến site theo tháng', 'statistics', 1, 0, 7, ''), 
(37, 'main', 'main', 'Main', 'banners', 1, 0, 1, ''), 
(38, 'addads', 'addads', 'Addads', 'banners', 1, 0, 2, ''), 
(39, 'clientinfo', 'clientinfo', 'Clientinfo', 'banners', 1, 0, 3, ''), 
(40, 'stats', 'stats', 'Stats', 'banners', 1, 0, 4, ''), 
(41, 'cledit', 'cledit', 'Cledit', 'banners', 0, 0, 0, ''), 
(42, 'click', 'click', 'Click', 'banners', 0, 0, 0, ''), 
(43, 'clinfo', 'clinfo', 'Clinfo', 'banners', 0, 0, 0, ''), 
(44, 'logininfo', 'logininfo', 'Logininfo', 'banners', 0, 0, 0, ''), 
(45, 'viewmap', 'viewmap', 'Viewmap', 'banners', 0, 0, 0, ''), 
(46, 'main', 'main', 'main', 'comment', 1, 0, 1, ''), 
(47, 'post', 'post', 'post', 'comment', 1, 0, 2, ''), 
(48, 'like', 'like', 'Like', 'comment', 1, 0, 3, ''), 
(49, 'delete', 'delete', 'Delete', 'comment', 1, 0, 4, ''), 
(50, 'main', 'main', 'Main', 'page', 1, 0, 1, ''), 
(51, 'sitemap', 'sitemap', 'Sitemap', 'page', 0, 0, 0, ''), 
(52, 'rss', 'rss', 'Rss', 'page', 0, 0, 0, ''), 
(53, 'main', 'main', 'Main', 'siteterms', 1, 0, 1, ''), 
(54, 'rss', 'rss', 'Rss', 'siteterms', 1, 0, 2, ''), 
(55, 'sitemap', 'sitemap', 'Sitemap', 'siteterms', 0, 0, 0, ''), 
(56, 'main', 'main', 'Main', 'contact', 1, 0, 1, ''), 
(57, 'main', 'main', 'Main', 'voting', 1, 0, 1, ''), 
(58, 'main', 'main', 'Main', 'seek', 1, 0, 1, ''), 
(59, 'main', 'main', 'Main', 'feeds', 1, 0, 1, ''), 
(60, 'main', 'main', 'Main', 'slider', 1, 1, 1, ''), 
(61, 'detail', 'detail', 'Detail', 'photos', 1, 0, 4, ''), 
(62, 'detail_album', 'detail_album', 'Detail_album', 'photos', 1, 0, 3, ''), 
(63, 'detail_viewer', 'detail_viewer', 'Detail_viewer', 'photos', 1, 0, 5, ''), 
(64, 'main', 'main', 'Main', 'photos', 1, 0, 1, ''), 
(65, 'pagemap', 'pagemap', 'Pagemap', 'photos', 0, 0, 0, ''), 
(66, 'process', 'process', 'Process', 'photos', 0, 0, 0, ''), 
(67, 'rating', 'rating', 'Rating', 'photos', 0, 0, 0, ''), 
(68, 'rss', 'rss', 'Rss', 'photos', 0, 1, 0, ''), 
(69, 'search', 'search', 'Search', 'photos', 1, 1, 6, ''), 
(70, 'sitemap-image', 'sitemap-image', 'Sitemap-image', 'photos', 0, 0, 0, ''), 
(71, 'sitemap', 'sitemap', 'Sitemap', 'photos', 0, 0, 0, ''), 
(72, 'upload', 'upload', 'Upload', 'photos', 0, 0, 0, ''), 
(73, 'viewcat', 'viewcat', 'Viewcat', 'photos', 1, 0, 2, ''), 
(74, 'detail', 'detail', 'Detail', 'weblinks', 1, 0, 3, ''), 
(75, 'main', 'main', 'Main', 'weblinks', 1, 0, 1, ''), 
(76, 'reportlink', 'reportlink', 'Reportlink', 'weblinks', 0, 0, 0, ''), 
(77, 'rss', 'rss', 'Rss', 'weblinks', 0, 0, 0, ''), 
(78, 'sitemap', 'sitemap', 'Sitemap', 'weblinks', 0, 0, 0, ''), 
(79, 'viewcat', 'viewcat', 'Viewcat', 'weblinks', 1, 0, 2, ''), 
(80, 'visitlink', 'visitlink', 'Visitlink', 'weblinks', 0, 0, 0, ''), 
(81, 'blockcat', 'blockcat', 'Blockcat', 'shops', 1, 0, 18, ''), 
(82, 'cart', 'cart', 'Cart', 'shops', 1, 0, 5, ''), 
(83, 'checkorder', 'checkorder', 'Checkorder', 'shops', 0, 0, 0, ''), 
(84, 'compare', 'compare', 'Compare', 'shops', 1, 0, 12, ''), 
(85, 'complete', 'complete', 'Complete', 'shops', 1, 0, 8, ''), 
(86, 'delhis', 'delhis', 'Delhis', 'shops', 0, 0, 0, ''), 
(87, 'detail', 'detail', 'Detail', 'shops', 1, 0, 3, ''), 
(88, 'download', 'download', 'Download', 'shops', 1, 0, 17, ''), 
(89, 'group', 'group', 'Group', 'shops', 1, 0, 10, ''), 
(90, 'history', 'history', 'History', 'shops', 1, 0, 9, ''), 
(91, 'loadcart', 'loadcart', 'Loadcart', 'shops', 0, 0, 0, ''), 
(92, 'main', 'main', 'Main', 'shops', 1, 0, 1, ''), 
(93, 'order', 'order', 'Order', 'shops', 1, 0, 6, ''), 
(94, 'payment', 'payment', 'Payment', 'shops', 1, 0, 7, ''), 
(95, 'point', 'point', 'Point', 'shops', 1, 0, 15, ''), 
(96, 'print', 'print', 'Print', 'shops', 0, 0, 0, ''), 
(97, 'print_pro', 'print_pro', 'Print_pro', 'shops', 0, 0, 0, ''), 
(98, 'remove', 'remove', 'Remove', 'shops', 0, 0, 0, ''), 
(99, 'review', 'review', 'Review', 'shops', 0, 0, 0, ''), 
(100, 'rss', 'rss', 'Rss', 'shops', 0, 0, 0, ''), 
(101, 'search', 'search', 'Search', 'shops', 1, 0, 4, ''), 
(102, 'search_result', 'search_result', 'Search_result', 'shops', 1, 0, 11, ''), 
(103, 'sendmail', 'sendmail', 'Sendmail', 'shops', 0, 0, 0, ''), 
(104, 'setcart', 'setcart', 'Setcart', 'shops', 0, 0, 0, ''), 
(105, 'shippingajax', 'shippingajax', 'Shippingajax', 'shops', 1, 0, 16, ''), 
(106, 'sitemap', 'sitemap', 'Sitemap', 'shops', 0, 0, 0, ''), 
(107, 'tag', 'tag', 'Tag', 'shops', 1, 0, 14, ''), 
(108, 'viewcat', 'viewcat', 'Viewcat', 'shops', 1, 0, 2, ''), 
(109, 'wishlist', 'wishlist', 'Wishlist', 'shops', 1, 0, 13, ''), 
(110, 'wishlist_update', 'wishlist_update', 'Wishlist_update', 'shops', 0, 0, 0, '');


-- ---------------------------------------


--
-- Table structure for table `az_vi_modthemes`
--

DROP TABLE IF EXISTS `az_vi_modthemes`;
CREATE TABLE `az_vi_modthemes` (
  `func_id` mediumint(8) DEFAULT NULL,
  `layout` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  UNIQUE KEY `func_id` (`func_id`,`layout`,`theme`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_modthemes`
--

INSERT INTO `az_vi_modthemes` VALUES
(0, 'left-main-right', 'default'), 
(0, 'main', 'mobile_default'), 
(1, 'main', 'mobile_default'), 
(1, 'mainabout', 'default'), 
(3, 'main-right', 'default'), 
(4, 'home', 'default'), 
(4, 'main', 'mobile_default'), 
(5, 'main', 'default'), 
(5, 'main', 'mobile_default'), 
(6, 'main', 'default'), 
(6, 'main', 'mobile_default'), 
(7, 'main', 'default'), 
(7, 'main', 'mobile_default'), 
(8, 'main', 'default'), 
(8, 'main', 'mobile_default'), 
(9, 'main', 'default'), 
(9, 'main', 'mobile_default'), 
(10, 'main', 'default'), 
(11, 'main', 'default'), 
(11, 'main', 'mobile_default'), 
(12, 'main', 'default'), 
(12, 'main', 'mobile_default'), 
(18, 'main', 'default'), 
(18, 'main', 'mobile_default'), 
(19, 'main', 'default'), 
(19, 'main', 'mobile_default'), 
(20, 'main', 'default'), 
(20, 'main', 'mobile_default'), 
(21, 'main', 'default'), 
(21, 'main', 'mobile_default'), 
(22, 'main', 'default'), 
(22, 'main', 'mobile_default'), 
(23, 'main', 'default'), 
(23, 'main', 'mobile_default'), 
(24, 'main', 'default'), 
(24, 'main', 'mobile_default'), 
(25, 'main', 'default'), 
(25, 'main', 'mobile_default'), 
(26, 'main', 'default'), 
(27, 'main', 'default'), 
(27, 'main', 'mobile_default'), 
(28, 'main', 'default'), 
(28, 'main', 'mobile_default'), 
(30, 'main', 'default'), 
(30, 'main', 'mobile_default'), 
(31, 'main', 'default'), 
(31, 'main', 'mobile_default'), 
(32, 'main', 'default'), 
(32, 'main', 'mobile_default'), 
(33, 'main', 'default'), 
(33, 'main', 'mobile_default'), 
(34, 'main', 'default'), 
(34, 'main', 'mobile_default'), 
(35, 'main', 'default'), 
(35, 'main', 'mobile_default'), 
(36, 'main', 'default'), 
(36, 'main', 'mobile_default'), 
(37, 'main', 'default'), 
(37, 'main', 'mobile_default'), 
(38, 'main', 'default'), 
(38, 'main', 'mobile_default'), 
(39, 'main', 'default'), 
(39, 'main', 'mobile_default'), 
(40, 'main', 'default'), 
(40, 'main', 'mobile_default'), 
(46, 'main', 'default'), 
(46, 'main', 'mobile_default'), 
(47, 'main', 'default'), 
(47, 'main', 'mobile_default'), 
(48, 'main', 'default'), 
(48, 'main', 'mobile_default'), 
(49, 'main', 'default'), 
(49, 'main', 'mobile_default'), 
(50, 'main', 'default'), 
(50, 'main', 'mobile_default'), 
(53, 'main', 'default'), 
(53, 'main', 'mobile_default'), 
(54, 'main', 'default'), 
(54, 'main', 'mobile_default'), 
(56, 'main', 'default'), 
(56, 'main', 'mobile_default'), 
(57, 'main', 'default'), 
(57, 'main', 'mobile_default'), 
(58, 'main', 'default'), 
(58, 'main', 'mobile_default'), 
(59, 'main', 'default'), 
(59, 'main', 'mobile_default'), 
(60, 'main', 'default'), 
(61, 'main', 'default'), 
(62, 'main', 'default'), 
(63, 'main', 'default'), 
(64, 'main', 'default'), 
(65, 'left-main-right', 'default'), 
(66, 'left-main-right', 'default'), 
(67, 'left-main-right', 'default'), 
(68, 'left-main-right', 'default'), 
(69, 'main', 'default'), 
(70, 'left-main-right', 'default'), 
(71, 'left-main-right', 'default'), 
(72, 'left-main-right', 'default'), 
(73, 'main', 'default'), 
(74, 'main', 'default'), 
(75, 'main', 'default'), 
(76, 'left-main-right', 'default'), 
(77, 'left-main-right', 'default'), 
(78, 'left-main-right', 'default'), 
(79, 'main', 'default'), 
(80, 'left-main-right', 'default'), 
(81, 'main', 'default'), 
(82, 'main', 'default'), 
(83, 'left-main-right', 'default'), 
(84, 'main', 'default'), 
(85, 'main', 'default'), 
(86, 'left-main-right', 'default'), 
(87, 'main', 'default'), 
(88, 'main', 'default'), 
(89, 'main', 'default'), 
(90, 'main', 'default'), 
(91, 'left-main-right', 'default'), 
(92, 'main', 'default'), 
(93, 'main', 'default'), 
(94, 'main', 'default'), 
(95, 'main', 'default'), 
(96, 'left-main-right', 'default'), 
(97, 'left-main-right', 'default'), 
(98, 'left-main-right', 'default'), 
(99, 'left-main-right', 'default'), 
(100, 'left-main-right', 'default'), 
(101, 'main', 'default'), 
(102, 'main', 'default'), 
(103, 'left-main-right', 'default'), 
(104, 'left-main-right', 'default'), 
(105, 'main', 'default'), 
(106, 'left-main-right', 'default'), 
(107, 'main', 'default'), 
(108, 'main', 'default'), 
(109, 'main', 'default'), 
(110, 'left-main-right', 'default');


-- ---------------------------------------


--
-- Table structure for table `az_vi_modules`
--

DROP TABLE IF EXISTS `az_vi_modules`;
CREATE TABLE `az_vi_modules` (
  `title` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_file` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_data` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `module_upload` varchar(55)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `custom_title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_title` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  `main_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admin_file` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `theme` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `mobile` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `admins` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `rss` tinyint(4) NOT NULL DEFAULT '1',
  `gid` smallint(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`title`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_modules`
--

INSERT INTO `az_vi_modules` VALUES
('about', 'page', 'about', 'about', 'Giới thiệu', '', 1475277519, 1, 1, '', '', '', '', '6', 3, 1, '', 1, 0), 
('news', 'news', 'news', 'news', 'Tin Tức', '', 1475277519, 1, 1, '', '', '', '', '6', 4, 1, '', 1, 0), 
('users', 'users', 'users', 'users', 'Thành viên', 'Tài khoản', 1475277519, 1, 1, '', '', '', '', '6', 7, 1, '', 0, 0), 
('contact', 'contact', 'contact', 'contact', 'Liên hệ', '', 1475277519, 1, 1, '', '', '', '', '6', 8, 1, '', 0, 0), 
('statistics', 'statistics', 'statistics', 'statistics', 'Thống kê', '', 1475277519, 1, 1, '', '', '', 'online, statistics', '6', 9, 1, '', 0, 0), 
('voting', 'voting', 'voting', 'voting', 'Thăm dò ý kiến', '', 1475277519, 1, 1, '', '', '', '', '6', 10, 1, '', 1, 0), 
('banners', 'banners', 'banners', 'banners', 'Quảng cáo', '', 1475277519, 1, 1, '', '', '', '', '6', 11, 1, '', 0, 0), 
('seek', 'seek', 'seek', 'seek', 'Tìm kiếm', '', 1475277519, 1, 0, '', '', '', '', '6', 12, 1, '', 0, 0), 
('menu', 'menu', 'menu', 'menu', 'Menu Site', '', 1475277519, 0, 1, '', '', '', '', '6', 13, 1, '', 0, 0), 
('feeds', 'feeds', 'feeds', 'feeds', 'RSS-feeds', 'RSS-feeds', 1475277519, 1, 1, '', '', '', '', '6', 14, 1, '', 0, 0), 
('page', 'page', 'page', 'page', 'Page', '', 1475277519, 1, 1, '', '', '', '', '6', 15, 1, '', 1, 0), 
('comment', 'comment', 'comment', 'comment', 'Bình luận', 'Quản lý bình luận', 1475277519, 0, 1, '', '', '', '', '6', 16, 1, '', 0, 0), 
('siteterms', 'page', 'siteterms', 'siteterms', 'Điều khoản sử dụng', '', 1475277519, 1, 1, '', '', '', '', '6', 17, 1, '', 1, 0), 
('freecontent', 'freecontent', 'freecontent', 'freecontent', 'Giới thiệu sản phẩm', '', 1475277519, 0, 1, '', '', '', '', '6', 18, 1, '', 0, 0), 
('slider', 'slider', 'slider', 'slider', 'Slides', '', 1475290330, 1, 1, '', '', '', '', '6', 6, 1, '', 0, 0), 
('photos', 'photos', 'photos', 'photos', 'Dự án', '', 1475296369, 1, 1, '', '', '', '', '6', 5, 1, '', 1, 0), 
('weblinks', 'weblinks', 'weblinks', 'weblinks', 'Bảng giá', '', 1475395555, 1, 1, '', '', '', '', '6', 2, 1, '', 1, 0), 
('shops', 'shops', 'shops', 'shops', 'Shops', '', 1475427388, 1, 1, '', '', '', '', '6', 1, 1, '', 1, 0);


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_1`
--

DROP TABLE IF EXISTS `az_vi_news_1`;
CREATE TABLE `az_vi_news_1` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=24  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_1`
--

INSERT INTO `az_vi_news_1` VALUES
(22, 1, '1', 0, 1, '', 0, 1477450135, 1477450135, 1, 1477449960, 0, 2, 'Cách bố trí sofa hợp phong thủy', 'cach-bo-tri-sofa-hop-phong-thuy', 'Việc bài trí sofa đúng cách không chỉ mang lại vẻ đẹp thanh thoát cho căn phòng mà còn mang tài vận và may mắn đến cho gia chủ. Trong phòng khách, bộ sofa luôn là tâm điểm thu hút sự chú ý khi bước chân vào không gian này.', '2016_10/up-04.jpg', '', 1, 1, '4', 1, 2, 0, 0, 0), 
(23, 1, '1', 0, 1, '', 0, 1477450222, 1477450222, 1, 1477450140, 0, 2, 'Kinh nghiệm chọn mua sofa da', 'kinh-nghiem-chon-mua-sofa-da', 'Hiện nay, Sofa da đã trở thành một trong những đồ nội thất phổ biến và được nhiều gia đình lựa chọn, đặc biệt là những gia chủ muốn thể hiện đẳng cấp, sự sang trọng cho ngôi nhà. Nhưng trên thị trường luôn tràn ngập các mẫu mã, thương hiệu, khiến Bạn phải hoa mắt và đau đầu khi lựa chọn. Bạn không phân biệt được Sofa da thật và Sofa giả da? Bạn không biết làm thế nào để đánh giá được chất lượng của một chiếc ghế Sofa? Nên chọn mua Sofa da nhập khẩu hay sử dụng Sofa nội địa? Hãy để Nội thất Nhà Đẹp chia sẻ với Bạn một số kinh nghiệm khi lựa chọn và đánh giá chất lượng một bộ Sofa da.', '2016_10/kennedy_26311r153.jpg', 'KENNEDY 26311R153', 1, 1, '4', 1, 2, 0, 0, 0), 
(20, 1, '1', 0, 1, '', 0, 1477449577, 1477684146, 1, 1477449420, 0, 2, 'Bí quyết thiết ké nội thất chung cư theo phong cách riêng', 'bi-quyet-thiet-ke-noi-that-chung-cu-theo-phong-cach-rieng', 'Thiết kế nội thất chung cư mang phong cách, dấu ấn riêng của gia đình bạn đòi hỏi sự khéo léo, tinh tế, khéo léo và khoa học, dưới đây là một số bí quyết để thực hiện điều đó mọi người cùng tham khảo:', '2016_10/bi-quyet-thiet-ke-noi-that-chung-cu-dep-3.jpg', 'AZVIET CMS', 1, 1, '4', 1, 2, 0, 0, 0), 
(21, 1, '1', 0, 1, '', 0, 1477449818, 1477684169, 1, 1477449540, 0, 2, 'Xu hướng thiết kế', 'xu-huong-thiet-ke', 'Pha trộn nâu đậm, một chút nâu nhẹ nhàng không hề khiến phòng ngủ trở nên tẻ nhạt, trái lại nó sẽ tạo được phong cách và sự lãng mạn cho không gian yên bình này. Công ty thiết kế nội thất chung cư uy tín - Amore.com.vn xin chia sẻ với bạn đọc một số mẫu thiết kế mọi người cùng tham khảo nhé!', '2016_10/khong_gian_phong_ngu_lang_man_va_phong_cach_voi_gam_mau_nau85.jpg', '', 1, 1, '4', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_admins`
--

DROP TABLE IF EXISTS `az_vi_news_admins`;
CREATE TABLE `az_vi_news_admins` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` smallint(5) NOT NULL DEFAULT '0',
  `admin` tinyint(4) NOT NULL DEFAULT '0',
  `add_content` tinyint(4) NOT NULL DEFAULT '0',
  `pub_content` tinyint(4) NOT NULL DEFAULT '0',
  `edit_content` tinyint(4) NOT NULL DEFAULT '0',
  `del_content` tinyint(4) NOT NULL DEFAULT '0',
  `app_content` tinyint(4) NOT NULL DEFAULT '0',
  UNIQUE KEY `userid` (`userid`,`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_block`
--

DROP TABLE IF EXISTS `az_vi_news_block`;
CREATE TABLE `az_vi_news_block` (
  `bid` smallint(5) unsigned NOT NULL,
  `id` int(11) unsigned NOT NULL,
  `weight` int(11) unsigned NOT NULL,
  UNIQUE KEY `bid` (`bid`,`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_block`
--

INSERT INTO `az_vi_news_block` VALUES
(2, 20, 4), 
(2, 21, 3), 
(2, 22, 2), 
(2, 23, 1);


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_block_cat`
--

DROP TABLE IF EXISTS `az_vi_news_block_cat`;
CREATE TABLE `az_vi_news_block_cat` (
  `bid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `adddefault` tinyint(4) NOT NULL DEFAULT '0',
  `numbers` smallint(5) NOT NULL DEFAULT '10',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_block_cat`
--

INSERT INTO `az_vi_news_block_cat` VALUES
(1, 0, 4, 'Tin tiêu điểm', 'Tin-tieu-diem', '', 'Tin tiêu điểm', 1, '', 1279945710, 1279956943), 
(2, 1, 4, 'Tin mới nhất', 'Tin-moi-nhat', '', 'Tin mới nhất', 2, '', 1279945725, 1279956445);


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_cat`
--

DROP TABLE IF EXISTS `az_vi_news_cat`;
CREATE TABLE `az_vi_news_cat` (
  `catid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `titlesite` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `descriptionhtml` text  COLLATE utf8mb4_unicode_ci,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `viewdescription` tinyint(2) NOT NULL DEFAULT '0',
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `viewcat` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `newday` tinyint(2) unsigned NOT NULL DEFAULT '2',
  `featured` int(11) NOT NULL DEFAULT '0',
  `ad_block_cat` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `admins` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`catid`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parentid` (`parentid`)
) ENGINE=MyISAM  AUTO_INCREMENT=13  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_cat`
--

INSERT INTO `az_vi_news_cat` VALUES
(1, 0, 'Tin tức', '', 'Tin-tuc', '', '', '', 0, 1, 1, 0, 'viewcat_page_new', 0, '', 1, 4, 2, 0, '', '', '', 1274986690, 1274986690, '6');


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_config_post`
--

DROP TABLE IF EXISTS `az_vi_news_config_post`;
CREATE TABLE `az_vi_news_config_post` (
  `group_id` smallint(5) NOT NULL,
  `addcontent` tinyint(4) NOT NULL,
  `postcontent` tinyint(4) NOT NULL,
  `editcontent` tinyint(4) NOT NULL,
  `delcontent` tinyint(4) NOT NULL,
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_config_post`
--

INSERT INTO `az_vi_news_config_post` VALUES
(1, 0, 0, 0, 0), 
(2, 0, 0, 0, 0), 
(3, 0, 0, 0, 0), 
(4, 0, 0, 0, 0), 
(7, 0, 0, 0, 0), 
(5, 0, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_detail`
--

DROP TABLE IF EXISTS `az_vi_news_detail`;
CREATE TABLE `az_vi_news_detail` (
  `id` int(11) unsigned NOT NULL,
  `bodyhtml` longtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `sourcetext` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imgposition` tinyint(1) NOT NULL DEFAULT '1',
  `copyright` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_send` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_print` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_save` tinyint(1) NOT NULL DEFAULT '0',
  `gid` mediumint(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_detail`
--

INSERT INTO `az_vi_news_detail` VALUES
(23, '<ol>	<li><strong>Kiểm tra thông tin về khung</strong></li></ol><p>Khi chọn mua Sofa thì bạn cần&nbsp; lưu ý đến bộ khung, vì khung là phần chịu tải trọng cho ghế, cũng là phần rất quan trọng:</p><p>–&nbsp;Hãy hỏi rõ người bán xem khung Sofa được làm từ loại gỗ nào, có phải gỗ thịt hay không, tuổi của gỗ là bao nhiêu? Tuy nhiên những thông tin này Bạn rất khó kiểm chứng vì khung Sofa là phần Bạn không nhìn thấy. Việc hỏi những thông tin này là để xem người bán hàng trả lời như thế nào, qua đó bạn cảm nhận và đánh giá về tính trung thực của người bán.</p><p>–&nbsp;Kiểm tra độ nặng của ghế Sofa, thường nếu Sofa được làm từ gỗ tốt như Bulo, Gụ, Long Não, Sồi, Thích, Dẻ Gai và trên 20 năm tuổi thì sẽ khá nặng, khối lượng trung bình từ 50~80 kg/m dài.</p><p>–&nbsp;Kiểm tra độ chắc chắn của bộ Sofa bằng cách nâng 1 góc phía mặt trước của Sofa lên 10~15cm, nếu chân đối diện của ghế Sofa cũng nhấc lên khỏi mặt sàn, tức là khung đủ chắc và không bị oằn, cong vênh khi chịu lực. Hoặc hãy thử lay các cạnh ghế, nhấc một góc của ghế và lắc nhẹ, nếu cảm thấy nhẹ và lung lay, hãy bỏ qua.</p><p>&nbsp;</p><ol start=\"2\">	<li><strong>Kiểm tra chất lượng phần đệm ngồi</strong></li></ol><p>Tương tự như phần khung, phần đệm ngồi Bạn cũng không nhìn được thực tế chi tiết cấu trúc của phần này, tuy nhiên đừng vì thế mà ngại ngần không hỏi rõ nhân viên bán hàng.</p><p>–&nbsp;Hãy yêu cầu người bán trả lời các câu hỏi như: Kết cấu phần đệm ngồi và tựa lưng của bộ Sofa da này như thế nào? Dùng lò xo gì? Đệm mút có mấy lớp? Đệm có bị xẹp không? Đệm và tựa lưng sử dụng bông hay lông vũ?</p><p>–&nbsp;Hãy ngồi thử lên sản phẩm, cảm &nbsp;nhận độ êm ái và độ đàn hồi của cả bộ Sofa. Thường Sofa da mà có cấu trúc đệm và lò xo tốt thì sẽ cho bạn cảm giác êm ái và dễ chịu. Hãy ngồi thử ở nhiều ghế Sofa khác nhau để cảm nhận và so sánh. Bạn hãy nhớ đừng bao giờ lựa chọn một bộ Sofa chỉ đẹp về hình thức mà đặc tính và công năng lại kém, bạn sẽ thấy hối tiếc mỗi khi ngồi lên nó. Sofa da mà phần đệm ngồi bị cứng, không thỏa mái sẽ luôn làm Bạn mệt mỏi và khó chịu. Một bộ Sofa da hoàn hảo là sự kết hợp giữa vẻ đẹp, độ bền và có giá trị sử dụng cao, mang lại cảm giác dễ chịu, thư giãn cho người sử dụng.</p><p>&nbsp;</p><ol start=\"3\">	<li><strong>Kiểm tra chất lượng và thông tin về lớp da</strong></li></ol><p><em>Về lý thuyết</em>, bạn có thể kiểm tra trực tiếp chất lượng thực tế của lớp vỏ bọc bằng da của bộ Sofa, tuy nhiên không phải khách hàng nào cũng có thể đánh giá đúng 100% về chất lượng của da. Đơn giản là vì không phải ai cũng là chuyên gia về da. Hơn nữa hiện nay công nghệ thuộc da rất phát triển, ngày càng có nhiều loại da với những đặc điểm hao hao giống nhau. Tuy nhiên đừng quá lo lắng về điều này, vẫn có những cách giúp Bạn kiểm tra chất lượng da Sofa:</p><p>–&nbsp;Hãy hỏi người bán hàng: Ghế sofa da được làm từ loại da bò nào (Full grain, corrected grain, split)? Độ dầy của loại da được sử dụng? Tất cả các phần của bộ Sofa đều được làm từ cùng một loại da hay là kết hợp giữa những loại da trên?</p><p>–&nbsp;Yêu cầu người bán cung cấp mẫu da được sử dụng cho sản phẩm để Bạn kiểm tra. Kiểm tra mặt trong và mặt ngoài của mẫu và so sánh với lớp da trên sản phẩm.</p><p>–&nbsp;Hãy yêu cầu người bán cho xem các mẫu da với chất lượng khác nhau. Sờ và cảm nhận độ dầy, độ mềm mại của lớp da trên sản phẩm sau đó so sánh các mẫu da với nhau.</p><p>–&nbsp;Kiểm tra chất lượng da ở nhiều vị trí khác nhau trên sản phẩm và đối chiếu với thông tin người bán cung cấp lúc ban đầu.</p><p>–&nbsp;Kiểm tra các đường may trên vỏ Sofa. Một bộ Sofa da tốt thường sẽ có đường may ngay ngắn, đều, nổi, chắc chắn.</p><div style=\"text-align:center\"><a href=\"http://nhadep.dev/wp-content/uploads/2015/10/image0021.jpg\"><img alt=\"image0021\" height=\"400\" src=\"/uploads/news/2016_10/image0021.jpg\" width=\"600\" /></a></div><p>Sofa da thật của Nhà Đẹp</p><p>&nbsp;</p><ol start=\"4\">	<li><strong>Kiểm tra thông tin về các dịch vụ bảo hành bảo trì</strong></li></ol><p>Ngoài việc kiểm tra thông tin và chất lượng thực tế, Bạn đừng bao giờ quên hỏi về các thông tin dịch vụ đi kèm với sản phẩm. Như đã nêu ở trên, hầu hết các khách hàng khó có thể tự kiểm tra và đánh giá chính xác về chất lượng thực tế của sản phẩm. Vì vậy các thông tin về dịch vụ bảo hành bảo trì đi kèm sản phẩm sẽ giúp ích rất nhiều cho việc nhận định và đánh giá chất lượng thực tế của sản phẩm.</p><p>Ghế Sofa da cao cấp thực sự, thường có giá trị khá cao do đó những người bán uy tín sẽ áp dụng các dịch vụ bảo hành bảo trì khá dài. Thời gian bảo hành, bảo trì càng lâu thì chứng tỏ mức độ tin cậy của sản phẩm càng cao. Hơn nữa, khi Bạn đầu tư một số tiền lớn để sở hữu một bộ Sofa da cao cấp, Bạn xứng đáng nhận được những dịch vụ tận tình, chu đáo.</p>', '', 2, 0, 1, 1, 1, 0), 
(20, '<p><em>Thiết kế nội thất chung cư&nbsp;</em>đẹp trước tiên phải quan tâm đến giá trị sử dụng vì diện tích của các căn hộ chung cư không quá rộng rãi nên phải tận dụng từng mét vuông đất để phát huy tối đa khả năng sử dụng của chúng. Nếu biết khéo léo vận dụng một vài bí quyết nhỏ sau, không gian chung cư nhà bạn sẽ trở nên sinh động, phong cách và khoa học hơn rất nhiều.</p><div style=\"text-align:center\"><img alt=\"AZVIET CMS\" height=\"400\" src=\"/uploads/news/2016_10/bi-quyet-thiet-ke-noi-that-chung-cu-dep-3.jpg\" width=\"600\" /></div><p>Một đặc điểm phổ biến của các căn hộ chung cư hiện nay và ta dễ dàng nhận thấy là chính vì diện tích không lớn nên nhiều căn hộ không đủ ánh sáng mà luôn luôn và nhờ đến nguồn ánh sáng từ đèn điện.&nbsp;<em>Thiết kế nội thất&nbsp;chung cư</em>&nbsp;đẹp&nbsp;là làm sao giảm sự chất chội, bí bách của không gian chung cư nhờ vào màu sắc và trang trí nội thất. Chung cư nên sử dụng màu sơn nhạt, nhẹ nhàng, tươi sáng để làm cho không gian sáng sủa hơn. Không nên lạm dụng đồ vật trang trí quá nhiều trong phòng, những đồ nội thất nên có hình khối vuông vức, điều đó khiến cho căn hộ gọn gàng hơn và dễ sắp đặt những đồ vật khác lên trên.</p><p>Hãy tưởng tượng một chiếc bàn đặt trong phòng khách có ngăn kéo đựng sách báo dưới gầm cũng như tủ trưng bày tích hợp với tủ để ti vi cũng là một thiết kế đầy công năng. Có lẽ căn bếp chung cư là nơi thích hợp để sử dụng những thiết kế nội thất đầy tính căn năng như tủ bếp, bàn bếp kết hợp làm bàn ăn…</p><div style=\"text-align:center\"><img alt=\"AZVIET CMS\" height=\"575\" src=\"/uploads/news/2016_10/bi-quyet-thiet-ke-noi-that-chung-cu-dep.jpg\" width=\"600\" /></div><p>Các căn hộ chung cư trong cùng một tòa nhà thường có kết cấu giống nhau và cấu trúc các phòng cũng tương đồng. Nhiệm vụ của nhà&nbsp;thiết kế nội thất chung cư&nbsp;là phải tạo ra được sự khác biệt dựa trên sự sắp xếp và trang trí nội thất trong nhà. Sự khác biệt đó là nhờ cách bố trí đồ nội thất, cách sử dụng đồ vật trang trí và sự kết hợp màu sắc cũng như chất liệu. Một bí quyết cơ bản để không gian nội thất nhà bạn trở nên khác biệt chính là phải tạo ra điểm nhấn cho căn hộ. Nếu bạn biết tận dụng một góc nhỏ trong lối ra vào để đặt một tủ để giày cùng một vài đồ trang trí hay giá sách thiết kế nhỏ gọn trên tường, một vài bức tranh cũng có thể khiến chung cư nhà bạn trở nên độc đáo và thú vị hơn.</p>', '', 2, 0, 1, 1, 1, 0), 
(21, '<h2>Không gian phòng ngủ lãng mạn và phong cách với gam màu nâu</h2><div style=\"text-align:center\"><img alt=\"AZVIET CMS\" height=\"593\" src=\"/uploads/news/2016_10/khong_gian_phong_ngu_lang_man_va_phong_cach_voi_gam_mau_nau85.jpg\" width=\"927\" /></div><p>&nbsp;</p><p><em><strong>Thiết kế nội thất chung cư cho không gian phòng ngủ với gam màu nâu nhạt thêm lãng mạn và phong cách</strong></em></p><p>Màu nâu, gam màu trung tính nhưng không kém chút dịu dàng. Một&nbsp;phòng ngủ&nbsp;với chút gam màu nâu sẽ khiến không gian thêm lãng mạn và phá cách. Cùng dạo và xem để để quyết định có thay đổi cho phòng ngủ nhà mình hay không nhé!</p><div style=\"text-align:center\"><img alt=\"AZVIET CMS\" height=\"780\" src=\"/uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau.jpg\" width=\"1043\" /></div><p>Phòng ngủ này mang nét lãng mạn cổ điển với màu nâu tạo vẻ đẹp cân bằng cho màu xanh dương và màu kem làm điểm nhấn không gian.</p><div style=\"text-align:center\"><img alt=\"AZVIET CMS\" height=\"1128\" src=\"/uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau2.jpg\" width=\"750\" /></div><p>Nếu bạn cảm thấy chỉ toàn những gam màu trung tính sẽ gây tẻ nhạt cho căn phòng, vậy thì có thẻ kết hợp thêm những&nbsp;phụ kiện&nbsp;có màu sắc ấm cúng, sôi nổi để tạo cảm giác đầy sức sống cho không gian phòng ngủ.</p><div style=\"text-align:center\"><img alt=\"AZVIET CMS\" height=\"1200\" src=\"/uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau3.jpg\" width=\"970\" /></div><p>Với&nbsp;tone nâu đậm hơn một chút thành màu socola nhưng nhờ được kết hợp với gam trắng mềm mại, phòng ngủ vẫn có được nét lãng mạnh tinh tế.</p><div style=\"text-align:center\"><img alt=\"AZVIET CMS\" height=\"593\" src=\"/uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau5.jpg\" width=\"927\" /></div><p>Mẫu&nbsp;<em><strong>thiết&nbsp;kế nội thất chung cư hiện đại</strong></em>&nbsp;với&nbsp;phòng ngủ đơn sắc lãng mạn với màu nâu và thêm chút màu kim loại bóng giúp phòng ngủ lấp lánh mà không bị quá độ.</p><div style=\"text-align:center\"><img alt=\"AZVIET CMS\" height=\"607\" src=\"/uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau6.jpg\" width=\"919\" /></div><p>Bất kể khi nào bạn thêm màu tự nhiên, hãy lấy chúng làm trung tâm, bạn sẽ nhận được một bầu không khí lãng mạn tuyệt vời hơn. Và khi bạn thêm các yếu tố kiến trúc hiện đại, bạn sẽ nhận được một phòng ngủ với chút lãng mạn kết hợp&nbsp;<em>phong cách hiện đại</em>.</p><div style=\"text-align:center\"><img alt=\"AZVIET CMS\" height=\"597\" src=\"/uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau7.jpg\" width=\"924\" /></div><p>Phòng ngủ theo phong cách chiết trung. Chút màu nâu với nhiều tone màu đậm nhạt khác nhau khiến cho phòng ngủ này mặc dù đơn điệu nhưng lại chẳng hề đơn điệu chút nào. Với mẫu thiết kế này, bạn có thể&nbsp;áp dụng cho các mẫu&nbsp;<strong><em>thiết kế nội thất chung cư nhỏ</em></strong>&nbsp;phù hợp với diện tích căn hộ.</p><div style=\"text-align:center\"><img alt=\"phong ngu phong cach va toi gian voi gam mau nau9\" height=\"594\" src=\"/uploads/news/2016_10/phong-ngu-phong-cach-va-toi-gian-voi-gam-mau-nau9.jpg\" width=\"914\" /></div><p>Nếu bạn là người thuộc chủ nghĩa tối giản, thì phòng ngủ với phong cách tối giản bởi hai gam màu trắng nâu này sẽ là sự lựa chọn bạn nên xem xét. Vẫn rất sang trọng, nhưng không cầu kỳ, đủ để đáp ứng đòi hỏi của những người theo chủ nghĩa tối giản khó tính nhất.</p>', '', 2, 0, 1, 1, 1, 0), 
(22, '<p>Hướng bài trí của sofa nên hướng vào hướng vượng, hướng vượng gồm có hướng chính Đông, hướng Đông Bắc, hướng chính Tây và hướng chính Nam. Vì vậy, nên lựa chọn ghế chính dựa lưng vào tường theo các hướng kể trên giúp mang đến nhiều tài lộc và phú quý cho gia chủ.</p><div style=\"text-align:center\"><a href=\"http://nhadep.com.vn/wp-content/uploads/up-012.jpg\"><img alt=\"up 012\" height=\"474\" src=\"/uploads/news/2016_10/up-012.jpg\" width=\"700\" /></a></div><p>Khi bài trí ghế sofa, ít nhất cần có một ghế sofa đặt dựa lưng vào tường bởi ghế và tường theo phong thủy có liên quan và ảnh hưởng rất lớn đến nhau. Lưng ghế dựa vào tường giống như khi gia chủ có chỗ ngồi vững chắc sẽ dễ phát triển sự nghiệp và công danh.</p><p>Nếu sau lưng sofa không có chỗ dựa nào thì dễ xuất hiện vấn đề hao hụt về tài chính. Vì thế, khi đằng sau sofa không có tường để dựa thì bạn nên đặt một chiếc tủ, kệ hoặc tấm bình phong làm vị trí “hạo sơn” (tựa núi) cho sofa.</p><div style=\"text-align:center\"><a href=\"http://nhadep.com.vn/wp-content/uploads/up-02.jpg\"><img alt=\"up 02\" height=\"529\" src=\"/uploads/news/2016_10/up-02.jpg\" width=\"700\" /></a></div><p>Tuy nhiên, không phải cứ đặt sofa dựa vào tường sẽ đều tốt. Có những vị trí không nên đặt, ví dụ như sau lưng tường là nhà vệ sinh, nhà bếp thì không nên làm tường dựa cho sofa. Sau lưng tường là bên ngoài của ngôi nhà, dễ bị ảnh hưởng của thời tiết mưa nắng thì cũng không nên làm tường dựa.</p><p>Khi bài trí sofa, gia chủ có thể chọn cho mình một vị trí cố định để tiếp khách khứa. Vị trí đó thường là ở chiếc ghế dựa vào tường và có thể nhìn thấy được cửa phòng khách cũng như bao quát bên ngoài. Nếu phong cảnh bên ngoài không được đẹp lắm thì có thể bài trí những chậu hoa, cây cảnh.</p><div style=\"text-align:center\"><a href=\"http://nhadep.com.vn/wp-content/uploads/up-03.jpg\"><img alt=\"up 03\" height=\"420\" src=\"/uploads/news/2016_10/up-03.jpg\" width=\"700\" /></a></div><p>Một vị trí đẹp và nhìn ra một khung cảnh đẹp sẽ mang đến những thuận lợi và may mắn cho sự nghiệp của chủ nhân cũng như những thành viên sống trong nhà.</p><p>Theo phong thủy truyền thống, khi đặt sofa theo hình chữ U, trong đó đáy của chữ U cũng là chiếc ghế đặt dựa lưng vào tường và hướng ra ngoài cửa chính. Hai bên sofa quay mặt vào nhau tượng trưng cho hai cánh tay dang rộng đón lấy nhiều tiền tài và của cải chảy vào nhà.</p><p>Bài trí theo cách này sẽ mang đến nhiều vận may cũng như sự an khang, thịnh vượng cho gia chủ, đặc biệt là những gia đình làm nghề kinh doanh, buôn bán.</p><div style=\"text-align:center\"><a href=\"http://nhadep.com.vn/wp-content/uploads/up-04.jpg\"><img alt=\"up 04\" height=\"522\" src=\"/uploads/news/2016_10/up-04.jpg\" width=\"700\" /></a></div><p>Về hình dáng và kích thước của sofa, khi chọn sofa đặt trong phòng nên chọn 1 bộ hoàn chỉnh, cân đối về kích thước và có cùng màu sắc. Bên cạnh đó, kích thước của sofa nên phù hợp với diện tích của phòng khách.</p><p>Nếu sofa quá to và choán hết diện tích của căn phòng hoặc quá nhỏ, lọt thỏm trong phòng có diện tích khá rộng rãi đều dễ gây ảnh hưởng đến tâm lý, tinh thần bất an cho gia chủ.</p><p>Ngoài ra, khi bài trí sofa cũng cần lưu ý đến các vật dụng khác trong phòng khách. Không nên đặt gương phía sau, đèn chùm phía trước ghế hay ánh sáng chiếu thẳng vào phía chỗ ngồi đều dễ gây cảm giác mệt mỏi và ức chế cho gia chủ.</p>', '', 2, 0, 1, 1, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_logs`
--

DROP TABLE IF EXISTS `az_vi_news_logs`;
CREATE TABLE `az_vi_news_logs` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `sid` mediumint(8) NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `set_time` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_rows`
--

DROP TABLE IF EXISTS `az_vi_news_rows`;
CREATE TABLE `az_vi_news_rows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `listcatid` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `topicid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `author` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `sourceid` mediumint(8) NOT NULL DEFAULT '0',
  `addtime` int(11) unsigned NOT NULL DEFAULT '0',
  `edittime` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `publtime` int(11) unsigned NOT NULL DEFAULT '0',
  `exptime` int(11) unsigned NOT NULL DEFAULT '0',
  `archive` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `hometext` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `homeimgfile` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgalt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `homeimgthumb` tinyint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `allowed_comm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `allowed_rating` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hitstotal` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `topicid` (`topicid`),
  KEY `admin_id` (`admin_id`),
  KEY `author` (`author`),
  KEY `title` (`title`),
  KEY `addtime` (`addtime`),
  KEY `publtime` (`publtime`),
  KEY `exptime` (`exptime`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=24  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_rows`
--

INSERT INTO `az_vi_news_rows` VALUES
(23, 1, '1', 0, 1, '', 0, 1477450222, 1477450222, 1, 1477450140, 0, 2, 'Kinh nghiệm chọn mua sofa da', 'kinh-nghiem-chon-mua-sofa-da', 'Hiện nay, Sofa da đã trở thành một trong những đồ nội thất phổ biến và được nhiều gia đình lựa chọn, đặc biệt là những gia chủ muốn thể hiện đẳng cấp, sự sang trọng cho ngôi nhà. Nhưng trên thị trường luôn tràn ngập các mẫu mã, thương hiệu, khiến Bạn phải hoa mắt và đau đầu khi lựa chọn. Bạn không phân biệt được Sofa da thật và Sofa giả da? Bạn không biết làm thế nào để đánh giá được chất lượng của một chiếc ghế Sofa? Nên chọn mua Sofa da nhập khẩu hay sử dụng Sofa nội địa? Hãy để Nội thất Nhà Đẹp chia sẻ với Bạn một số kinh nghiệm khi lựa chọn và đánh giá chất lượng một bộ Sofa da.', '2016_10/kennedy_26311r153.jpg', 'KENNEDY 26311R153', 1, 1, '4', 1, 2, 0, 0, 0), 
(22, 1, '1', 0, 1, '', 0, 1477450135, 1477450135, 1, 1477449960, 0, 2, 'Cách bố trí sofa hợp phong thủy', 'cach-bo-tri-sofa-hop-phong-thuy', 'Việc bài trí sofa đúng cách không chỉ mang lại vẻ đẹp thanh thoát cho căn phòng mà còn mang tài vận và may mắn đến cho gia chủ. Trong phòng khách, bộ sofa luôn là tâm điểm thu hút sự chú ý khi bước chân vào không gian này.', '2016_10/up-04.jpg', '', 1, 1, '4', 1, 2, 0, 0, 0), 
(20, 1, '1', 0, 1, '', 0, 1477449577, 1477684146, 1, 1477449420, 0, 2, 'Bí quyết thiết ké nội thất chung cư theo phong cách riêng', 'bi-quyet-thiet-ke-noi-that-chung-cu-theo-phong-cach-rieng', 'Thiết kế nội thất chung cư mang phong cách, dấu ấn riêng của gia đình bạn đòi hỏi sự khéo léo, tinh tế, khéo léo và khoa học, dưới đây là một số bí quyết để thực hiện điều đó mọi người cùng tham khảo:', '2016_10/bi-quyet-thiet-ke-noi-that-chung-cu-dep-3.jpg', 'AZVIET CMS', 1, 1, '4', 1, 2, 0, 0, 0), 
(21, 1, '1', 0, 1, '', 0, 1477449818, 1477684169, 1, 1477449540, 0, 2, 'Xu hướng thiết kế', 'xu-huong-thiet-ke', 'Pha trộn nâu đậm, một chút nâu nhẹ nhàng không hề khiến phòng ngủ trở nên tẻ nhạt, trái lại nó sẽ tạo được phong cách và sự lãng mạn cho không gian yên bình này. Công ty thiết kế nội thất chung cư uy tín - Amore.com.vn xin chia sẻ với bạn đọc một số mẫu thiết kế mọi người cùng tham khảo nhé!', '2016_10/khong_gian_phong_ngu_lang_man_va_phong_cach_voi_gam_mau_nau85.jpg', '', 1, 1, '4', 1, 2, 0, 0, 0);


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_sources`
--

DROP TABLE IF EXISTS `az_vi_news_sources`;
CREATE TABLE `az_vi_news_sources` (
  `sourceid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `logo` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`sourceid`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=5  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_sources`
--

INSERT INTO `az_vi_news_sources` VALUES
(1, 'Báo Hà Nội Mới', 'http://hanoimoi.com.vn', '', 1, 1274989177, 1274989177), 
(2, 'VINADES.,JSC', 'http://vinades.vn', '', 2, 1274989787, 1274989787), 
(3, 'Báo điện tử Dân Trí', 'http://dantri.com.vn', '', 3, 1322685396, 1322685396), 
(4, 'Bộ Thông tin và Truyền thông', 'http://http://mic.gov.vn', '', 4, 1445309676, 1445309676);


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_tags`
--

DROP TABLE IF EXISTS `az_vi_news_tags`;
CREATE TABLE `az_vi_news_tags` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `numnews` mediumint(8) NOT NULL DEFAULT '0',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `keywords` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  PRIMARY KEY (`tid`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=43  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_tags`
--

INSERT INTO `az_vi_news_tags` VALUES
(1, 0, 'nguồn-mở', '', '', 'nguồn mở'), 
(2, 0, 'quen-thuộc', '', '', 'quen thuộc'), 
(3, 0, 'cộng-đồng', '', '', 'cộng đồng'), 
(4, 0, 'việt-nam', '', '', 'việt nam'), 
(5, 0, 'hoạt-động', '', '', 'hoạt động'), 
(6, 0, 'tin-tức', '', '', 'tin tức'), 
(7, 0, 'thương-mại-điện', '', '', 'thương mại điện'), 
(8, 0, 'điện-tử', '', '', 'điện tử'), 
(9, 0, 'nukeviet', '', '', 'nukeviet'), 
(10, 0, 'vinades', '', '', 'vinades'), 
(11, 0, 'lập-trình-viên', '', '', 'lập trình viên'), 
(12, 0, 'chuyên-viên-đồ-họa', '', '', 'chuyên viên đồ họa'), 
(13, 0, 'php', '', '', 'php'), 
(14, 0, 'mysql', '', '', 'mysql'), 
(15, 0, 'nhân-tài-đất-việt-2011', '', '', 'nhân tài đất việt 2011'), 
(16, 0, 'mã-nguồn-mở', '', '', 'mã nguồn mở'), 
(17, 0, 'nukeviet4', '', '', 'nukeviet4'), 
(18, 0, 'mail', '', '', 'mail'), 
(19, 0, 'fpt', '', '', 'fpt'), 
(20, 0, 'smtp', '', '', 'smtp'), 
(21, 0, 'bootstrap', '', '', 'bootstrap'), 
(22, 0, 'block', '', '', 'block'), 
(23, 0, 'modules', '', '', 'modules'), 
(24, 0, 'banner', '', '', 'banner'), 
(25, 0, 'liên-kết', '', '', 'liên kết'), 
(26, 0, 'hosting', '', '', 'hosting'), 
(27, 0, 'hỗ-trợ', '', '', 'hỗ trợ'), 
(28, 0, 'hợp-tác', '', '', 'hợp tác'), 
(29, 0, 'tốc-độ', '', '', 'tốc độ'), 
(30, 0, 'website', '', '', 'website'), 
(31, 0, 'bảo-mật', '', '', 'bảo mật'), 
(32, 0, 'giáo-dục', '', '', 'giáo dục'), 
(33, 0, 'edu-gate', '', '', 'edu gate'), 
(34, 0, 'lập-trình', '', '', 'lập trình'), 
(35, 0, 'logo', '', '', 'logo'), 
(36, 0, 'code', '', '', 'code'), 
(37, 0, 'thực-tập', '', '', 'thực tập'), 
(38, 0, 'kinh-doanh', '', '', 'kinh doanh'), 
(39, 0, 'nhân-viên', '', '', 'nhân viên'), 
(40, 0, 'bộ-gd&đt', '', '', 'Bộ GD&ĐT'), 
(41, 0, 'module', '', '', 'module'), 
(42, 0, 'php-nuke', '', '', 'php-nuke');


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_tags_id`
--

DROP TABLE IF EXISTS `az_vi_news_tags_id`;
CREATE TABLE `az_vi_news_tags_id` (
  `id` int(11) NOT NULL,
  `tid` mediumint(9) NOT NULL,
  `keyword` varchar(65)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `id_tid` (`id`,`tid`),
  KEY `tid` (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_vi_news_topics`
--

DROP TABLE IF EXISTS `az_vi_news_topics`;
CREATE TABLE `az_vi_news_topics` (
  `topicid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `description` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `weight` smallint(5) NOT NULL DEFAULT '0',
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`topicid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_news_topics`
--

INSERT INTO `az_vi_news_topics` VALUES
(1, 'NukeViet 4', 'NukeViet-4', '', 'NukeViet 4', 1, 'NukeViet 4', 1445396011, 1445396011);


-- ---------------------------------------


--
-- Table structure for table `az_vi_page`
--

DROP TABLE IF EXISTS `az_vi_page`;
CREATE TABLE `az_vi_page` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_page`
--

INSERT INTO `az_vi_page` VALUES
(1, 'Xem Phong Thủy', 'Xem-Phong-Thuy', 'nguhanh.jpg', '', 2, 'Màu sắc & Ngũ hành<br /><br />Ngũ hành mạng cũng có nhiều loại, nên khi dùng màu của Mạng trùng với màu của Hành thì phải cân nhắc cẩn thận vì “lưỡng” hành là con dao hai lưỡi, tùy theo mạng mà đôi khi tốt, đôi khi lại xấu. Thí dụ: Lưỡng Kim thành khí, tức là tốt chỉ cho những người mạng kim nguyên thủy chưa chế biến như Hải Trung Kim; Sa Trung Kim; Bạch Lạp Kim. Các mạng Kim khác thì lại hóa ra “lưỡng kim, kim khuyết” tức là hai kim khí chạm nhau có thể gây sức mẻ, hư hại cho nhau. Cho nên nếu không biết chắc chắn thì tránh mặc, đeo, mang những màu cùng Mạng của mình.', '<p><strong>Mộc</strong><br  /> Mạng Mộc nên dùng màu xanh nước biển, đen, tím xanh.<br  /> “Lưỡng mộc thành lâm”, nhiều cây thành rừng nên mạng Mộc rất hợp với màu xanh lá cây, trang sức như gỗ hóa thạch. Tránh trường hợp những Mạng hợp cùng màu của Hành sinh ra “lưỡng mộc, mộc chiết” tức là bị đổ gãy, giống như con đường công danh, sự nghiệp bị chặt đứt đôi vậy!<br  /> Mộc chế khắc được Thổ nên có thể dùng màu nâu, vàng đậm.<br  /> Không nên dùng màu của Kim như vàng tươi, trắng và bạc, ví như cây bị cưa, búa, rìu chặc thành khúc vậy.</p>  <p><strong>Hỏa</strong><br  /> Người mạng Hỏa nên dùng màu tương sinh, hành Mộc tức là xanh lá cây.<br  /> Có thể dùng màu tương hợp đỏ, hồng, cam nhưng phải cẩn thận, “lưỡng hỏa thành viên” tức là trở thành trọn vẹn, đầy đủ, thành tựu. Nhưng quá nhiều năng lượng thì hóa ra nóng nảy, dễ gây stress, nóng tánh, lên máu, sinh mụn nhọt, lở loét, đau bao tử. Ngoài ra nên đề phòng mạng Hỏa hợp màu hành Hỏa sinh ra “lưỡng hỏa, hỏa diệt” tức bị tàn lụi, thất bại, diệt vong.<br  /> Cũng có thể dùng màu mạng Kim như vàng, trắng vì chỉ có lửa mới khống chế, nấu chảy được kim thành chất loảng mà thôi. Những màu Kim rất thích hợp cho những người mạng Hỏa thường hay bị stress.<br  /> Không nên dùng màu đen, xanh nước biển, tím-xanh (màu tím nghiêng về xanh, màu tím lạnh, là màu hành thủy).</p>  <p><strong>Thổ</strong><br  /> Mạng Thổ nên dùng màu đỏ, hồng, cam<br  /> Có thể dùng màu của hành Thổ tức là màu nâu đậm thì rất tốt vì “lưỡng thổ thành sơn” tức là thành núi, giúp địa vị được vững chắc, bảo vệ tiền tài không bị thất thoát. Nhưng cũng phải đề phòng Mạng hợp với màu hành Thổ hóa ra “lưỡng thổ, thổ kiệt” đất bị khô cằn, thể chất kiệt huệ.<br  /> Nên tránh màu hành Thủy: đen, xanh nước biển và tím xanh. Kỵ nhứt là màu xanh lá cây, cây rút chất bổ từ đất mà sống, người mạng Thổ dùng màu hành Mộc tức ngày càng suy yếu về sức khỏe, thể lực cũng như tiền tài, vật chất.</p>  <p><strong>Kim</strong><br  /> Mạng Kim tốt nhứt nên dùng màu vàng đậm đến nâu, trang sức đeo đá như gỗ hóa thạch, nâu đậm như ngọc mắt cọp. Có thể đeo đá màu trắng như hột xoàn, đá màu bạc hoặc vàng tươi, trân châu hột bẹt vì “lưỡng kim thành khí” tức là thành đồ dùng, khí cụ trở thành vật trợ giúp cho người mạng Kim đạt nhiều mục đích hữu ích, người sang càng sang thêm, người tài phát huy được tài của mình, như rồng thêm cánh vậy. Đề phòng trường hợp “lưỡng kim, kim khuyết” như thí dụ ở trên.<br  /> Nên tránh màu xanh lá cây vì chúng không đem lại lợi ích gì.<br  /> Kiêng kỵ những màu hành Hỏa như đỏ, hồng, cam.</p>  <p><strong>Thủy</strong><br  /> Mạng Thủy tốt nhứt dùng màu bạc, trắng.<br  /> Có thể dùng màu đen, xanh nước biển, tím xanh vì “lưỡng Thủy thành Giang” tức là dòng sông, giúp người mạng Thủy bành trướng, nhân gấp nhiều lần những gì tốt đẹp người đó đang có về vật chất cũng như tinh thần. Cũng tùy theo Mạng thuộc loại “Thủy” gì, nên tránh trường hợp Mạng và màu của Hành hợp lại thành “lưỡng thủy, thủy kiệt” tức là nước cạn, sạch hết nước, vào con đường không lối thoát ví như đánh cờ “hết nước” để đi.<br  /> Thủy có thể chế khắc được Hỏa nên cũng có thể dùng đá màu đỏ, hồng, cam.<br  /> Kỵ màu vàng đậm, nâu, bởi vì đất (đê) có thể trấn áp, chận được nước, nước chảy không suông, mọi sự bế tắc ( màu tím nghiêng về đỏ hồng, màu tím ấm, là màu hành hỏa).</p>  <h3>&nbsp;</h3>', '', 1, '6', '', 0, 1, 1, 1476968834, 1477845808, 1), 
(2, 'Bảng giá', 'Bang-gia', '', '', 0, '', 'Nội dung đang được cập nhập', '', 1, '4', '', 0, 2, 1, 1476968847, 1476968847, 1);


-- ---------------------------------------


--
-- Table structure for table `az_vi_page_config`
--

DROP TABLE IF EXISTS `az_vi_page_config`;
CREATE TABLE `az_vi_page_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_page_config`
--

INSERT INTO `az_vi_page_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '5'), 
('news_first', '1'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `az_vi_photos_album`
--

DROP TABLE IF EXISTS `az_vi_photos_album`;
CREATE TABLE `az_vi_photos_album` (
  `album_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_keyword` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `model` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `capturedate` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `capturelocal` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `folder` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `layout` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `num_photo` mediumint(3) unsigned NOT NULL DEFAULT '0',
  `viewed` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `weight` int(11) unsigned NOT NULL DEFAULT '0',
  `allow_rating` int(11) unsigned NOT NULL DEFAULT '1',
  `total_rating` int(11) NOT NULL DEFAULT '0',
  `click_rating` int(11) NOT NULL DEFAULT '0',
  `favorite` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `groups_view` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `author` int(11) unsigned NOT NULL DEFAULT '0',
  `author_modify` int(11) unsigned NOT NULL DEFAULT '0',
  `allow_comment` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `hitscm` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `date_modified` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`album_id`),
  KEY `category_id` (`category_id`),
  KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_photos_album`
--

INSERT INTO `az_vi_photos_album` VALUES
(1, 1, 'Caffe Hoàng Long', 'caffe-hoang-long', '', '', '', '', '', 'Thiết kế kiến trúc và nội thất', '01/01/1970', 'Q. Cầu Giấy, Hà Nội', '2016/10/caffe-hoang-long', '', 8, 7, 0, 1, 0, 0, 0, 1, '6', 1, 1, '6', 0, 1475297383, 1475297383), 
(2, 7, 'London College Design School', 'london-college-design-school', '', '', '', '', '', '', '01/01/1970', 'Tây Hồ, Hà Nội', '2016/10/london-college-design-school', '', 11, 7, 0, 1, 0, 0, 0, 1, '6', 1, 1, '6', 0, 1475357892, 1475357892), 
(3, 7, 'Horizon School', 'horizon-school', '', '', '', '', '', '', '', '98 Tô Ngọc Vân, Q Ba Đình, HN', '2016/10/horizon-school', '', 5, 4, 0, 1, 0, 0, 0, 1, '6', 1, 1, '6', 0, 1475358126, 1475358126), 
(4, 2, 'Nguyễn Huy Thắng', 'nguyen-huy-thang', '', '', '', '', '', '', '01/01/1970', 'Ngõ 25, Trương Định, HN', '2016/10/nguyen-huy-thang', '', 5, 7, 0, 1, 0, 0, 0, 1, '6', 1, 1, '6', 0, 1475358245, 1475358245), 
(5, 2, 'Vũ Sĩ Lợi', 'vu-si-loi', '', '', '', '', '', '', '01/01/1970', 'Phố Huế, HBT, HN', '2016/10/vu-si-loi', '', 5, 3, 0, 1, 0, 0, 0, 1, '6', 1, 1, '6', 0, 1476446094, 1476446094), 
(6, 1, 'Đàm Mai Lâm', 'dam-mai-lam', '', '', '', '', '', 'Thiết kế và thi công nội thất', '01/01/1970', 'Vinhomes Riverside, Long Biên, HN', '2016/10/dam-mai-lam', '', 7, 2, 0, 1, 0, 0, 0, 1, '6', 1, 1, '6', 0, 1477049122, 1477049122), 
(7, 2, 'Trần Thanh Sang', 'tran-thanh-sang', '', '', '', '', '', 'Thiết kế và thi công nội thất', '01/01/1970', 'Số 53, Ngõ 45, phố Phùng Khoang, Thanh Xuân, HN', '2016/10/tran-thanh-sang', '', 4, 1, 0, 1, 0, 0, 0, 1, '6', 1, 1, '6', 0, 1477049450, 1477049450), 
(8, 3, 'Nguyễn Thanh Phong', 'nguyen-thanh-phong', '', '', '', '', '', 'Thiết kế thi công trọn gói', '31/12/1969', '129D Trương Định, HBT, HN', '2016/10/nguyen-thanh-phong', '', 6, 3, 0, 1, 0, 0, 0, 1, '6', 1, 1, '6', 0, 1477049636, 1477049636);


-- ---------------------------------------


--
-- Table structure for table `az_vi_photos_category`
--

DROP TABLE IF EXISTS `az_vi_photos_category`;
CREATE TABLE `az_vi_photos_category` (
  `category_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `meta_title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_description` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_keyword` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sort_order` smallint(5) NOT NULL DEFAULT '0',
  `lev` smallint(5) NOT NULL DEFAULT '0',
  `layout` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `viewcat` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'viewcat_page_new',
  `numsubcat` smallint(5) NOT NULL DEFAULT '0',
  `subcatid` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `num_album` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(250)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `date_modified` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `alias` (`alias`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=9  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_photos_category`
--

INSERT INTO `az_vi_photos_category` VALUES
(1, 0, 'Biệt thự', 'biet-thu', '', '', '', '', 1, 1, 0, '', 'viewcat_grid', 0, '', 1, 1, 4, 2, '6', 1475297294, 1475297294), 
(2, 0, 'Nhà phố', 'nha-pho', '', '', '', '', 3, 3, 0, '', 'viewcat_grid', 0, '', 1, 1, 4, 3, '6', 1475297308, 1475297308), 
(3, 0, 'Căn hộ, penthouse', 'can-ho-penthouse', '', '', '', '', 4, 4, 0, '', 'viewcat_grid', 0, '', 1, 1, 4, 1, '6', 1475357457, 1475357457), 
(4, 0, 'Khách sạn, resort', 'khach-san-resort', '', '', '', '', 5, 5, 0, '', 'viewcat_grid', 0, '', 1, 1, 4, 0, '6', 1475357473, 1475357473), 
(5, 0, 'Bar, cafe, nhà hàng, karaoke', 'bar-cafe-nha-hang-karaoke', '', '', '', '', 6, 6, 0, '', 'viewcat_grid', 0, '', 1, 1, 4, 0, '6', 1475357489, 1475357489), 
(6, 0, 'Spa, beauty salon', 'spa-beauty-salon', '', '', '', '', 7, 7, 0, '', 'viewcat_grid', 0, '', 1, 1, 4, 0, '6', 1475357502, 1475357502), 
(7, 0, 'Showroom, shop, building, office', 'showroom-shop-building-office', '', '', '', '', 8, 8, 0, '', 'viewcat_grid', 0, '', 1, 1, 4, 2, '6', 1475357516, 1475357516), 
(8, 0, 'Showroom, shop, building, office', 'showroom-shop-building-office-8', '', '', '', '', 2, 2, 0, '', 'viewcat_grid', 0, '', 1, 1, 4, 0, '6', 1475357535, 1475357535);


-- ---------------------------------------


--
-- Table structure for table `az_vi_photos_rows`
--

DROP TABLE IF EXISTS `az_vi_photos_rows`;
CREATE TABLE `az_vi_photos_rows` (
  `row_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `defaults` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `size` int(11) unsigned NOT NULL DEFAULT '0',
  `width` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `height` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `mime` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `file` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumb` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `favorite` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `viewed` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  `date_modified` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`row_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=202  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_photos_rows`
--

INSERT INTO `az_vi_photos_rows` VALUES
(200, 1, '7-3.jpg', '', 0, 250139, 1200, 415, 'image/jpeg', '2016/10/caffe-hoang-long/7-3.jpg', '/2016/10/90x72-7-3_1.jpg', 0, 1, 0, 1477483847, 1477483847), 
(201, 1, '8-5.jpg', '', 0, 334553, 1200, 740, 'image/jpeg', '2016/10/caffe-hoang-long/8-5.jpg', '/2016/10/90x72-8-5_1.jpg', 0, 1, 0, 1477483847, 1477483847), 
(194, 1, '1-6.jpg', '', 0, 238048, 1200, 401, 'image/jpeg', '2016/10/caffe-hoang-long/1-6.jpg', '/2016/10/90x72-1-6_2.jpg', 0, 1, 0, 1477483847, 1477483847), 
(195, 1, '2-2.jpg', '', 1, 349774, 1200, 740, 'image/jpeg', '2016/10/caffe-hoang-long/2-2.jpg', '/2016/10/90x72-2-2_1.jpg', 0, 1, 0, 1477483847, 1477483847), 
(196, 1, '3-2.jpg', '', 0, 225625, 1200, 402, 'image/jpeg', '2016/10/caffe-hoang-long/3-2.jpg', '/2016/10/90x72-3-2_1.jpg', 0, 1, 0, 1477483847, 1477483847), 
(197, 1, '4-7.jpg', '', 0, 342800, 1200, 681, 'image/jpeg', '2016/10/caffe-hoang-long/4-7.jpg', '/2016/10/90x72-4-7_2.jpg', 0, 1, 0, 1477483847, 1477483847), 
(198, 1, '5-6.jpg', '', 0, 243864, 1200, 404, 'image/jpeg', '2016/10/caffe-hoang-long/5-6.jpg', '/2016/10/90x72-5-6_2.jpg', 0, 1, 0, 1477483847, 1477483847), 
(199, 1, '6-2.jpg', '', 0, 383459, 1200, 697, 'image/jpeg', '2016/10/caffe-hoang-long/6-2.jpg', '/2016/10/90x72-6-2_1.jpg', 0, 1, 0, 1477483847, 1477483847), 
(193, 2, '11-2.jpg', '', 0, 342139, 1500, 811, 'image/jpeg', '2016/10/london-college-design-school/11-2.jpg', '/2016/10/90x72-11-2.jpg', 0, 1, 0, 1477482975, 1477482975), 
(192, 2, '10-2.jpg', '', 0, 391922, 1500, 811, 'image/jpeg', '2016/10/london-college-design-school/10-2.jpg', '/2016/10/90x72-10-2.jpg', 0, 1, 0, 1477482975, 1477482975), 
(191, 2, '9-2.jpg', '', 0, 356754, 1500, 761, 'image/jpeg', '2016/10/london-college-design-school/9-2.jpg', '/2016/10/90x72-9-2.jpg', 0, 1, 0, 1477482975, 1477482975), 
(190, 2, '8-5.jpg', '', 0, 421275, 1500, 811, 'image/jpeg', '2016/10/london-college-design-school/8-5.jpg', '/2016/10/90x72-8-5.jpg', 0, 1, 0, 1477482975, 1477482975), 
(189, 2, '7-3.jpg', '', 0, 448728, 1500, 811, 'image/jpeg', '2016/10/london-college-design-school/7-3.jpg', '/2016/10/90x72-7-3.jpg', 0, 1, 0, 1477482975, 1477482975), 
(188, 2, '6-2.jpg', '', 0, 383361, 1500, 806, 'image/jpeg', '2016/10/london-college-design-school/6-2.jpg', '/2016/10/90x72-6-2.jpg', 0, 1, 0, 1477482975, 1477482975), 
(187, 2, '5-6.jpg', '', 0, 386424, 1500, 812, 'image/jpeg', '2016/10/london-college-design-school/5-6.jpg', '/2016/10/90x72-5-6_1.jpg', 0, 1, 0, 1477482975, 1477482975), 
(186, 2, '4-7.jpg', '', 0, 385745, 1500, 816, 'image/jpeg', '2016/10/london-college-design-school/4-7.jpg', '/2016/10/90x72-4-7_1.jpg', 0, 1, 0, 1477482975, 1477482975), 
(185, 2, '3-2.jpg', '', 1, 324691, 1500, 810, 'image/jpeg', '2016/10/london-college-design-school/3-2.jpg', '/2016/10/90x72-3-2.jpg', 0, 1, 0, 1477482975, 1477482975), 
(184, 2, '1-6.jpg', '', 0, 178875, 1500, 498, 'image/jpeg', '2016/10/london-college-design-school/1-6.jpg', '/2016/10/90x72-1-6_1.jpg', 0, 1, 0, 1477482975, 1477482975), 
(183, 2, '0-2.jpg', '', 0, 411999, 1500, 810, 'image/jpeg', '2016/10/london-college-design-school/0-2.jpg', '/2016/10/90x72-0-2.jpg', 0, 1, 0, 1477482975, 1477482975), 
(144, 3, '1-8.jpg', '', 0, 302007, 1500, 750, 'image/jpeg', '2016/10/horizon-school/1-8.jpg', '/2016/10/90x72-1-8.jpg', 0, 1, 0, 1477420047, 1477420047), 
(145, 3, '2-8.jpg', '', 1, 303718, 1500, 750, 'image/jpeg', '2016/10/horizon-school/2-8.jpg', '/2016/10/90x72-2-8.jpg', 0, 1, 0, 1477420047, 1477420047), 
(146, 3, '3-8.jpg', '', 0, 404271, 1500, 875, 'image/jpeg', '2016/10/horizon-school/3-8.jpg', '/2016/10/90x72-3-8.jpg', 0, 1, 0, 1477420047, 1477420047), 
(147, 3, '4-8.jpg', '', 0, 424129, 1500, 945, 'image/jpeg', '2016/10/horizon-school/4-8.jpg', '/2016/10/90x72-4-8.jpg', 0, 1, 0, 1477420047, 1477420047), 
(148, 3, '5-8.jpg', '', 0, 409445, 1500, 845, 'image/jpeg', '2016/10/horizon-school/5-8.jpg', '/2016/10/90x72-5-8.jpg', 0, 1, 0, 1477420047, 1477420047), 
(139, 4, '1-7.jpg', '', 1, 260859, 1500, 898, 'image/jpeg', '2016/10/nguyen-huy-thang/1-7.jpg', '/2016/10/90x72-1-7.jpg', 0, 1, 0, 1477419410, 1477419410), 
(140, 4, '2-7.png', '', 0, 2529902, 1500, 1016, 'image/png', '2016/10/nguyen-huy-thang/2-7.png', '/2016/10/90x72-2-7.png', 0, 1, 0, 1477419410, 1477419410), 
(141, 4, '3-7.png', '', 0, 1809830, 1500, 694, 'image/png', '2016/10/nguyen-huy-thang/3-7.png', '/2016/10/90x72-3-7.png', 0, 1, 0, 1477419410, 1477419410), 
(142, 4, '4-7.jpg', '', 0, 286540, 1500, 889, 'image/jpeg', '2016/10/nguyen-huy-thang/4-7.jpg', '/2016/10/90x72-4-7.jpg', 0, 1, 0, 1477419410, 1477419410), 
(143, 4, '5-7.jpg', '', 0, 249365, 1500, 944, 'image/jpeg', '2016/10/nguyen-huy-thang/5-7.jpg', '/2016/10/90x72-5-7.jpg', 0, 1, 0, 1477419410, 1477419410), 
(134, 5, '1-6.jpg', '', 1, 308924, 1500, 767, 'image/jpeg', '2016/10/vu-si-loi/1-6.jpg', '/2016/10/90x72-1-6.jpg', 0, 1, 0, 1477418193, 1477418193), 
(135, 5, '2-6.jpg', '', 0, 461717, 1500, 1000, 'image/jpeg', '2016/10/vu-si-loi/2-6.jpg', '/2016/10/90x72-2-6.jpg', 0, 1, 0, 1477418193, 1477418193), 
(136, 5, '3-6.jpg', '', 0, 432102, 1500, 1000, 'image/jpeg', '2016/10/vu-si-loi/3-6.jpg', '/2016/10/90x72-3-6.jpg', 0, 1, 0, 1477418193, 1477418193), 
(137, 5, '4-6.jpg', '', 0, 552301, 1500, 1302, 'image/jpeg', '2016/10/vu-si-loi/4-6.jpg', '/2016/10/90x72-4-6.jpg', 0, 1, 0, 1477418193, 1477418193), 
(138, 5, '5-6.jpg', '', 0, 513180, 1500, 1302, 'image/jpeg', '2016/10/vu-si-loi/5-6.jpg', '/2016/10/90x72-5-6.jpg', 0, 1, 0, 1477418193, 1477418193), 
(132, 6, '1-5-1.jpg', '', 0, 388097, 1500, 897, 'image/jpeg', '2016/10/dam-mai-lam/1-5-1.jpg', '/2016/10/90x72-1-5-1.jpg', 0, 1, 0, 1477416473, 1477416473), 
(131, 6, '7-5-1.jpg', '', 0, 348432, 1500, 899, 'image/jpeg', '2016/10/dam-mai-lam/7-5-1.jpg', '/2016/10/90x72-7-5-1.jpg', 0, 1, 0, 1477416473, 1477416473), 
(130, 6, '6-5-1.jpg', '', 0, 412864, 1500, 966, 'image/jpeg', '2016/10/dam-mai-lam/6-5-1.jpg', '/2016/10/90x72-6-5-1.jpg', 0, 1, 0, 1477416473, 1477416473), 
(126, 6, '2-5-1.jpg', '', 0, 354450, 1500, 901, 'image/jpeg', '2016/10/dam-mai-lam/2-5-1.jpg', '/2016/10/90x72-2-5-1.jpg', 0, 1, 0, 1477416473, 1477416473), 
(127, 6, '3-5-1.jpg', '', 1, 432573, 1500, 896, 'image/jpeg', '2016/10/dam-mai-lam/3-5-1.jpg', '/2016/10/90x72-3-5-1.jpg', 0, 1, 0, 1477416473, 1477416473), 
(128, 6, '4-5-1.jpg', '', 0, 398197, 1500, 896, 'image/jpeg', '2016/10/dam-mai-lam/4-5-1.jpg', '/2016/10/90x72-4-5-1.jpg', 0, 1, 0, 1477416473, 1477416473), 
(129, 6, '5-5-1.jpg', '', 0, 413127, 1500, 899, 'image/jpeg', '2016/10/dam-mai-lam/5-5-1.jpg', '/2016/10/90x72-5-5-1.jpg', 0, 1, 0, 1477416473, 1477416473), 
(101, 7, '1-4-2.jpg', '', 1, 292937, 1500, 884, 'image/jpeg', '2016/10/tran-thanh-sang/1-4-2.jpg', '/2016/10/90x72-1-4-2.jpg', 0, 1, 0, 1477409843, 1477409843), 
(102, 7, '2-4-2.jpg', '', 0, 270439, 1500, 847, 'image/jpeg', '2016/10/tran-thanh-sang/2-4-2.jpg', '/2016/10/90x72-2-4-2.jpg', 0, 1, 0, 1477409843, 1477409843), 
(103, 7, '3-4-2.jpg', '', 0, 459654, 1500, 958, 'image/jpeg', '2016/10/tran-thanh-sang/3-4-2.jpg', '/2016/10/90x72-3-4-2.jpg', 0, 1, 0, 1477409843, 1477409843), 
(104, 7, '4-4-2.jpg', '', 0, 312670, 1500, 960, 'image/jpeg', '2016/10/tran-thanh-sang/4-4-2.jpg', '/2016/10/90x72-4-4-2.jpg', 0, 1, 0, 1477409843, 1477409843), 
(100, 8, '1-2.jpg', '', 0, 350497, 1500, 899, 'image/jpeg', '2016/10/nguyen-thanh-phong/1-2.jpg', '/2016/10/90x72-1-2.jpg', 0, 1, 0, 1477408088, 1477725173), 
(95, 8, '2-2.jpg', '', 0, 353763, 1500, 899, 'image/jpeg', '2016/10/nguyen-thanh-phong/2-2.jpg', '/2016/10/90x72-2-2.jpg', 0, 1, 0, 1477408088, 1477725173), 
(96, 8, '4-3.jpg', '', 0, 278097, 1500, 877, 'image/jpeg', '2016/10/nguyen-thanh-phong/4-3.jpg', '/2016/10/90x72-4-3.jpg', 0, 1, 0, 1477408088, 1477725173), 
(97, 8, '5-3.jpg', '', 1, 325126, 1500, 889, 'image/jpeg', '2016/10/nguyen-thanh-phong/5-3.jpg', '/2016/10/90x72-5-3.jpg', 0, 1, 0, 1477408088, 1477725173), 
(98, 8, '7-1.jpg', '', 0, 294030, 1500, 889, 'image/jpeg', '2016/10/nguyen-thanh-phong/7-1.jpg', '/2016/10/90x72-7-1.jpg', 0, 1, 0, 1477408088, 1477725173), 
(99, 8, '8-3.jpg', '', 0, 382480, 1500, 1234, 'image/jpeg', '2016/10/nguyen-thanh-phong/8-3.jpg', '/2016/10/90x72-8-3.jpg', 0, 1, 0, 1477408088, 1477725173);


-- ---------------------------------------


--
-- Table structure for table `az_vi_referer_stats`
--

DROP TABLE IF EXISTS `az_vi_referer_stats`;
CREATE TABLE `az_vi_referer_stats` (
  `host` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `month01` int(11) NOT NULL DEFAULT '0',
  `month02` int(11) NOT NULL DEFAULT '0',
  `month03` int(11) NOT NULL DEFAULT '0',
  `month04` int(11) NOT NULL DEFAULT '0',
  `month05` int(11) NOT NULL DEFAULT '0',
  `month06` int(11) NOT NULL DEFAULT '0',
  `month07` int(11) NOT NULL DEFAULT '0',
  `month08` int(11) NOT NULL DEFAULT '0',
  `month09` int(11) NOT NULL DEFAULT '0',
  `month10` int(11) NOT NULL DEFAULT '0',
  `month11` int(11) NOT NULL DEFAULT '0',
  `month12` int(11) NOT NULL DEFAULT '0',
  `last_update` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `host` (`host`),
  KEY `total` (`total`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_referer_stats`
--

INSERT INTO `az_vi_referer_stats` VALUES
('facebook.com', 21, 0, 0, 0, 0, 0, 0, 0, 0, 0, 15, 6, 0, 1479429284), 
('m.facebook.com', 34, 0, 0, 0, 0, 0, 0, 0, 0, 0, 6, 28, 0, 1480050917), 
('google.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1477058883), 
('l.facebook.com', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1477388238), 
('azvietco.com', 3, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1486670194);


-- ---------------------------------------


--
-- Table structure for table `az_vi_searchkeys`
--

DROP TABLE IF EXISTS `az_vi_searchkeys`;
CREATE TABLE `az_vi_searchkeys` (
  `id` varchar(32)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `skey` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `total` int(11) NOT NULL DEFAULT '0',
  `search_engine` varchar(50)  COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `id` (`id`),
  KEY `skey` (`skey`),
  KEY `search_engine` (`search_engine`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_vi_siteterms`
--

DROP TABLE IF EXISTS `az_vi_siteterms`;
CREATE TABLE `az_vi_siteterms` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imagealt` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `imageposition` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `description` text  COLLATE utf8mb4_unicode_ci,
  `bodytext` mediumtext  COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` text  COLLATE utf8mb4_unicode_ci,
  `socialbutton` tinyint(4) NOT NULL DEFAULT '0',
  `activecomm` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `layout_func` varchar(100)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `gid` mediumint(9) NOT NULL DEFAULT '0',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `add_time` int(11) NOT NULL DEFAULT '0',
  `edit_time` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM  AUTO_INCREMENT=3  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_siteterms`
--

INSERT INTO `az_vi_siteterms` VALUES
(1, 'Chính sách bảo mật (Quyền riêng tư)', 'privacy', '', '', 0, 'Tài liệu này cung cấp cho bạn (người truy cập và sử dụng website) chính sách liên quan đến bảo mật và quyền riêng tư của bạn', '<strong><a id=\"index\" name=\"index\"></a>Danh mục</strong><br /> <a href=\"#1\">Điều 1: Thu thập thông tin</a><br /> <a href=\"#2\">Điều 2: Lưu trữ &amp; Bảo vệ thông tin</a><br /> <a href=\"#3\">Điều 3: Sử dụng thông tin </a><br /> <a href=\"#4\">Điều 4: Tiếp nhận thông tin từ các đối tác </a><br /> <a href=\"#5\">Điều 5: Chia sẻ thông tin với bên thứ ba</a><br /> <a href=\"#6\">Điều 6: Thay đổi chính sách bảo mật</a>  <hr  /> <h2 style=\"text-align: justify;\"><a id=\"1\" name=\"1\"></a>Điều 1: Thu thập thông tin</h2>  <h3 style=\"text-align: justify;\">1.1. Thu thập tự động:</h3>  <div style=\"text-align: justify;\">Hệ thống này được xây dựng bằng mã nguồn NukeViet. Như mọi website hiện đại khác, chúng tôi sẽ thu thập địa chỉ IP và các thông tin web tiêu chuẩn khác của bạn như: loại trình duyệt, các trang bạn truy cập trong quá trình sử dụng dịch vụ, thông tin về máy tính &amp; thiết bị mạng v.v… cho mục đích phân tích thông tin phục vụ việc bảo mật và giữ an toàn cho hệ thống.</div>  <h3 style=\"text-align: justify;\">1.2. Thu thập từ các khai báo của chính bạn:</h3>  <div style=\"text-align: justify;\">Các thông tin do bạn khai báo cho chúng tôi trong quá trình làm việc như: đăng ký tài khoản, liên hệ với chúng tôi... cũng sẽ được chúng tôi lưu trữ phục vụ công việc chăm sóc khách hàng sau này.</div>  <h3 style=\"text-align: justify;\">1.3. Thu thập thông tin thông qua việc đặt cookies:</h3>  <p style=\"text-align: justify;\">Như mọi website hiện đại khác, khi bạn truy cập website, chúng tôi (hoặc các công cụ theo dõi hoặc thống kê hoạt động của website do các đối tác cung cấp) sẽ đặt một số File dữ liệu gọi là Cookies lên đĩa cứng hoặc bộ nhớ máy tính của bạn.</p>  <p style=\"text-align: justify;\">Một trong số những Cookies này có thể tồn tại lâu để thuận tiện cho bạn trong quá trình sử dụng, ví dụ như: lưu Email của bạn trong trang đăng nhập để bạn không phải nhập lại v.v…</p>  <h3 style=\"text-align: justify;\">1.4. Thu thập và lưu trữ thông tin trong quá khứ:</h3>  <p style=\"text-align: justify;\">Bạn có thể thay đổi thông tin cá nhân của mình bất kỳ lúc nào bằng cách sử dụng chức năng tương ứng. Tuy nhiên chúng tôi sẽ lưu lại những thông tin bị thay đổi để chống các hành vi xóa dấu vết gian lận.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2 style=\"text-align: justify;\"><a id=\"2\" name=\"2\"></a>Điều 2: Lưu trữ &amp; Bảo vệ thông tin</h2>  <div style=\"text-align: justify;\">Hầu hết các thông tin được thu thập sẽ được lưu trữ tại cơ sở dữ liệu của chúng tôi.<br /> <br /> Chúng tôi bảo vệ dữ liệu cá nhân của các bạn bằng các hình thức như: mật khẩu, tường lửa, mã hóa cùng các hình thức thích hợp khác và chỉ cấp phép việc truy cập và xử lý dữ liệu cho các đối tượng phù hợp, ví dụ chính bạn hoặc các nhân viên có trách nhiệm xử thông tin với bạn thông qua các bước xác định danh tính phù hợp.<br /> <br /> Mật khẩu của bạn được lưu trữ và bảo vệ bằng phương pháp mã hoá trong cơ sở dữ liệu của hệ thống, vì thế nó rất an toàn. Tuy nhiên, chúng tôi khuyên bạn không nên dùng lại mật khẩu này trên các website khác. Mật khẩu của bạn là cách duy nhất để bạn đăng nhập vào tài khoản thành viên của mình trong website này, vì thế hãy cất giữ nó cẩn thận. Trong mọi trường hợp bạn không nên cung cấp thông tin mật khẩu cho bất kỳ người nào dù là người của chúng tôi, người của NukeViet hay bất kỳ người thứ ba nào khác trừ khi bạn hiểu rõ các rủi ro khi để lộ mật khẩu. Nếu quên mật khẩu, bạn có thể sử dụng chức năng “<a href=\"/users/lostpass/\">Quên mật khẩu</a>” trên website. Để thực hiện việc này, bạn cần phải cung cấp cho hệ thống biết tên thành viên hoặc địa chỉ Email đang sử dụng của mình trong tài khoản, sau đó hệ thống sẽ tạo ra cho bạn mật khẩu mới và gửi đến cho bạn để bạn vẫn có thể đăng nhập vào tài khoản thành viên của mình.  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p> </div>  <h2 style=\"text-align: justify;\"><a id=\"3\" name=\"3\"></a>Điều 3: Sử dụng thông tin</h2>  <p style=\"text-align: justify;\">Thông tin thu thập được sẽ được chúng tôi sử dụng để:</p>  <div style=\"text-align: justify;\">- Cung cấp các dịch vụ hỗ trợ &amp; chăm sóc khách hàng.</div>  <div style=\"text-align: justify;\">- Thực hiện giao dịch thanh toán &amp; gửi các thông báo trong quá trình giao dịch.</div>  <div style=\"text-align: justify;\">- Xử lý khiếu nại, thu phí &amp; giải quyết sự cố.</div>  <div style=\"text-align: justify;\">- Ngăn chặn các hành vi có nguy cơ rủi ro, bị cấm hoặc bất hợp pháp và đảm bảo tuân thủ đúng chính sách “Thỏa thuận người dùng”.</div>  <div style=\"text-align: justify;\">- Đo đạc, tùy biến &amp; cải tiến dịch vụ, nội dung và hình thức của website.</div>  <div style=\"text-align: justify;\">- Gửi bạn các thông tin về chương trình Marketing, các thông báo &amp; chương trình khuyến mại.</div>  <div style=\"text-align: justify;\">- So sánh độ chính xác của thông tin cá nhân của bạn trong quá trình kiểm tra với bên thứ ba.</div>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2 style=\"text-align: justify;\"><a id=\"4\" name=\"4\"></a>Điều 4: Tiếp nhận thông tin từ các đối tác</h2>  <div style=\"text-align: justify;\">Khi sử dụng các công cụ giao dịch và thanh toán thông qua internet, chúng tôi có thể tiếp nhận thêm các thông tin về bạn như địa chỉ username, Email, số tài khoản ngân hàng... Chúng tôi kiểm tra những thông tin này với cơ sở dữ liệu người dùng của mình nhằm xác nhận rằng bạn có phải là khách hàng của chúng tôi hay không nhằm giúp việc thực hiện các dịch vụ cho bạn được thuận lợi.<br /> <br /> Các thông tin tiếp nhận được sẽ được chúng tôi bảo mật như những thông tin mà chúng tôi thu thập được trực tiếp từ bạn.</div>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"5\" name=\"5\"></a>Điều 5: Chia sẻ thông tin với bên thứ ba</h2>  <p style=\"text-align: justify;\">Chúng tôi sẽ không chia sẻ thông tin cá nhân, thông tin tài chính... của bạn cho các bên thứ 3 trừ khi được sự đồng ý của chính bạn hoặc khi chúng tôi buộc phải tuân thủ theo các quy định pháp luật hoặc khi có yêu cầu từ cơ quan công quyền có thẩm quyền.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2><a id=\"6\" name=\"6\"></a>Điều 6: Thay đổi chính sách bảo mật</h2>  <p style=\"text-align: justify;\">Chính sách Bảo mật này có thể thay đổi theo thời gian. Chúng tôi sẽ không giảm quyền của bạn theo Chính sách Bảo mật này mà không có sự đồng ý rõ ràng của bạn. Chúng tôi sẽ đăng bất kỳ thay đổi Chính sách Bảo mật nào trên trang này và, nếu những thay đổi này quan trọng, chúng tôi sẽ cung cấp thông báo nổi bật hơn (bao gồm, đối với một số dịch vụ nhất định, thông báo bằng email về các thay đổi của Chính sách Bảo mật).</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <p style=\"text-align: right;\">Chính sách bảo mật mặc định này được xây dựng cho <a href=\"http://nukeviet.vn\" target=\"_blank\">NukeViet CMS</a>, được tham khảo từ website <a href=\"http://webnhanh.vn/vi/thiet-ke-web/detail/Chinh-sach-bao-mat-Quyen-rieng-tu-Privacy-Policy-2147/\">webnhanh.vn</a></p>', '', 0, '4', '', 0, 1, 1, 1475277519, 1475277519, 1), 
(2, 'Điều khoản và điều kiện sử dụng', 'terms-and-conditions', '', '', 0, 'Đây là các điều khoản và điều kiện áp dụng cho website này. Truy cập và sử dụng website tức là bạn đã đồng ý với các quy định này.', '<div style=\"text-align: justify;\">Cảm ơn bạn đã sử dụng. Xin vui lòng đọc các Điều khoản một cách cẩn thận, và <a href=\"/contact/\">liên hệ</a> với chúng tôi nếu bạn có bất kỳ câu hỏi. Bằng việc truy cập hoặc sử dụng website của chúng tôi, bạn đồng ý bị ràng buộc bởi các <a href=\"/siteterms/terms-and-conditions.html\">Điều khoản và điều kiện</a> sử dụng cũng như <a href=\"/siteterms/privacy.html\">Chính sách bảo mật</a> của chúng tôi. Nếu không đồng ý với các quy định này, bạn vui lòng ngưng sử dụng website.<br /> <br /> <strong><a id=\"index\" name=\"index\"></a>Danh mục</strong><br /> <a href=\"#1\">Điều 1: Điều khoản liên quan đến phần mềm vận hành website</a><br /> <a href=\"#2\">Điều 2: Giới hạn cho việc sử dụng Website và các tài liệu trên website</a><br /> <a href=\"#3\">Điều 3: Sử dụng thương hiệu</a><br /> <a href=\"#4\">Điều 4: Các hành vi bị nghiêm cấm</a><br /> <a href=\"#5\">Điều 5: Các đường liên kết đến các website khác</a><br /> <a href=\"#6\">Điều 6: Từ chối bảo đảm</a><br /> <a href=\"#7\">Điều 7: Luật áp dụng và cơ quan giải quyết tranh chấp</a><br /> <a href=\"#8\">Điều 8: Thay đổi điều khoản và điều kiện sử dụng</a></div>  <hr  /> <h2 style=\"text-align: justify;\"><a id=\"1\" name=\"1\"></a>Điều khoản liên quan đến phần mềm vận hành website</h2>  <p style=\"text-align: justify;\">- Website của chúng tôi sử dụng hệ thống NukeViet, là giải pháp về website/ cổng thông tin nguồn mở được phát hành theo giấy phép bản quyền phần mềm tự do nguồn mở “<a href=\"http://www.gnu.org/licenses/old-licenses/gpl-2.0.html\" target=\"_blank\">GNU General Public License</a>” (viết tắt là GNU/GPL hay GPL) và có thể tải về miễn phí tại trang web <a href=\"http://www.nukeviet.vn\" target=\"_blank\">www.nukeviet.vn</a>.<br /> - Website này do chúng tôi sở hữu, điều hành và duy trì. NukeViet (hiểu ở đây là “hệ thống NukeViet” (bao gồm nhân hệ thống NukeViet và các sản phẩm phái sinh như NukeViet CMS, NukeViet Portal, <a href=\"http://edu.nukeviet.vn\" target=\"_blank\">NukeViet Edu Gate</a>...), “www.nukeviet.vn”, “tổ chức NukeViet”, “ban điều hành NukeViet”, &quot;Ban Quản Trị NukeViet&quot; và nói chung là những gì liên quan đến NukeViet...) không liên quan gì đến việc chúng tôi điều hành website cũng như quy định bạn được phép làm và không được phép làm gì trên website này.<br /> - Hệ thống NukeViet là bộ mã nguồn được phát triển để xây dựng các website/ cổng thông tin trên mạng. Chúng tôi (chủ sở hữu, điều hành và duy trì website này) không hỗ trợ và khẳng định hay ngụ ý về việc có liên quan đến NukeViet. Để biết thêm nhiều thông tin về NukeViet, hãy ghé thăm website của NukeViet tại địa chỉ: <a href=\"http://nukeviet.vn\" target=\"_blank\">http://nukeviet.vn</a>.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2 style=\"text-align: justify;\"><a id=\"2\" name=\"2\"></a>Giới hạn cho việc sử dụng Website và các tài liệu trên website</h2>  <p style=\"text-align: justify;\">- Tất cả các quyền liên quan đến tất cả tài liệu và thông tin được hiển thị và/ hoặc được tạo ra sẵn cho Website này (ví dụ như những tài liệu được cung cấp để tải về) được quản lý, sở hữu hoặc được cho phép sử dụng bởi chúng tôi hoặc chủ sở hữu tương ứng với giấy phép tương ứng. Việc sử dụng các tài liệu và thông tin phải được tuân thủ theo giấy phép tương ứng được áp dụng cho chúng.<br /> - Ngoại trừ các tài liệu được cấp phép rõ ràng dưới dạng giấy phép tư liệu mở&nbsp;Creative Commons (gọi là giấy phép CC) cho phép bạn khai thác và chia sẻ theo quy định của giấy phép tư liệu mở, đối với các loại tài liệu không ghi giấy phép rõ ràng thì bạn không được phép sử dụng (bao gồm nhưng không giới hạn việc sao chép, chỉnh sửa toàn bộ hay một phần, đăng tải, phân phối, cấp phép, bán và xuất bản) bất cứ tài liệu nào mà không có sự cho phép trước bằng văn bản của chúng tôi ngoại trừ việc sử dụng cho mục đích cá nhân, nội bộ, phi thương mại.<br /> - Một số tài liệu hoặc thông tin có những điều khoản và điều kiện áp dụng riêng cho chúng không phải là giấy phép tư liệu mở, trong trường hợp như vậy, bạn được yêu cầu phải chấp nhận các điều khoản và điều kiện đó khi truy cập vào các tài liệu và thông tin này.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2 style=\"text-align: justify;\"><a id=\"3\" name=\"3\"></a>Sử dụng thương hiệu</h2>  <p style=\"text-align: justify;\">- VINADES.,JSC, NukeViet và thương hiệu gắn với NukeViet (ví dụ NukeViet CMS, NukeViet Portal, NukeViet Edu Gate...), logo công ty VINADES thuộc sở hữu của Công ty cổ phần phát triển nguồn mở Việt Nam.<br /> - Những tên sản phẩm, tên dịch vụ khác, logo và/ hoặc những tên công ty được sử dụng trong Website này là những tài sản đã được đăng ký độc quyền và được giữ bản quyền bởi những người sở hữu và/ hoặc người cấp phép tương ứng.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2 style=\"text-align: justify;\"><a id=\"4\" name=\"4\"></a>Các hành vi bị nghiêm cấm</h2>  <p style=\"text-align: justify;\">Người truy cập website này không được thực hiện những hành vi dưới đây khi sử dụng website:<br /> - Xâm phạm các quyền hợp pháp (bao gồm nhưng không giới hạn đối với các quyền riêng tư và chung) của người khác.<br /> - Gây ra sự thiệt hại hoặc bất lợi cho người khác.<br /> - Làm xáo trộn trật tự công cộng.<br /> - Hành vi liên quan đến tội phạm.<br /> - Tải lên hoặc phát tán thông tin riêng tư của tổ chức, cá nhân khác mà không được sự chấp thuận của họ.<br /> - Sử dụng Website này vào mục đích thương mại mà chưa được sự cho phép của chúng tôi.<br /> - Nói xấu, làm nhục, phỉ báng người khác.<br /> - Tải lên các tập tin chứa virus hoặc các tập tin bị hư mà có thể gây thiệt hại đến sự vận hành của máy tính khác.<br /> - Những hoạt động có khả năng ảnh hưởng đến hoạt động bình thường của website.<br /> - Những hoạt động mà chúng tôi cho là không thích hợp.<br /> - Những hoạt động bất hợp pháp hoặc bị cấm bởi pháp luật hiện hành.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2 style=\"text-align: justify;\"><a id=\"5\" name=\"5\"></a>Các đường liên kết đến các website khác</h2>  <p style=\"text-align: justify;\">- Các website của các bên thứ ba (không phải các trang do chúng tôi quản lý) được liên kết đến hoặc từ website này (&quot;Các website khác&quot;) được điều hành và duy trì hoàn toàn độc lập bởi các bên thứ ba đó và không nằm trong quyền điều khiển và/hoặc giám sát của chúng tôi. Việc truy cập các website khác phải được tuân thủ theo các điều khoản và điều kiện quy định bởi ban điều hành của website đó.<br /> - Chúng tôi không chịu trách nhiệm cho sự mất mát hoặc thiệt hại do việc truy cập và sử dụng các website bên ngoài, và bạn phải chịu mọi rủi ro khi truy cập các website đó.<br /> - Không có nội dung nào trong Website này thể hiện như một sự đảm bảo của chúng tôi về nội dung của các website khác và các sản phẩm và/ hoặc các dịch vụ xuất hiện và/ hoặc được cung cấp tại các website khác.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2 style=\"text-align: justify;\"><a id=\"6\" name=\"6\"></a>Từ chối bảo đảm</h2>  <p style=\"text-align: justify;\">NGOẠI TRỪ PHẠM VI BỊ CẤM THEO LUẬT PHÁP HIỆN HÀNH, CHÚNG TÔI SẼ:<br /> - KHÔNG CHỊU TRÁCH NHIỆM HAY BẢO ĐẢM, MỘT CÁCH RÕ RÀNG HAY NGỤ Ý, BAO GỒM SỰ BẢO ĐẢM VỀ TÍNH CHÍNH XÁC, MỨC ĐỘ TIN CẬY, HOÀN THIỆN, PHÙ HỢP CHO MỤC ĐÍCH CỤ THỂ, SỰ KHÔNG XÂM PHẠM QUYỀN CỦA BÊN THỨ 3 VÀ/HOẶC TÍNH AN TOÀN CỦA NỘI DỤNG WEBSITE NÀY, VÀ NHỮNG TUYÊN BỐ, ĐẢM BẢO CÓ LIÊN QUAN.<br /> - KHÔNG CHỊU TRÁCH NHIỆM CHO BẤT KỲ SỰ THIỆT HẠI HAY MẤT MÁT PHÁT SINH TỪ VIỆC TRUY CẬP VÀ SỬ DỤNG WEBSITE HAY VIỆC KHÔNG THỂ SỬ DỤNG WEBSITE.<br /> - CHÚNG TÔI CÓ THỂ THAY ĐỔI VÀ/HOẶC THAY THẾ NỘI DUNG CỦA WEBSITE NÀY, HOẶC TẠM HOÃN HOẶC NGƯNG CUNG CẤP CÁC DỊCH VỤ QUA WEBSITE NÀY VÀO BẤT KỲ THỜI ĐIỂM NÀO MÀ KHÔNG CẦN THÔNG BÁO TRƯỚC. CHÚNG TÔI SẼ KHÔNG CHỊU TRÁCH NHIỆM CHO BẤT CỨ THIỆT HẠI NÀO PHÁT SINH DO SỰ THAY ĐỔI HOẶC THAY THẾ NỘI DUNG CỦA WEBSITE.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2 style=\"text-align: justify;\"><a id=\"7\" name=\"7\"></a>Luật áp dụng và cơ quan giải quyết tranh chấp</h2>  <p style=\"text-align: justify;\">- Các Điều Khoản và Điều Kiện này được điều chỉnh và giải thích theo luật của Việt Nam trừ khi có điều khoản khác được cung cấp thêm. Tất cả tranh chấp phát sinh liên quan đến website này và các Điều Khoản và Điều Kiện sử dụng này sẽ được giải quyết tại các tòa án ở Việt Nam.<br /> - Nếu một phần nào đó của các Điều Khoản và Điều Kiện bị xem là không có giá trị, vô hiệu, hoặc không áp dụng được vì lý do nào đó, phần đó được xem như là phần riêng biệt và không ảnh hưởng đến tính hiệu lực của phần còn lại.<br /> - Trong trường hợp có sự mâu thuẫn giữa bản Tiếng Anh và bản Tiếng Việt của bản Điều Khoản và Điều Kiện này, bản Tiếng Việt sẽ được ưu tiên áp dụng.</p>  <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p>  <h2 style=\"text-align: justify;\"><a id=\"8\" name=\"8\"></a>Thay đổi điều khoản và điều kiện sử dụng</h2>  <div style=\"text-align: justify;\">Điều khoản và điều kiện sử dụng có thể thay đổi theo thời gian. Chúng tôi bảo lưu quyền thay đổi hoặc sửa đổi bất kỳ điều khoản và điều kiện cũng như các quy định khác, bất cứ lúc nào và theo ý mình. Chúng tôi sẽ có thông báo trên website khi có sự thay đổi. Tiếp tục sử dụng trang web này sau khi đăng các thay đổi tức là bạn đã chấp nhận các thay đổi đó. <p style=\"text-align: right;\"><a href=\"#index\">Trở lại danh mục</a></p> </div>', '', 0, '4', '', 0, 2, 1, 1475277519, 1475277519, 1);


-- ---------------------------------------


--
-- Table structure for table `az_vi_siteterms_config`
--

DROP TABLE IF EXISTS `az_vi_siteterms_config`;
CREATE TABLE `az_vi_siteterms_config` (
  `config_name` varchar(30)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  UNIQUE KEY `config_name` (`config_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_siteterms_config`
--

INSERT INTO `az_vi_siteterms_config` VALUES
('viewtype', '0'), 
('facebookapi', ''), 
('per_page', '20'), 
('news_first', '0'), 
('related_articles', '5');


-- ---------------------------------------


--
-- Table structure for table `az_vi_slider_group`
--

DROP TABLE IF EXISTS `az_vi_slider_group`;
CREATE TABLE `az_vi_slider_group` (
  `group_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`group_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=8  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_slider_group`
--

INSERT INTO `az_vi_slider_group` VALUES
(1, 'Trang chủ', 1, 1, 1475290379), 
(5, 'Khách hàng', 1, 3, 1477631925), 
(4, 'Videos', 1, 2, 1477604171), 
(6, 'Trang điểm', 1, 4, 1477671611), 
(7, 'Dịch vụ', 1, 5, 1477885475);


-- ---------------------------------------


--
-- Table structure for table `az_vi_slider_photo`
--

DROP TABLE IF EXISTS `az_vi_slider_photo`;
CREATE TABLE `az_vi_slider_photo` (
  `photo_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `links` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumb` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`photo_id`),
  UNIQUE KEY `title` (`title`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM  AUTO_INCREMENT=26  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_slider_photo`
--

INSERT INTO `az_vi_slider_photo` VALUES
(1, 1, '1', '', '#', '06.jpg', '06-thumb.jpg', 1, 1, 1475290406), 
(2, 1, '2', '', '#', '05.jpg', '05-thumb.jpg', 1, 2, 1475290422), 
(3, 1, '3', '', '#', '04.jpg', '04-thumb.jpg', 1, 3, 1475290450), 
(4, 1, '4', '', '#', '02_1.jpg', '02_1-thumb.jpg', 1, 4, 1475290479), 
(5, 1, '5', '', '#', '03_1.jpg', '03_1-thumb.jpg', 1, 5, 1475290503), 
(6, 1, '6', '', '#', '01_1.jpg', '01_1-thumb.jpg', 1, 6, 1475290562), 
(8, 1, '7', '', '#', 'apartment_revised_shot_5.jpg', 'apartment_revised_shot_5-thumb.jpg', 1, 7, 1477393423), 
(9, 4, 'Hari Won - Anh Cứ Đi Đi', '', 'https://www.youtube.com/embed/Y7nkqZvQcBQ', 'ficha2_imagen1_highres_post_mail.jpg', 'ficha2_imagen1_highres_post_mail-thumb.jpg', 1, 8, 1477604436), 
(10, 4, 'Phóng sự cưới đẹp', '', 'https://www.youtube.com/embed/77-rVHopRbs', '01.jpg', '01-thumb.jpg', 1, 9, 1477606330), 
(11, 4, 'Cưới flycam ở Lý Sơn', '', 'https://www.youtube.com/embed/eqQeSBXNdNE', '02.jpg', '02-thumb.jpg', 1, 10, 1477606430), 
(13, 5, 'Hoàng Thị Hằng Tâm', '10 năm kinh nghiệm trong ngành kiến trúc, nội thất và xây dựng, với hàng trăm khách hàng mỗi năm, Wonder là một công ty danh tiếng và đáng tin cậy trong việc cung cấp dịch vụ cho khách hàng tư nhân và doanh nghiệp.', '', 'ficha2_imagen1_highres_post_mail.jpg', 'ficha2_imagen1_highres_post_mail-thumb.jpg', 1, 12, 1477631982), 
(12, 4, 'Cưới Siêu Lãng Mạn & Hoành Tráng', 'Đám cưới của đôi tình nhân Hồng Lan và Lê Thanh Đám cưới của đôi tình nhân Hồng Lan và Lê Thanh Đám cưới của đôi tình nhân Hồng Lan và Lê Thanh Đám cưới của đôi tình nhân Hồng Lan và Lê ThanhĐám cưới của đôi tình nhân Hồng Lan và Lê Thanh Đám cưới của đôi tình nhân Hồng Lan và Lê Thanh', 'https://www.youtube.com/embed/cJ6e7k2OBts', '03.jpg', '03-thumb.jpg', 1, 11, 1477606588), 
(14, 5, 'Lê Mạnh Cường', 'Wonder áp dụng phong cách thiết kế đơn giản, bố trí nội thất thông minh, ánh sáng tràn ngập không gian với các khung cửa kính lớn và thiên về xu hướng cảnh quan màu xanh lá.', '', '04_hill_house_kitchen_detail_2000.jpg', '04_hill_house_kitchen_detail_2000-thumb.jpg', 1, 13, 1477632052), 
(15, 5, 'Lê Thị Thu Vân', 'Các nhóm thiết kế của Wonder quan tâm đến mọi khía cạnh từ khâu lên ý tưởng, phát triển concept đến thực tế sử dụng. Chúng tôi kết hợp giữa truyền thống và đương đại để phát triển sản phẩm. Tất cả dự án của Wonder là sự kết hợp giữa nghệ thuật kiến trúc và công năng sử dụng.', '', 'bedroom_12_1.jpg', 'bedroom_12_1-thumb.jpg', 1, 14, 1477632072), 
(16, 6, 'Mẫu 01', '', '', '006.jpg', '006-thumb.jpg', 1, 15, 1477671825), 
(17, 6, 'Mẫu 02', '', '', '002.jpg', '002-thumb.jpg', 1, 16, 1477671848), 
(18, 6, 'Mẫu 03', '', '', '005.jpg', '005-thumb.jpg', 1, 17, 1477671859), 
(19, 6, 'Mẫu 04', '', '', '003.jpg', '003-thumb.jpg', 1, 18, 1477671877), 
(20, 6, 'Mẫu 05', '', '', '004.jpg', '004-thumb.jpg', 1, 19, 1477671891), 
(21, 6, 'Mẫu 06', '', '', '001.jpg', '001-thumb.jpg', 1, 20, 1477671911), 
(22, 7, 'Cho thuê trang phục cưới', 'STUDIO DATNGUYEN  là địa chỉ tin cậy để các bạn trao niềm tin và lựa chọn cho mình một chiếc áo cưới lộng lẫy, hợp thời trang, quyến rũ nhất trong ngày cưới', '', '1453868678.png', '1453868678-thumb.png', 1, 21, 1477885543), 
(23, 7, 'Quay phóng sự cưới', 'Một bức ảnh hơn ngàn lời nói - 1 đoạn Video hơn ngàn bức ảnh. Xem những Clip cực đẹp với thiết bị đẳng cấp tại Palatino. Liên hệ ngay 091.14.41.65.67', '', '1453868707.png', '1453868707-thumb.png', 1, 22, 1477885560), 
(24, 7, 'Chụp ảnh đẳng cấp tại Palatino', 'Trải nghiệm những dịch vụ đẳng cấp tại Palatino Studio với chi phí siêu rẻ. Xem thêm vì sao đã có hơn 2000 khách hàng hài lòng về chất lượng của chúng tôi...', '', '1456475557.png', '1456475557-thumb.png', 1, 23, 1477885579), 
(25, 7, 'Trang điểm cô dâu, dạ hội', 'Chuyên viên Makeup tại PALATINO trên 5 năm kinh nghiệm. Với phong cách trang điểm đẳng cấp phong cách tự nhiên, sang trọng...', '', '1453868688.png', '1453868688-thumb.png', 1, 24, 1477885600);


-- ---------------------------------------


--
-- Table structure for table `az_vi_slider_template`
--

DROP TABLE IF EXISTS `az_vi_slider_template`;
CREATE TABLE `az_vi_slider_template` (
  `template_id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `date_added` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`template_id`),
  UNIQUE KEY `title` (`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=7  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_slider_template`
--

INSERT INTO `az_vi_slider_template` VALUES
(1, 'slider', 1, 1, 1475290330), 
(2, 'bxslider', 2, 1, 1475290330), 
(3, 'nivo_slider', 3, 1, 1475290330), 
(4, 'pinwheel', 4, 1, 1475290330), 
(5, 'khachhang', 5, 1, 0), 
(6, 'Trangdiem', 6, 1, 0);


-- ---------------------------------------


--
-- Table structure for table `az_vi_voting`
--

DROP TABLE IF EXISTS `az_vi_voting`;
CREATE TABLE `az_vi_voting` (
  `vid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(250)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `acceptcm` int(2) NOT NULL DEFAULT '1',
  `admin_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `groups_view` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `publ_time` int(11) unsigned NOT NULL DEFAULT '0',
  `exp_time` int(11) unsigned NOT NULL DEFAULT '0',
  `act` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`vid`),
  UNIQUE KEY `question` (`question`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_voting`
--

INSERT INTO `az_vi_voting` VALUES
(2, 'Bạn biết gì về NukeViet 4?', '', 1, 1, '6', 1275318563, 0, 1), 
(3, 'Lợi ích của phần mềm nguồn mở là gì?', '', 1, 1, '6', 1275318563, 0, 1);


-- ---------------------------------------


--
-- Table structure for table `az_vi_voting_rows`
--

DROP TABLE IF EXISTS `az_vi_voting_rows`;
CREATE TABLE `az_vi_voting_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `vid` smallint(5) unsigned NOT NULL,
  `title` varchar(245)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `url` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT '',
  `hitstotal` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=14  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_voting_rows`
--

INSERT INTO `az_vi_voting_rows` VALUES
(5, 2, 'Một bộ sourcecode cho web hoàn toàn mới.', '', 0), 
(6, 2, 'Mã nguồn mở, sử dụng miễn phí.', '', 0), 
(7, 2, 'Sử dụng HTML5, CSS3 và hỗ trợ Ajax', '', 0), 
(8, 2, 'Tất cả các ý kiến trên', '', 0), 
(9, 3, 'Liên tục được cải tiến, sửa đổi bởi cả thế giới.', '', 0), 
(10, 3, 'Được sử dụng miễn phí không mất tiền.', '', 0), 
(11, 3, 'Được tự do khám phá, sửa đổi theo ý thích.', '', 0), 
(12, 3, 'Phù hợp để học tập, nghiên cứu vì được tự do sửa đổi theo ý thích.', '', 0), 
(13, 3, 'Tất cả các ý kiến trên', '', 0);


-- ---------------------------------------


--
-- Table structure for table `az_vi_weblinks_cat`
--

DROP TABLE IF EXISTS `az_vi_weblinks_cat`;
CREATE TABLE `az_vi_weblinks_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parentid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `catimage` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci,
  `weight` smallint(4) NOT NULL DEFAULT '0',
  `inhome` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `numlinks` tinyint(2) unsigned NOT NULL DEFAULT '3',
  `keywords` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) unsigned NOT NULL,
  `edit_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`catid`),
  UNIQUE KEY `parentid` (`parentid`,`title`)
) ENGINE=MyISAM  AUTO_INCREMENT=2  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_weblinks_cat`
--

INSERT INTO `az_vi_weblinks_cat` VALUES
(1, 0, 'Báo giá tháng 10', '', 'Bao-gia-thang-10', '', 1, 1, 3, '', 1475396808, 1475396808);


-- ---------------------------------------


--
-- Table structure for table `az_vi_weblinks_config`
--

DROP TABLE IF EXISTS `az_vi_weblinks_config`;
CREATE TABLE `az_vi_weblinks_config` (
  `name` varchar(20)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` varchar(255)  COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_weblinks_config`
--

INSERT INTO `az_vi_weblinks_config` VALUES
('intro', ''), 
('numcat', '2'), 
('showsub', '1'), 
('numsub', '2'), 
('numinsub', '1'), 
('showcatimage', '0'), 
('per_page', '20'), 
('numsubcat', '2'), 
('shownumsubcat', '1'), 
('sort', 'asc'), 
('showlinkimage', '0'), 
('showdes', '1'), 
('sortoption', 'byid'), 
('imgwidth', '100'), 
('imgheight', '74'), 
('timeout', '1');


-- ---------------------------------------


--
-- Table structure for table `az_vi_weblinks_report`
--

DROP TABLE IF EXISTS `az_vi_weblinks_report`;
CREATE TABLE `az_vi_weblinks_report` (
  `id` int(11) DEFAULT NULL,
  `type` int(1) DEFAULT NULL,
  `report_time` int(11) NOT NULL,
  `report_userid` int(11) NOT NULL,
  `report_ip` varchar(16)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_browse_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_browse_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_os_key` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_os_name` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `report_note` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;


-- ---------------------------------------


--
-- Table structure for table `az_vi_weblinks_rows`
--

DROP TABLE IF EXISTS `az_vi_weblinks_rows`;
CREATE TABLE `az_vi_weblinks_rows` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` mediumint(9) NOT NULL,
  `author` varchar(100)  COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1|1',
  `title` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `alias` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `urlimg` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_email` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `note` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `gia_1` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `mieuta_gia_1` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `gia_2` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `mieuta_gia_2` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `gia_3` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `mieuta_gia_3` varchar(255)  COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text  COLLATE utf8mb4_unicode_ci NOT NULL,
  `add_time` int(11) unsigned NOT NULL DEFAULT '0',
  `edit_time` int(11) unsigned NOT NULL DEFAULT '0',
  `hits_total` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`),
  KEY `status` (`status`)
) ENGINE=MyISAM  AUTO_INCREMENT=4  DEFAULT CHARSET=utf8mb4  COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `az_vi_weblinks_rows`
--

INSERT INTO `az_vi_weblinks_rows` VALUES
(1, 1, '1|1', 'Trọn gói đ&#x002F;m²', 'Tron-goi-d-m', 'http://azvietco.vn', 'weblinks/1-55-720x540.jpg', '0', '0', '', '249,000', 'Nhà phố, Biệt thự Khách sạn, Resort', '299,000', 'Bar, Cafe, Nhà hàng Nhà nhỏ dưới 120m² Nhà phong cách cổ điển', '199,000', 'Sân vườn, Cảnh quan Tư vấn thiết kế nhanh', 'Bảng vẽ Kiến trúc,<br  />
Nội thất Kết cấu,<br  />
M&amp;E Hồ sơ xin phép xây dựng<br  />
Giám sát tác giả', 1475396829, 1475403456, 1, 1), 
(2, 1, '1|1', 'Kiến trúc đ&#x002F;m²', 'Kien-truc-d-m', 'http://azvietco.vn/1/', 'weblinks/1-55-720x540.jpg', '0', '0', '', '189,000', 'Nhà phố, Biệt thự Khách sạn, Resort', '249,000', 'Bar, Cafe, Nhà hàng Nhà nhỏ dưới 120m² Nhà phong cách cổ điển', '199,000', 'Sân vườn, Cảnh quan Tư vấn thiết kế nhanh', '<ul>
	<li style=\"text-align: justify;\">Bảng vẽ Kiến trúc</li>
	<li style=\"text-align: justify;\">Kết cấu (none: cải tạo)</li>
	<li style=\"text-align: justify;\">Hồ sơ xin phép xây dựng</li>
	<li style=\"text-align: justify;\">Giám sát tác giả</li>
</ul>', 1475399415, 1477723006, 1, 1), 
(3, 1, '1|1', 'Nội thất đ&#x002F;m²', 'Noi-that-d-m', 'http://azvietco.vn/2/', 'weblinks/1-55-720x540.jpg', '0', '0', '', '189,000', 'Nhà phố, Biệt thự Khách sạn, Resort', '249,000', 'Bar, Cafe, Nhà hàng Nhà nhỏ dưới 120m² Nhà phong cách cổ điển', '199,000', 'Sân vườn, Cảnh quan Tư vấn thiết kế nhanh', '<ul>
	<li>Bảng vẽ 3D nội thất</li>
	<li>M&amp;E</li>
	<li>Giám sát tác giả</li>
</ul>', 1475399873, 1475399873, 1, 1);