import React from 'react';
import FlashCard from './components/flashcard/FlashCard.jsx';
import StatusBar from './components/statusbar/StatusBar.jsx';
import './App.css';

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      // card list
      cards: [
        {
          word: '여자',
          definition: 'women'
        }, 
        {
          word: '남자',
          definition: 'men'
        },
        // more words here
      ],
      // the index of showing card in <card list>
      index: 0 
    };
  }

  async componentDidMount() {
    const response = await fetch('https://wpr-quiz-api.herokuapp.com/cards');
    const cards = await response.json();

    this.setState({cards});
  }

  next = () => {
    let {index} = this.state;
    index++;

    this.setState({ index });
  }

  prev = () => {
    let {index} = this.state;
    index--;

    this.setState({ index });
  }

  render() {
    const card = this.state.cards[this.state.index];
    
    return <div id="main">
          <div id="flashcard-container">
              
              <FlashCard card = {card} />

          </div>

          <StatusBar
            currentIndex={this.state.index+1} 
            maxIndex={this.state.cards.length} 
            prevCallback={this.prev} 
            nextCallback={this.next} 
          />
          
      </div>;
  }
}

export default App;
