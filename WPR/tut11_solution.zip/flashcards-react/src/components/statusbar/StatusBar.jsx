export default function StatusBar({currentIndex, maxIndex, prevCallback, nextCallback}) {
    return <div id="status-bar">
        <button 
            disabled={currentIndex <= 1} 
            id="prev" 
            onClick={prevCallback}
        >&larr;</button>
        
        <strong>{currentIndex}</strong>/<span>{maxIndex}</span>
        
        <button 
            disabled={currentIndex >= maxIndex} 
            id="next" 
            onClick={nextCallback}
        >&rarr;</button>
    </div>;
}