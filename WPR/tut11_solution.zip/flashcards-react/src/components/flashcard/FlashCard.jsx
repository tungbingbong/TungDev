// exercise 1: functional component - version
// export default function FlashCard({card}) {
//     return <div className="flashcard-box">
//         <div className="flashcard word">{card.word}</div>
//         <div className="flashcard definition">{card.definition}</div>
//     </div>;
// }

// exercise 2: class component
import React from 'react';
import './FlashCard.css';

export default class FlashCard extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            showingWordSide: true
        };
    }

    flip = () => {
        let {showingWordSide} = this.state;
        showingWordSide = !showingWordSide;

        this.setState({ showingWordSide });
    }

    render() {
        const {card} = this.props;

        return <div className="flashcard-box" onClick={this.flip}>
            {
                this.state.showingWordSide ?
                    <div className="flashcard word">{card.word}</div> 
                    : <div className="flashcard definition">{card.definition}</div>
            }
        </div>;
    }
}