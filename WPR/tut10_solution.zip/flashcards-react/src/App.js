import React from 'react';

class App extends React.Component {
  constructor() {
    super();
    this.state = {
      // card list
      cards: [
        {
          word: '여자',
          definition: 'women'
        }, 
        {
          word: '남자',
          definition: 'men'
        },
        // more words here
      ],
      // the index of showing card in <card list>
      index: 0 
    };
  }

  next = () => {
    this.setState({
      ...this.state,
      index: this.state.index+1
    });
  }

  prev = () => {
    this.setState({
      ...this.state,
      index: this.state.index-1
    });
  }

  render() {
    const card = this.state.cards[this.state.index];
    
    return <div id="main">
          <div id="flashcard-container">
              <div className="flashcard-box">
                <div className="flashcard word">{card.word}</div>
                <div className="flashcard definition">{card.definition}</div>
              </div>
          </div>

          <div id="status-bar">
              <button disabled={this.state.index <= 0} id="prev" onClick={this.prev}>&larr;</button>
              <strong>{this.state.index+1}</strong>/<span>{this.state.cards.length}</span>
              <button disabled={this.state.index >= this.state.cards.length-1} id="next" onClick={this.next}>&rarr;</button>
          </div>
      </div>;
  }
}

export default App;
