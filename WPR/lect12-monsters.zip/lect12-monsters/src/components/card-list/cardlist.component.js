import React from 'react';
import Card from '../card/card.component';
import './cardlist.styles.css';

export default class CardList extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            monsters: []
        };

        // NOTE: error - not update to display fetched data??
        // this.state = {
        //     monsters: props.monsters
        // };
    }

    // --> solution 2
    static getDerivedStateFromProps(props, state) {
        return {
            monsters: props.monsters
        };
    }

    render() {
        const cards = [];
        for (const monster of this.state.monsters) { // --> solution 1: this.props.monsters
            const card = <Card key={monster.id} monster = {monster} />;
            cards.push(card);
        }

        return <div className='card-list'>
            {cards}
        </div>;
    }
} 