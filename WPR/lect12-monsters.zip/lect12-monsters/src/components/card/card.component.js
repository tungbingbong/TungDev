import { Link } from 'react-router-dom';
import './card.styles.css';

export default function Card(props) {

    return <div className='card-container'>
        <img 
            alt='monster' 
            src={`https://robohash.org/${props.monster.id}?set=set2&size=180x180`} 
        />
        <h2> {props.monster.name} </h2>
        <p> {props.monster.email} </p>

        <Link to={`/${props.monster.id}`}>Details</Link>
        <Link to={`/${props.monster.id}/update`}>Update</Link>

    </div>;
}

