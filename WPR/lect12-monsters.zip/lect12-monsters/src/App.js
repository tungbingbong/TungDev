import React from 'react';
import { Route, Switch } from 'react-router-dom';
import './App.css';
import AddPage from './pages/addpage/addpage.component';
import HomePage from './pages/homepage/homepage.component';
export default class App extends React.Component {
    constructor() {
        super();

        this.state = {
            monsters: [],
        };
    }

    async componentDidMount() {
        const response = await fetch('https://jsonplaceholder.typicode.com/users');
        const monsters = await response.json();
        
        this.setState({
            monsters: monsters
        });
    }

    addMonster(monster) {
        this.setState({
            monster, 
            ...this.state.monsters
        });
    }

    render() {
        return <div className='App'>
            <Route exact path='/' component={() => <HomePage monsters={this.state.monsters} />} />
            <Route path='/add' component={() => <AddPage addMonsterCallback={this.addMonster} />} /> 
        </div>;
    }
}