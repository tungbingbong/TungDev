import React from 'react';
import CardList from '../../components/card-list/cardlist.component';

export default class HomePage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            // monsters: [],  // now as props
            searchField: ''
        };
    }

    search = (event) => {
        this.setState({
            searchField: event.target.value
        });
    }

    render() {
        // filter using this.state.searchField
        const filteredMonsters = [];
        for (const monster of this.props.monsters) {
            if (monster.name.toLowerCase().includes(this.state.searchField)) {
                filteredMonsters.push(monster);
            }
        }

        return <div className='App'>
            <h1>Monsters Rolodex</h1>
            
            <input className='search-box' onChange={this.search} type='search' placeholder='search monsters' />

            <CardList monsters={filteredMonsters} />
        </div>;
    }
}