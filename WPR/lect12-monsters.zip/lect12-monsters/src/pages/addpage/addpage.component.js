import React from 'react';
import { withRouter } from 'react-router-dom';

class AddPage extends React.Component {
    constructor() {
        super();

        this.state = {
            id: '',
            name: '',
            email: ''
        };
    }

    handleChange = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        });
    }

    handleSubmit = (e) => {
        e.preventDefault();

        // do something with data
        console.log(this.state);

        // redirect to homepage
        this.props.history.push('/');
    }

    render() {
        return <>
            <h1>new Monster</h1>

            <form onSubmit={this.handleSubmit}>
                <div>
                    <label>ID</label>   
                    <input type="number" name="id" onChange={this.handleChange} />
                </div>

                <div>
                    <label>Name</label>
                    <input type="text" name="name" onChange={this.handleChange} />
                </div>

                <div>
                    <label>Email</label>
                    <input type="email" name="email" onChange={this.handleChange} />
                </div>
            </form>
        </>;
    }
}

export default withRouter(AddPage);