import React from 'react';
import Card from '../card/card.component';
import './cardlist.styles.css';

export default class CardList extends React.Component {
    constructor(props) {
        super(props);

        // NOTE: error - not displaying fetched data??
        this.state = {
            monsters: props.monsters
        };
    }

    render() {
        const cards = [];
        for (const monster of this.state.monsters) {
            const card = <Card monster = {monster} />;
            cards.push(card);
        }

        return <div class='card-list'>
            {cards}
        </div>;
    }
} 