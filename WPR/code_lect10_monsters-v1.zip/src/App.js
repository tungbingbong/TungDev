import React from 'react';
import './App.css';
import CardList from './components/card-list/cardlist.component';
export default class App extends React.Component {
    constructor() {
        super();

        this.state = {
            monsters: []
            // monsters: [
            //     {
            //         id: 1,
            //         name: "CongNV",
            //         email: "congnv@hanu.edu.vn"
            //     }, 
            //     {
            //         id: 2,
            //         name: "CamNH",
            //         email: "camnh@hanu.edu.vn"
            //     },
            //     {
            //         id: 3,
            //         name: "NgocTB",
            //         email: "ngoctb@hanu.edu.vn"
            //     }
            // ]
        };
    }

    async componentDidMount() {
        const response = await fetch('https://jsonplaceholder.typicode.com/users');
        const monsters = await response.json();
        
        this.setState({
            monsters: monsters
        });
    }

    render() {
        return <div class='App'>
            <h1>Monsters Rolodex</h1>
            
            <input class='search-box' type='search' placeholder='search monsters' />

            <CardList monsters={this.state.monsters} />
        </div>;
    }
}