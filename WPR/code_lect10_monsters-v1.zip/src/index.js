import ReactDOM from 'react-dom';
import App from './App';

import './index.css';

ReactDOM.render(<App message="hi" />, document.querySelector('#root'));