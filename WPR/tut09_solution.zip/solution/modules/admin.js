const { Router } = require('express');
const express = require('express');
const { ObjectID } = require('mongodb');
const url = require('url');

const router = express.Router();

// middleware: allow access req in .handlebars template
router.use(function(req,res,next){
    res.locals.req = req;
    next();
});

// view table of all words
router.get('/admin/words', async function (req, res) {
    const docs = await req.db.collection('words').find().toArray();

    res.render('admin/words/index.handlebars', {docs: docs});
});

// form: create card
router.get('/admin/words/create', function(req, res) {
    const doc = req.query;

    res.render('admin/words/create.handlebars', {doc});
});

// store new card
router.post('/admin/words', async function(req, res) {
    const word = req.body.word;
    const definition = req.body.definition;

    // validate exists
    const doc = await req.db.collection('words').findOne({word: word});

    if (doc != null) { // word already exists
        return res.redirect(url.format({
            pathname: '/admin/words/create', 
            query: {
                error: '409: CONFLICT: word already exists',
                ...req.body
            }
        }));
    }

    // insert
    const result = await req.db.collection('words').insertOne({word: word, definition: definition});
    console.log(result);

    // redirect to <table of all words>
    return res.redirect(url.format({pathname: '/admin/words', query: {success: 'Added a new card: ' + word}}));
});

// form: edit card
router.get('/admin/words/:id/edit', async function(req, res) {
    const id = req.params.id;

    const doc = await req.db.collection('words').findOne({_id: ObjectID(id)});

    if (doc == null) { // word not exist
        // redirect to <table of all words>
        return res.redirect('/admin/words');
    }

    res.render('admin/words/edit.handlebars', {doc});
});

// update card
router.post('/admin/words/:id/update', async function(req, res) {
    const id = req.params.id;
    const word = req.body.word;
    const definition = req.body.definition;

    const doc = await req.db.collection('words').findOne({_id: ObjectID(id)});

    if (doc == null) { // word not exist
        return res.redirect(url.format({
            pathname: `/admin/words/${id}/edit`, 
            query: {
                error: '404: NOT FOUND: word not exist',
                ...req.body
            }
        }));
    }

    const result = await req.db.collection('words').update({_id: ObjectID(id)}, {word: word, definition: definition});
    console.log(result);
    
    // redirect to <table of all words>
    return res.redirect(url.format({pathname: '/admin/words', query: {success: 'Updated card: ' + doc.word}}));
});

// delete card
router.post('/admin/words/:id/delete', async function(req, res) {
    const id = req.params.id;
    const doc = await req.db.collection('words').findOne({_id: ObjectID(id)});

    if (doc == null) { // word not exist
        // redirect to <table of all words>
        return res.redirect('/admin/words');
    }

    const result = await req.db.collection('words').deleteOne({_id: ObjectID(id)});
    console.log(result);

    // redirect to <table of all words>
    return res.redirect(url.format({pathname: '/admin/words', query: {success: 'Deleted card: ' + doc.word}}));
});


module.exports = router;