function linearEquation(a, b) {
    if (a === 0) {
        if (b === 0) {
            return 'many roots';
        } else {
            return 'no root';
        }
    } else {
        const x = -b/a;
        return 'one root x=' + x;
    }
}

function quadraticEquation(a, b, c) {
    if (a === 0) {
        return linearEquation(b, c);
    } else {
        const delta = b*b-4*a*c;

        if (delta > 0) {
            const x1 = (-b + Math.sqrt(delta)) / (2 * a);
            const x2 = (-b - Math.sqrt(delta)) / (2 * a);

            return '2 roots: x1=' + x1 + ', x2=' + x2;
        } else if (delta === 0) {
            const x = -b/(2*a);

            return '1 root: x=' + x;
        } else {
            return 'no root';
        }
    }
}

function onBtnSolveClick() {
    const a = parseFloat(inputA.value) || 1; // if user not input value for a, a = 1 by default
    const b = parseFloat(inputB.value) || 1;
    const c = parseFloat(inputC.value) || 0;

    const roots = quadraticEquation(a,b,c);

    // show result
    resultView.textContent = roots;
}

const inputA = document.querySelector('input#a');
const inputB = document.querySelector('input#b');
const inputC = document.querySelector('input#c');

const btnSolve = document.querySelector('button');
btnSolve.addEventListener('click', onBtnSolveClick);

const resultView = document.querySelector('#result');