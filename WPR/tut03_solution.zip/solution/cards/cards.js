function createCard(cardSource) {
    const img = document.createElement('img');
    img.src = cardSource;
    return img;
}

function onCardClick(event) {
    const card = event.currentTarget;

    // remove active if any
    const activeCard = document.querySelector('.active');
    if (activeCard) {
        activeCard.classList.remove('active');
    }

    card.classList.add('active');
}

const cardBoard = document.querySelector('#card-board');

for (const cardSource of CARD_SOURCES) {
    const card = createCard(cardSource);
    card.addEventListener('click', onCardClick);
    cardBoard.appendChild(card);
}