// const WORDS = {
//     '네': 'yes', 
//     '아니요': 'no'
// };

const express = require('express');
const mongodb = require('mongodb');

const app = express();

// serve static files (html, css, js, images...)
app.use(express.static('public'));

// decode req.body from form-data
app.use(express.urlencoded());
// decode req.body from post body message
app.use(express.json());

app.get('/hello', function(req, res) {
    res.send('Hello ' + req.query.name + '!');
});

// get all words
app.get('/words', async function(req, res) {
    const docs = await db.collection('words').find().toArray();

    const WORDS = {};
    for (const doc of docs) {
        WORDS[doc.word] = doc.definition;
    }

    res.json(WORDS); // OK (by default)
});

// create a new word
app.post('/words', async function (req, res){
    const word = req.body.word;
    const definition = req.body.definition;

    const doc = await db.collection('words').findOne({word: word});

    if (doc != null) { // word already exists
        return res.status(409).end(); // CONFLICT
    }

    const result = await db.collection('words').insertOne({word: word, definition: definition});
    console.log(result);
    res.status(201).json({word: definition});
});

// update a word
app.put('/words/:word', async function(req, res) {
    const word = req.params.word;
    const definition = req.body.definition;

    const doc = await db.collection('words').findOne({word: word});

    if (doc == null) { // word not exist
        return res.status(404).end(); // NOT FOUND
    }

    const result = await db.collection('words').update({word: word}, {word: word, definition: definition});
    console.log(result);
    
    res.json({word: definition}); // OK (by default)
});

// delete a word
app.delete('/words/:word', async function (req, res){
    const word = req.params.word;
    const definition = req.body.definition;
    
    const doc = await db.collection('words').findOne({word: word});

    if (doc == null) { // word not exist
        return res.status(404).end(); // NOT FOUND
    }

    const result = await db.collection('words').deleteOne({word: word});
    console.log(result);

    res.json({word: definition}); // OK (by default)
});

let db = null;
async function startServer() {
    const client = await mongodb.MongoClient.connect('mongodb://localhost:27017/flashcards-db');
    db = client.db();
    console.log('connected to db.');

    await app.listen(3000);
    console.log('Listening on port 3000!');
}
startServer();

// app.listen(3000, function(){
//     console.log('Listening on port 3000!');
// }); 