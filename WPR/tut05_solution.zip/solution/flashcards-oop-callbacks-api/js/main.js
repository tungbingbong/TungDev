const cardContainer = document.querySelector('#flashcard-container');
const statusBarContainer = document.querySelector('#status-bar');

function onResponse(response) {
    return response.json();
}

function onJson(json) {
    const app = new App(cardContainer, statusBarContainer, json);
}

fetch('https://wpr-quiz-api.herokuapp.com/words').then(onResponse).then(onJson);