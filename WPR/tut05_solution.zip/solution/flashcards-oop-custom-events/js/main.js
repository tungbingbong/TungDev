const cardContainer = document.querySelector('#flashcard-container');
const statusBarContainer = document.querySelector('#status-bar');

const app = new App(cardContainer, statusBarContainer, WORDS);


